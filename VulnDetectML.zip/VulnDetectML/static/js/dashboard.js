/**
 * Dashboard JS - Zero-Day Vulnerability Detection System
 * Handles chart initializations and dashboard functionality
 */

/**
 * Initialize dashboard charts
 * @param {Object} anomalyData - Data for the anomaly pie chart
 */
function initDashboardCharts(anomalyData) {
    // Initialize anomaly pie chart
    const anomalyPieCtx = document.getElementById('anomalyPieChart').getContext('2d');
    
    const anomalyPieChart = new Chart(anomalyPieCtx, {
        type: 'doughnut',
        data: anomalyData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#e9ecef'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            },
            cutout: '70%'
        }
    });
}

/**
 * Format date for display
 * @param {string} dateString - ISO date string
 * @returns {string} Formatted date string
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

/**
 * Format file size in human-readable format
 * @param {number} bytes - Size in bytes
 * @returns {string} Formatted size string
 */
function formatFileSize(bytes) {
    if (bytes < 1024) {
        return bytes + ' bytes';
    } else if (bytes < 1024 * 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    } else {
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }
}

/**
 * Update the dashboard data
 * Fetches the latest data from the server and updates the UI
 */
function updateDashboardData() {
    // This function can be implemented to periodically refresh dashboard data
    // using fetch API to get updated statistics
    
    // Example:
    // fetch('/api/dashboard/stats')
    //   .then(response => response.json())
    //   .then(data => {
    //     // Update statistics
    //     document.getElementById('totalPayloads').textContent = data.total_payloads;
    //     document.getElementById('analyzedPayloads').textContent = data.analyzed_payloads;
    //     // etc.
    //   })
    //   .catch(error => console.error('Error updating dashboard:', error));
}

// Add event listeners when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Set up any event listeners or additional initialization here
    
    // Example: Refresh data every 30 seconds
    // setInterval(updateDashboardData, 30000);
});
