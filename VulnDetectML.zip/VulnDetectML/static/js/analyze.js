/**
 * Analyze.js - Zero-Day Vulnerability Detection System
 * Handles payload analysis functionality
 */

// Store template examples for different payload types
const templates = {
    json: `{
  "request": {
    "method": "GET",
    "path": "/api/v1/users",
    "headers": {
      "Content-Type": "application/json",
      "Authorization": "Bearer TOKEN"
    },
    "params": {
      "id": 12345,
      "include_details": true
    }
  }
}`,
    xml: `<?xml version="1.0" encoding="UTF-8"?>
<request>
  <method>GET</method>
  <path>/api/v1/users</path>
  <headers>
    <header name="Content-Type">application/xml</header>
    <header name="Authorization">Bearer TOKEN</header>
  </headers>
  <params>
    <param name="id">12345</param>
    <param name="include_details">true</param>
  </params>
</request>`,
    script: `#!/bin/bash
# Example script
echo "Processing request..."
USER_ID=12345
REQUEST_PATH="/api/v1/users"

# Get user data
curl -X GET "$REQUEST_PATH/$USER_ID" \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer TOKEN"

echo "Request completed"`
};

// Random payload generators
const randomPayloadGenerators = {
    json: function() {
        const methods = ["GET", "POST", "PUT", "DELETE"];
        const contentTypes = ["application/json", "application/xml", "text/plain"];
        const paths = ["/api/v1/users", "/api/v1/products", "/api/v1/orders", "/api/v1/auth/login"];
        
        return JSON.stringify({
            request: {
                method: methods[Math.floor(Math.random() * methods.length)],
                path: paths[Math.floor(Math.random() * paths.length)],
                headers: {
                    "Content-Type": contentTypes[Math.floor(Math.random() * contentTypes.length)],
                    "Authorization": "Bearer " + Math.random().toString(36).substring(2, 15)
                },
                params: {
                    id: Math.floor(Math.random() * 10000),
                    limit: Math.floor(Math.random() * 100),
                    include_details: Math.random() > 0.5
                }
            }
        }, null, 2);
    },
    
    xml: function() {
        const methods = ["GET", "POST", "PUT", "DELETE"];
        const contentTypes = ["application/json", "application/xml", "text/plain"];
        const paths = ["/api/v1/users", "/api/v1/products", "/api/v1/orders", "/api/v1/auth/login"];
        
        return `<?xml version="1.0" encoding="UTF-8"?>
<request>
  <method>${methods[Math.floor(Math.random() * methods.length)]}</method>
  <path>${paths[Math.floor(Math.random() * paths.length)]}</path>
  <headers>
    <header name="Content-Type">${contentTypes[Math.floor(Math.random() * contentTypes.length)]}</header>
    <header name="Authorization">Bearer ${Math.random().toString(36).substring(2, 15)}</header>
  </headers>
  <params>
    <param name="id">${Math.floor(Math.random() * 10000)}</param>
    <param name="limit">${Math.floor(Math.random() * 100)}</param>
    <param name="include_details">${Math.random() > 0.5 ? "true" : "false"}</param>
  </params>
</request>`;
    },
    
    script: function() {
        const methods = ["GET", "POST", "PUT", "DELETE"];
        const paths = ["/api/v1/users", "/api/v1/products", "/api/v1/orders", "/api/v1/auth/login"];
        
        return `#!/bin/bash
# Random script example
echo "Processing request..."
USER_ID=${Math.floor(Math.random() * 10000)}
REQUEST_PATH="${paths[Math.floor(Math.random() * paths.length)]}"
REQUEST_METHOD="${methods[Math.floor(Math.random() * methods.length)]}"

# Make the request
curl -X $REQUEST_METHOD "$REQUEST_PATH/$USER_ID" \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer ${Math.random().toString(36).substring(2, 15)}"

echo "Request completed with status $?"`;
    },
    
    text: function() {
        const commands = [
            "SELECT * FROM users WHERE username='admin'",
            "GET /api/v1/users?id=12345 HTTP/1.1",
            "find /var/www -name '*.php' -type f",
            "ping -c 4 google.com"
        ];
        
        return commands[Math.floor(Math.random() * commands.length)];
    }
};

// Document ready function
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const payloadContent = document.getElementById('payload_content');
    const payloadNameInput = document.getElementById('payload_name');
    const payloadFileInput = document.getElementById('payload_file');
    const formatHelpers = document.querySelectorAll('.format-helper');
    const clearPayloadBtn = document.getElementById('clearPayload');
    const generateRandomBtn = document.getElementById('generateRandomPayload');
    const loadExampleBtns = document.querySelectorAll('.load-example');
    const payloadTypeRadios = document.querySelectorAll('input[name="payload_type"]');
    const injectZeroDayCheckbox = document.getElementById('inject_zero_day');
    const vulnerabilityOptions = document.getElementById('vulnerability_options');
    const useDeepLearningCheckbox = document.getElementById('use_deep_learning');
    const deepLearningOptions = document.getElementById('deep_learning_options');

    // Add event listeners to payload type radio buttons
    payloadTypeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            // Update the "Generate Random" button text to reflect the selected type
            if (generateRandomBtn) {
                generateRandomBtn.innerHTML = `<i class="fas fa-random me-2"></i> Generate Random ${this.value.charAt(0).toUpperCase() + this.value.slice(1)}`;
            }
        });
    });
    
    // Handle file upload
    if (payloadFileInput) {
        payloadFileInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                // Auto-fill the name field with the file name if empty
                if (!payloadNameInput.value) {
                    payloadNameInput.value = file.name;
                }
                
                // Set payload type based on file extension
                const extension = file.name.split('.').pop().toLowerCase();
                if (extension) {
                    // Try to match file extension to a payload type
                    if (['json'].includes(extension)) {
                        document.getElementById('type_json').checked = true;
                    } else if (['xml', 'html', 'svg'].includes(extension)) {
                        document.getElementById('type_xml').checked = true;
                    } else if (['sh', 'bash', 'js', 'py', 'php', 'rb', 'pl', 'ps1'].includes(extension)) {
                        document.getElementById('type_script').checked = true;
                    } else {
                        document.getElementById('type_text').checked = true;
                    }
                }
                
                // Read the file content
                const reader = new FileReader();
                reader.onload = function(e) {
                    payloadContent.value = e.target.result;
                };
                reader.readAsText(file);
            }
        });
    }

    // Add event listeners to format helper dropdown items
    formatHelpers.forEach(helper => {
        helper.addEventListener('click', function() {
            const formatType = this.getAttribute('data-type');
            if (templates[formatType]) {
                payloadContent.value = templates[formatType];
                
                // Also select the corresponding radio button
                const radioBtn = document.getElementById(`type_${formatType}`);
                if (radioBtn) {
                    radioBtn.checked = true;
                }
                
                // Generate a default name if empty
                if (!payloadNameInput.value) {
                    payloadNameInput.value = `${formatType.charAt(0).toUpperCase() + formatType.slice(1)} Payload`;
                }
            }
        });
    });

    // Clear payload button
    if (clearPayloadBtn) {
        clearPayloadBtn.addEventListener('click', function() {
            payloadContent.value = '';
        });
    }

    // Generate random payload button
    if (generateRandomBtn) {
        generateRandomBtn.addEventListener('click', function() {
            // Get selected payload type
            const selectedType = document.querySelector('input[name="payload_type"]:checked').value;
            
            // Generate random payload based on type
            if (randomPayloadGenerators[selectedType]) {
                payloadContent.value = randomPayloadGenerators[selectedType]();
                
                // Generate a default name if empty
                if (!payloadNameInput.value) {
                    payloadNameInput.value = `Random ${selectedType.charAt(0).toUpperCase() + selectedType.slice(1)} Payload`;
                }
            }
        });
    }

    // Load example buttons
    loadExampleBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const type = this.getAttribute('data-type');
            const name = this.getAttribute('data-name');
            const content = this.getAttribute('data-content');
            
            // Set the form values
            payloadContent.value = content;
            payloadNameInput.value = name;
            
            // Select the corresponding type radio
            const radioBtn = document.getElementById(`type_${type}`);
            if (radioBtn) {
                radioBtn.checked = true;
            }
            
            // Switch to the manual input tab
            const manualTab = document.getElementById('manual-tab');
            if (manualTab) {
                const tabInstance = new bootstrap.Tab(manualTab);
                tabInstance.show();
            }
        });
    });

    // Toggle vulnerability options based on checkbox
    if (injectZeroDayCheckbox && vulnerabilityOptions) {
        injectZeroDayCheckbox.addEventListener('change', function() {
            if (this.checked) {
                vulnerabilityOptions.style.display = 'block';
            } else {
                vulnerabilityOptions.style.display = 'none';
            }
        });
        
        // Initial state
        vulnerabilityOptions.style.display = injectZeroDayCheckbox.checked ? 'block' : 'none';
    }
    
    // Toggle deep learning options based on checkbox
    if (useDeepLearningCheckbox && deepLearningOptions) {
        useDeepLearningCheckbox.addEventListener('change', function() {
            if (this.checked) {
                deepLearningOptions.style.display = 'block';
            } else {
                deepLearningOptions.style.display = 'none';
            }
        });
        
        // Initial state
        deepLearningOptions.style.display = useDeepLearningCheckbox.checked ? 'block' : 'none';
    }
    
    // Toggle listener configuration options based on checkbox
    const configureListenerCheckbox = document.getElementById('configure_listener');
    const listenerOptions = document.getElementById('listener_options');
    if (configureListenerCheckbox && listenerOptions) {
        configureListenerCheckbox.addEventListener('change', function() {
            if (this.checked) {
                listenerOptions.style.display = 'block';
            } else {
                listenerOptions.style.display = 'none';
            }
        });
        
        // Initial state
        listenerOptions.style.display = configureListenerCheckbox.checked ? 'block' : 'none';
    }
    
    // Toggle custom script options based on checkbox
    const useCustomScriptCheckbox = document.getElementById('use_custom_script');
    const customScriptOptions = document.getElementById('custom_script_options');
    if (useCustomScriptCheckbox && customScriptOptions) {
        useCustomScriptCheckbox.addEventListener('change', function() {
            if (this.checked) {
                customScriptOptions.style.display = 'block';
            } else {
                customScriptOptions.style.display = 'none';
            }
        });
        
        // Initial state
        customScriptOptions.style.display = useCustomScriptCheckbox.checked ? 'block' : 'none';
    }
    
    // Script library integration
    const scriptFromLibraryAlert = document.getElementById('scriptFromLibraryAlert');
    const scriptLibraryName = document.getElementById('scriptLibraryName');
    const clearLibraryScriptBtn = document.getElementById('clearLibraryScript');
    const scriptLibraryIdField = document.getElementById('script_library_id');
    
    // Check if a script template was selected from the library
    if (sessionStorage.getItem('scriptTemplate')) {
        try {
            const scriptTemplate = JSON.parse(sessionStorage.getItem('scriptTemplate'));
            
            // Auto-check the custom script checkbox
            if (useCustomScriptCheckbox) {
                useCustomScriptCheckbox.checked = true;
                customScriptOptions.style.display = 'block';
            }
            
            // Set the script content and language
            if (customScriptTextarea) {
                customScriptTextarea.value = scriptTemplate.code;
            }
            
            if (scriptLanguageSelect) {
                scriptLanguageSelect.value = scriptTemplate.language;
            }
            
            // Show the "using script from library" alert
            if (scriptFromLibraryAlert && scriptLibraryName) {
                scriptFromLibraryAlert.style.display = 'block';
                scriptLibraryName.textContent = scriptTemplate.name;
                
                // Set the script library ID in the hidden field
                if (scriptLibraryIdField && scriptTemplate.id) {
                    scriptLibraryIdField.value = scriptTemplate.id;
                }
            }
        } catch (e) {
            console.error('Error loading script template from session storage:', e);
        }
    }
    
    // Clear library script button
    if (clearLibraryScriptBtn) {
        clearLibraryScriptBtn.addEventListener('click', function() {
            // Clear session storage
            sessionStorage.removeItem('scriptTemplate');
            
            // Hide the alert
            if (scriptFromLibraryAlert) {
                scriptFromLibraryAlert.style.display = 'none';
            }
            
            // Clear the script library ID
            if (scriptLibraryIdField) {
                scriptLibraryIdField.value = '';
            }
            
            // Clear the script content but keep the language
            if (customScriptTextarea && scriptLanguageSelect) {
                setCodeTemplate(scriptLanguageSelect.value);
            }
        });
    }
    
    // Script language selector change handler
    const scriptLanguageSelect = document.getElementById('script_language');
    const customScriptTextarea = document.getElementById('custom_script');
    if (scriptLanguageSelect && customScriptTextarea) {
        scriptLanguageSelect.addEventListener('change', function() {
            const language = this.value;
            const currentText = customScriptTextarea.value.trim();
            
            // Only add template if there's no text
            if (!currentText) {
                setCodeTemplate(language);
            }
        });
    }
    
    // Function to set code template based on language
    function setCodeTemplate(language) {
        let template = '';
        
        switch (language) {
            case 'bash':
                template = `#!/bin/bash
# Custom script for zero-day payload
# Environment variables available:
# - $HOSTNAME: Target system hostname
# - $IP: Target system IP address
# - $USERNAME: Current user
# - $OSINFO: Operating system information

echo "Executing custom payload script..."
# Add your custom code here
`;
                break;
            case 'python':
                template = `#!/usr/bin/env python3
# Custom script for zero-day payload
# Environment variables available:
import os
import sys

# Display system information
print("Executing custom Python payload...")
print(f"Hostname: {os.environ.get('HOSTNAME', 'unknown')}")
print(f"IP Address: {os.environ.get('IP', 'unknown')}")
print(f"Current User: {os.environ.get('USERNAME', 'unknown')}")
print(f"OS Info: {os.environ.get('OSINFO', 'unknown')}")

# Add your custom code here
`;
                break;
            case 'javascript':
                template = `// Custom JavaScript for zero-day payload
// Environment variables available through process.env

console.log("Executing custom JavaScript payload...");
console.log("Hostname:", process.env.HOSTNAME || "unknown");
console.log("IP Address:", process.env.IP || "unknown");
console.log("Current User:", process.env.USERNAME || "unknown");
console.log("OS Info:", process.env.OSINFO || "unknown");

// Add your custom code here
`;
                break;
            case 'powershell':
                template = `# Custom PowerShell script for zero-day payload
# Environment variables available:
# - $env:HOSTNAME: Target system hostname
# - $env:IP: Target system IP address
# - $env:USERNAME: Current user
# - $env:OSINFO: Operating system information

Write-Host "Executing custom PowerShell payload..."
Write-Host "Hostname: $env:HOSTNAME"
Write-Host "IP Address: $env:IP"
Write-Host "Current User: $env:USERNAME"
Write-Host "OS Info: $env:OSINFO"

# Add your custom code here
`;
                break;
        }
        
        customScriptTextarea.value = template;
    }
    
    // Form submission validation
    const analyzeForm = document.getElementById('analyzeForm');
    if (analyzeForm) {
        analyzeForm.addEventListener('submit', function(event) {
            // Validate payload content or file upload
            if (!payloadContent.value.trim() && (!payloadFileInput || !payloadFileInput.files || !payloadFileInput.files.length)) {
                event.preventDefault();
                alert('Please enter payload content or upload a file before analyzing.');
                return false;
            }
            
            // Auto-generate name if empty
            if (!payloadNameInput.value.trim()) {
                // Auto-generate a name based on type if empty
                const selectedType = document.querySelector('input[name="payload_type"]:checked').value;
                payloadNameInput.value = `${selectedType.charAt(0).toUpperCase() + selectedType.slice(1)} Payload`;
            }
            
            // Validate listener configuration if enabled
            const configureListenerCheckbox = document.getElementById('configure_listener');
            if (configureListenerCheckbox && configureListenerCheckbox.checked) {
                const listenerHost = document.getElementById('listener_host');
                if (!listenerHost.value.trim()) {
                    event.preventDefault();
                    alert('Please enter a Listener Host/IP address.');
                    listenerHost.focus();
                    return false;
                }
                
                // Validate port is in valid range
                const listenerPort = document.getElementById('listener_port');
                const portValue = parseInt(listenerPort.value);
                if (isNaN(portValue) || portValue < 1 || portValue > 65535) {
                    event.preventDefault();
                    alert('Please enter a valid port number (1-65535).');
                    listenerPort.focus();
                    return false;
                }
                
                // Validate callback interval is reasonable
                const listenerInterval = document.getElementById('listener_interval');
                const intervalValue = parseInt(listenerInterval.value);
                if (isNaN(intervalValue) || intervalValue < 10 || intervalValue > 86400) {
                    event.preventDefault();
                    alert('Please enter a valid callback interval (10-86400 seconds).');
                    listenerInterval.focus();
                    return false;
                }
                
                // Ensure at least one data type is selected
                const dataCheckboxes = [
                    document.getElementById('callback_data_hostname'),
                    document.getElementById('callback_data_ip'),
                    document.getElementById('callback_data_user'),
                    document.getElementById('callback_data_os')
                ];
                
                if (!dataCheckboxes.some(cb => cb && cb.checked)) {
                    event.preventDefault();
                    alert('Please select at least one type of data to report.');
                    return false;
                }
            }
            
            // Validate custom script if enabled
            const useCustomScriptCheckbox = document.getElementById('use_custom_script');
            if (useCustomScriptCheckbox && useCustomScriptCheckbox.checked) {
                const customScript = document.getElementById('custom_script');
                if (!customScript.value.trim()) {
                    event.preventDefault();
                    alert('Please enter your custom script code.');
                    customScript.focus();
                    return false;
                }
                
                // Check if script looks dangerous
                const dangerousPatterns = [
                    /rm\s+(-rf|--no-preserve-root)/i,  // Dangerous rm commands
                    /mkfs/i,                           // Format commands
                    /dd\s+if=/i                        // Disk operations
                ];
                
                for (const pattern of dangerousPatterns) {
                    if (pattern.test(customScript.value)) {
                        const confirmDelete = confirm('Your script contains potentially dangerous commands. Are you sure you want to proceed?');
                        if (!confirmDelete) {
                            event.preventDefault();
                            return false;
                        }
                        break;
                    }
                }
            }
            
            // Add a loading indicator or disable the button to prevent multiple submissions
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Analyzing...';
            submitBtn.disabled = true;
            
            return true;
        });
    }
});
