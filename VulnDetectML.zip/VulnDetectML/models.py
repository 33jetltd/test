from app import db
from datetime import datetime
import json

class ZeroDayNews(db.Model):
    """Model to store news about zero-day vulnerabilities"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    vulnerability_type = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(20), nullable=False)  # low, medium, high, critical
    published_date = db.Column(db.DateTime, default=datetime.utcnow)
    source = db.Column(db.String(100), nullable=True)
    url = db.Column(db.String(255), nullable=True)
    
    def __repr__(self):
        return f"<ZeroDayNews {self.title}>"

class ZeroDayCategory(db.Model):
    """Model to store categories of zero-day vulnerabilities with code examples"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    code_examples = db.Column(db.Text, nullable=False)  # JSON-encoded list of examples
    severity = db.Column(db.String(20), nullable=False)  # low, medium, high, critical
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<ZeroDayCategory {self.name}>"

class Payload(db.Model):
    """Model to store payload data and analysis results"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    content_type = db.Column(db.String(50), nullable=False)
    size = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    analyzed = db.Column(db.Boolean, default=False)
    
    # Analysis results
    anomaly_score = db.Column(db.Float, nullable=True)
    is_anomalous = db.Column(db.Boolean, nullable=True)
    cluster_id = db.Column(db.Integer, nullable=True)
    
    # Relationships
    vulnerabilities = db.relationship('Vulnerability', backref='payload', lazy=True)
    
    def __repr__(self):
        return f"<Payload {self.name}>"

class Vulnerability(db.Model):
    """Model to store detected vulnerabilities"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(20), nullable=False)  # low, medium, high, critical
    confidence = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    payload_id = db.Column(db.Integer, db.ForeignKey('payload.id'), nullable=False)
    
    def __repr__(self):
        return f"<Vulnerability {self.name}>"

class TrainingSession(db.Model):
    """Model to store training session information"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="running")  # running, completed, failed
    anomaly_model_path = db.Column(db.String(255), nullable=True)
    clustering_model_path = db.Column(db.String(255), nullable=True)
    num_samples = db.Column(db.Integer, nullable=False, default=0)
    performance_metrics = db.Column(db.Text, nullable=True)
    
    def __repr__(self):
        return f"<TrainingSession {self.name}>"

class Feature(db.Model):
    """Model to store extracted features from payloads"""
    id = db.Column(db.Integer, primary_key=True)
    payload_id = db.Column(db.Integer, db.ForeignKey('payload.id'), nullable=False)
    # Store features as JSON in the database
    features = db.Column(db.Text, nullable=False)  # JSON string of features
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Create a relationship to the payload
    payload = db.relationship('Payload', backref=db.backref('features', lazy=True))
    
    def __repr__(self):
        return f"<Feature for Payload {self.payload_id}>"
        
class ScriptTemplate(db.Model):
    """Model to store script templates for the script library"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    code = db.Column(db.Text, nullable=False)
    language = db.Column(db.String(50), nullable=False)  # bash, python, javascript, powershell
    category = db.Column(db.String(50), nullable=False)  # data collection, persistence, lateral movement, etc.
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<ScriptTemplate {self.name}>"
        
    def to_dict(self):
        """Convert the script template to a dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'code': self.code,
            'language': self.language,
            'category': self.category,
            'tags': self.tags.split(',') if self.tags else [],
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
