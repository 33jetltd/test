"""
Utility functions for the ML engine.

This module provides various helper functions used across the ML engine,
including data conversion, normalization, and other utility functions.
"""

import logging
import numpy as np
import json
import math
from collections import defaultdict
from collections import Counter

logger = logging.getLogger(__name__)

def calculate_entropy(data):
    """
    Calculate Shannon entropy of data.
    
    Args:
        data (str): Input string
        
    Returns:
        float: Shannon entropy value
    """
    if not data:
        return 0
    
    # Count occurrences of each character
    counts = Counter(data)
    
    # Calculate probabilities for each character
    length = len(data)
    probabilities = [count / length for count in counts.values()]
    
    # Calculate entropy using Shannon's formula
    entropy = -sum(p * math.log2(p) for p in probabilities)
    
    return entropy

def flatten_dict(d, parent_key='', sep='_'):
    """
    Flatten a nested dictionary into a single-level dictionary.
    
    Args:
        d (dict): Dictionary to flatten
        parent_key (str): Key of the parent dictionary
        sep (str): Separator between keys
        
    Returns:
        dict: Flattened dictionary
    """
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep).items())
        else:
            items.append((new_key, v))
    return dict(items)

def get_feature_vector(features_list):
    """
    Convert a list of feature dictionaries to a feature matrix.
    
    This function handles:
    - Flattening nested dictionaries
    - Ensuring all samples have the same features
    - Converting non-numeric values to numeric
    - Handling missing values
    
    Args:
        features_list (list): List of feature dictionaries
        
    Returns:
        numpy.ndarray: Feature matrix
    """
    if not features_list:
        return np.array([])
    
    # Flatten all dictionaries
    flat_features = [flatten_dict(features) for features in features_list]
    
    # Collect all unique keys
    all_keys = set()
    for features in flat_features:
        all_keys.update(features.keys())
    
    # Sort keys for consistent ordering
    sorted_keys = sorted(all_keys)
    
    # Create feature matrix
    X = np.zeros((len(flat_features), len(sorted_keys)))
    
    # Fill the matrix
    for i, features in enumerate(flat_features):
        for j, key in enumerate(sorted_keys):
            # Get the value, default to 0 if missing
            value = features.get(key, 0)
            
            # Convert to numeric if possible
            if isinstance(value, (int, float)):
                X[i, j] = value
            elif isinstance(value, bool):
                X[i, j] = 1 if value else 0
            elif isinstance(value, str):
                try:
                    X[i, j] = float(value)
                except ValueError:
                    # For non-convertible strings, use a hash function
                    X[i, j] = hash(value) % 1000000 / 1000000.0
            else:
                # For other types, use 0
                X[i, j] = 0
    
    return X

def normalize_features(X):
    """
    Normalize features to have zero mean and unit variance.
    
    Args:
        X (numpy.ndarray): Feature matrix
        
    Returns:
        numpy.ndarray: Normalized feature matrix
    """
    # Calculate mean and standard deviation for each feature
    mean = np.mean(X, axis=0)
    std = np.std(X, axis=0)
    
    # Replace zero standard deviation with 1 to avoid division by zero
    std[std == 0] = 1
    
    # Normalize
    X_norm = (X - mean) / std
    
    return X_norm

def serialize_model_results(results, model_type):
    """
    Serialize model results to JSON.
    
    Args:
        results (dict): Results from model
        model_type (str): Type of model
        
    Returns:
        str: JSON string of results
    """
    # Convert numpy types to Python types
    def convert_numpy(obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_numpy(item) for item in obj]
        else:
            return obj
    
    converted_results = convert_numpy(results)
    converted_results["model_type"] = model_type
    
    return json.dumps(converted_results)

def deserialize_model_results(json_str):
    """
    Deserialize model results from JSON.
    
    Args:
        json_str (str): JSON string of results
        
    Returns:
        dict: Deserialized results
    """
    try:
        return json.loads(json_str)
    except Exception as e:
        logger.error(f"Error deserializing model results: {str(e)}")
        return {}

def calculate_metrics(y_true, y_pred):
    """
    Calculate various metrics for model evaluation.
    
    Args:
        y_true (array-like): True labels
        y_pred (array-like): Predicted labels
        
    Returns:
        dict: Dictionary of metrics
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    
    # Convert to binary labels if needed
    if len(np.unique(y_true)) > 2:
        logger.warning("Converting multi-class labels to binary for metric calculation")
        y_true = (y_true != 0).astype(int)
    if len(np.unique(y_pred)) > 2:
        y_pred = (y_pred != 0).astype(int)
    
    # Calculate confusion matrix elements
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    
    # Calculate metrics
    accuracy = (tp + tn) / (tp + fp + tn + fn) if (tp + fp + tn + fn) > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    return {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1),
        "true_positives": int(tp),
        "false_positives": int(fp),
        "true_negatives": int(tn),
        "false_negatives": int(fn)
    }

def format_time_elapsed(seconds):
    """
    Format time elapsed in a human-readable format.
    
    Args:
        seconds (float): Time elapsed in seconds
        
    Returns:
        str: Formatted time string
    """
    if seconds < 60:
        return f"{seconds:.2f} seconds"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.2f} minutes"
    else:
        hours = seconds / 3600
        return f"{hours:.2f} hours"
