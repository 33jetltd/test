"""
Machine Learning Engine for Zero-Day Vulnerability Detection.

This package provides the core functionality for detecting zero-day vulnerabilities
in payloads using machine learning techniques including feature extraction,
anomaly detection, and clustering.
"""

# Make version info available
__version__ = "0.1.0"
