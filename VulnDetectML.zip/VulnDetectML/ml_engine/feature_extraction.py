"""
Feature extraction from payloads.

This module implements various techniques to extract features from different
types of payloads that can be used for anomaly detection and clustering.
"""

import logging
import json
import numpy as np
import re
import base64
from collections import Counter
from app import db
from models import Payload, Feature

logger = logging.getLogger(__name__)

# Common patterns to look for in payloads
SUSPICIOUS_PATTERNS = [
    r'eval\s*\(', r'exec\s*\(', r'system\s*\(', r'os\.', r'subprocess',  # Code execution
    r'SELECT.+FROM', r'INSERT.+INTO', r'UPDATE.+SET', r'DROP\s+TABLE',    # SQL patterns
    r'<script>', r'javascript:', r'onerror=', r'onload=',                 # XSS patterns
    r'../../', r'/etc/passwd', r'C:\\Windows\\',                          # Path traversal
    r'(?:\x00|\\0|%00)',                                                  # Null bytes
    r'\\x[0-9a-fA-F]{2}',                                                 # Hex encoding
    r'multipart/form-data',                                               # File upload
    r'\$\{\s*[^}]*\}', r'\$\(\s*[^)]*\)',                                # Template injection
    r'window\.', r'document\.cookie',                                     # Browser objects
    r'function\s*\(', r'=>\s*\{',                                         # JavaScript functions
]

# Load-bearing numbers for payload analysis (prime numbers, buffer sizes, etc.)
SIGNIFICANT_NUMBERS = [16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192]

def extract_features_from_payload(payload_id):
    """
    Extract features from a payload stored in the database.
    
    Args:
        payload_id (int): ID of the payload in the database
        
    Returns:
        dict: Dictionary of extracted features
    """
    # Retrieve the payload from the database
    payload = Payload.query.get(payload_id)
    if not payload:
        logger.error(f"Payload with ID {payload_id} not found")
        raise ValueError(f"Payload with ID {payload_id} not found")
    
    logger.info(f"Extracting features for payload {payload.name}")
    
    # Extract features based on payload type
    if payload.content_type == 'json':
        features = extract_json_features(payload.content)
    elif payload.content_type == 'xml':
        features = extract_xml_features(payload.content)
    elif payload.content_type == 'binary':
        features = extract_binary_features(payload.content)
    elif payload.content_type == 'script':
        features = extract_script_features(payload.content)
    else:
        # Default to text features
        features = extract_text_features(payload.content)
    
    # Add common features
    features.update(extract_common_features(payload.content))
    
    # Store the extracted features in the database
    try:
        # Check if features already exist for this payload
        existing_feature = Feature.query.filter_by(payload_id=payload_id).first()
        
        if existing_feature:
            # Update existing feature
            existing_feature.features = json.dumps(features)
        else:
            # Create new feature
            feature = Feature(
                payload_id=payload_id,
                features=json.dumps(features)
            )
            db.session.add(feature)
        
        db.session.commit()
        logger.info(f"Features extracted and stored for payload {payload.name}")
    except Exception as e:
        logger.error(f"Error storing features: {str(e)}")
        db.session.rollback()
        raise
    
    return features

def extract_common_features(content):
    """
    Extract features common to all payload types with advanced detection for exploitation patterns.
    
    Args:
        content (str): Payload content
        
    Returns:
        dict: Dictionary of enhanced features for better zero-day detection
    """
    features = {}
    
    # Basic statistical features
    features['length'] = len(content)
    features['entropy'] = calculate_entropy(content)
    
    # Character distribution
    char_counts = Counter(content)
    features['unique_chars'] = len(char_counts)
    features['char_diversity'] = features['unique_chars'] / max(1, features['length'])
    
    # Enhanced pattern detection
    pattern_matches = {}
    for pattern_name, pattern in enumerate(SUSPICIOUS_PATTERNS):
        matches = re.findall(pattern, content, re.IGNORECASE)
        pattern_matches[f'pattern_{pattern_name}'] = len(matches)
    
    features['suspicious_pattern_count'] = sum(pattern_matches.values())
    features['suspicious_patterns'] = pattern_matches
    
    # Calculate block-level entropy (to detect encrypted/compressed sections)
    block_size = 64
    block_entropies = []
    for i in range(0, len(content), block_size):
        block = content[i:i+block_size]
        if len(block) >= 16:  # Only calculate for reasonably sized blocks
            block_entropies.append(calculate_entropy(block))
    
    if block_entropies:
        features['mean_block_entropy'] = sum(block_entropies) / len(block_entropies)
        features['max_block_entropy'] = max(block_entropies)
        features['min_block_entropy'] = min(block_entropies)
        features['entropy_variance'] = np.var(block_entropies) if len(block_entropies) > 1 else 0
    else:
        features['mean_block_entropy'] = 0
        features['max_block_entropy'] = 0
        features['min_block_entropy'] = 0
        features['entropy_variance'] = 0
    
    # Advanced reverse shell detection
    reverse_shell_patterns = [
        r'socket\s*\(', r'bind\s*\(', r'listen\s*\(', r'accept\s*\(',  # Socket operations
        r'connect\s*\(', r'recv\s*\(', r'send\s*\(',                   # Connection operations
        r'nc\s+-[el]', r'netcat', r'ncat',                             # Netcat variants
        r'bash\s+-i', r'/bin/sh', r'/bin/bash',                        # Shell spawning
        r'python\s+-c', r'perl\s+-e', r'ruby\s+-e',                    # Command execution via scripting languages
        r'powershell.*-e', r'powershell.*-enc',                        # PowerShell encoding
        r'meterpreter', r'metasploit', r'payload',                     # Common attack framework terms
        r'reverse_tcp', r'reverse_http', r'bind_tcp',                  # Common payload types
        r'cmd\.exe', r'child_process', r'spawn',                       # Process creation
        r'execve', r'system', r'popen', r'execlp'                      # System execution calls
    ]
    
    reverse_shell_count = 0
    for pattern in reverse_shell_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        reverse_shell_count += len(matches)
    
    features['reverse_shell_indicator_count'] = reverse_shell_count
    
    # Data exfiltration detection
    exfil_patterns = [
        r'curl\s+', r'wget\s+', r'ftp\s+',                             # Network transfer tools
        r'ssh\s+', r'scp\s+', r'sftp\s+',                              # Secure transport 
        r'https?://[^\s]+',                                            # URLs
        r'base64\s*\(', r'base64_encode', r'btoa\(',                   # Encoding functions
        r'encrypt', r'compress', r'zip', r'gzip',                      # Data transformation
        r'dns', r'icmp', r'udp',                                       # Alternative protocols
        r'cookie', r'localstore', r'storage\.set'                      # Browser storage
    ]
    
    exfil_count = 0
    for pattern in exfil_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        exfil_count += len(matches)
    
    features['data_exfiltration_indicator_count'] = exfil_count
    
    # Persistence mechanism detection
    persistence_patterns = [
        r'crontab', r'at\s+', r'schtasks',                             # Scheduled tasks
        r'registry', r'HKEY_', r'regedit',                             # Registry operations
        r'startup', r'/etc/init', r'systemd', r'service',              # System services
        r'autorun', r'autoruns',                                       # Autorun mechanisms
        r'hook', r'callback', r'listener',                             # Event hooks
        r'daemon', r'background', r'detach'                            # Background processes
    ]
    
    persistence_count = 0
    for pattern in persistence_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        persistence_count += len(matches)
    
    features['persistence_indicator_count'] = persistence_count
    
    # Obfuscation detection
    obfuscation_patterns = [
        r'eval\s*\(', r'atob\s*\(', r'btoa\s*\(',                      # Encoding/evaluation
        r'fromCharCode', r'charCodeAt',                                # Character code conversion
        r'unescape\s*\(', r'escape\s*\(',                              # URL encoding/decoding
        r'parseInt\s*\(.*,\s*16\)', r'toString\s*\(.*,\s*16\)',         # Base conversion
        r'\\u[0-9a-fA-F]{4}', r'\\x[0-9a-fA-F]{2}',                    # Unicode/hex escapes
        r'\+\s*[\'"]\s*\+', r'split\s*\(\s*[\'"][^\'"]+', r'join\s*\(' # String splitting/joining
    ]
    
    obfuscation_count = 0
    for pattern in obfuscation_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        obfuscation_count += len(matches)
    
    features['obfuscation_indicator_count'] = obfuscation_count
    
    # Check for high byte frequency (indicative of binary/encrypted data)
    high_byte_count = sum(1 for c in content if ord(c) > 127)
    features['high_byte_ratio'] = high_byte_count / max(1, len(content))
    
    # Detect sequences of control characters (potential shellcode)
    control_char_count = sum(1 for c in content if ord(c) < 32 and c not in '\t\n\r')
    features['control_char_ratio'] = control_char_count / max(1, len(content))
    
    # Detect potential XOR obfuscation
    xor_patterns = []
    for key in range(1, 256):
        if len(content) >= 8:  # Check at least 8 bytes for pattern
            sample = ''.join(chr(ord(c) ^ key) for c in content[:8])
            if re.search(r'[a-zA-Z]{3,}', sample):  # Look for readable text after XOR
                xor_patterns.append(key)
    
    features['potential_xor_keys'] = len(xor_patterns)
    
    # Detect long continuous sequences (potential payloads)
    longest_seq = 0
    current_seq = 0
    for i in range(1, len(content)):
        if abs(ord(content[i]) - ord(content[i-1])) <= 1:
            current_seq += 1
            longest_seq = max(longest_seq, current_seq)
        else:
            current_seq = 0
    
    features['longest_sequential_bytes'] = longest_seq
    
    # Check connection to significant numbers
    for num in SIGNIFICANT_NUMBERS:
        if len(content) == num or len(content) % num == 0:
            features[f'length_match_{num}'] = 1
        else:
            features[f'length_match_{num}'] = 0
    
    # Compute overall exploitation score
    features['exploitation_score'] = (
        features['suspicious_pattern_count'] * 0.2 + 
        features['reverse_shell_indicator_count'] * 0.3 + 
        features['data_exfiltration_indicator_count'] * 0.2 + 
        features['persistence_indicator_count'] * 0.15 + 
        features['obfuscation_indicator_count'] * 0.15
    )
    
    return features

def extract_text_features(content):
    """
    Extract features from text payloads.
    
    Args:
        content (str): Text payload content
        
    Returns:
        dict: Dictionary of text features
    """
    features = {}
    
    # Line statistics
    lines = content.split('\n')
    features['line_count'] = len(lines)
    features['avg_line_length'] = sum(len(line) for line in lines) / max(1, len(lines))
    
    # Word statistics
    words = re.findall(r'\w+', content)
    features['word_count'] = len(words)
    features['unique_words'] = len(set(words))
    features['word_diversity'] = features['unique_words'] / max(1, features['word_count'])
    
    # Symbol statistics
    symbols = re.findall(r'[^\w\s]', content)
    features['symbol_count'] = len(symbols)
    features['symbol_ratio'] = features['symbol_count'] / max(1, len(content))
    
    # Special characters
    features['special_char_count'] = sum(1 for c in content if not c.isalnum() and not c.isspace())
    features['numeric_char_count'] = sum(1 for c in content if c.isdigit())
    features['uppercase_char_count'] = sum(1 for c in content if c.isupper())
    
    return features

def extract_json_features(content):
    """
    Extract features from JSON payloads.
    
    Args:
        content (str): JSON payload content
        
    Returns:
        dict: Dictionary of JSON features
    """
    features = {}
    
    try:
        # Parse JSON
        json_data = json.loads(content)
        
        # Structure complexity
        features['json_depth'] = get_json_depth(json_data)
        features['json_breadth'] = get_json_breadth(json_data)
        features['json_size'] = get_json_size(json_data)
        
        # Key statistics
        all_keys = extract_json_keys(json_data)
        features['key_count'] = len(all_keys)
        features['unique_key_count'] = len(set(all_keys))
        
        # Value statistics
        all_values = extract_json_values(json_data)
        features['string_value_count'] = sum(1 for v in all_values if isinstance(v, str))
        features['numeric_value_count'] = sum(1 for v in all_values if isinstance(v, (int, float)))
        features['boolean_value_count'] = sum(1 for v in all_values if isinstance(v, bool))
        features['null_value_count'] = sum(1 for v in all_values if v is None)
        features['array_value_count'] = sum(1 for v in all_values if isinstance(v, list))
        features['object_value_count'] = sum(1 for v in all_values if isinstance(v, dict))
        
    except json.JSONDecodeError:
        # If JSON is malformed, set error features
        features['json_parse_error'] = True
        features['json_depth'] = 0
        features['json_breadth'] = 0
        features['json_size'] = 0
        features['key_count'] = 0
        features['unique_key_count'] = 0
    
    return features

def extract_xml_features(content):
    """
    Extract features from XML payloads.
    
    Args:
        content (str): XML payload content
        
    Returns:
        dict: Dictionary of XML features
    """
    features = {}
    
    # Tag statistics
    tags = re.findall(r'<([^/!][^>]*)>', content)
    features['tag_count'] = len(tags)
    features['unique_tag_count'] = len(set(tags))
    
    # Attribute statistics
    attributes = re.findall(r'(\w+)=["\'](.*?)["\']', content)
    features['attribute_count'] = len(attributes)
    features['unique_attribute_count'] = len(set(attr[0] for attr in attributes))
    
    # Structure statistics
    features['closing_tag_count'] = len(re.findall(r'</\w+>', content))
    features['self_closing_tag_count'] = len(re.findall(r'/>', content))
    features['comment_count'] = len(re.findall(r'<!--.*?-->', content, re.DOTALL))
    features['cdata_count'] = len(re.findall(r'<!\[CDATA\[.*?\]\]>', content, re.DOTALL))
    
    # Nesting depth approximation
    open_tags = 0
    max_depth = 0
    for char in content:
        if char == '<':
            open_tags += 1
            max_depth = max(max_depth, open_tags)
        elif char == '>':
            open_tags = max(0, open_tags - 1)
    
    features['estimated_xml_depth'] = max_depth
    
    return features

def extract_binary_features(content):
    """
    Extract features from binary payloads.
    
    Args:
        content (str): Binary payload content (base64 encoded)
        
    Returns:
        dict: Dictionary of binary features
    """
    features = {}
    
    try:
        # Try to decode base64 content
        binary_data = base64.b64decode(content)
        
        # Byte distribution
        byte_counts = Counter(binary_data)
        features['unique_bytes'] = len(byte_counts)
        features['byte_diversity'] = features['unique_bytes'] / max(1, len(binary_data))
        
        # Statistical features
        features['binary_entropy'] = calculate_entropy(binary_data.decode('latin-1'))
        features['binary_length'] = len(binary_data)
        
        # Special byte sequences
        features['null_byte_count'] = binary_data.count(0)
        features['ff_byte_count'] = binary_data.count(255)
        
        # Check for executable markers
        features['has_mz_header'] = b'MZ' in binary_data[:4]
        features['has_elf_header'] = b'\x7fELF' in binary_data[:4]
        features['has_pdf_header'] = b'%PDF' in binary_data[:8]
        features['has_png_header'] = b'\x89PNG' in binary_data[:8]
        
    except Exception:
        # If binary decoding fails, set error features
        features['binary_decode_error'] = True
        features['binary_length'] = len(content)
        features['unique_bytes'] = 0
        features['byte_diversity'] = 0
    
    return features

def extract_script_features(content):
    """
    Extract features specific to script payloads.
    
    Args:
        content (str): Script payload content
        
    Returns:
        dict: Dictionary of script features
    """
    features = {}
    
    # Function statistics
    functions = re.findall(r'function\s+(\w+)\s*\(', content)
    features['function_count'] = len(functions)
    features['unique_function_count'] = len(set(functions))
    
    # Variable statistics
    variables = re.findall(r'var\s+(\w+)', content)
    features['variable_count'] = len(variables)
    features['unique_variable_count'] = len(set(variables))
    
    # Control flow statements
    features['if_count'] = len(re.findall(r'\bif\s*\(', content))
    features['for_count'] = len(re.findall(r'\bfor\s*\(', content))
    features['while_count'] = len(re.findall(r'\bwhile\s*\(', content))
    features['try_count'] = len(re.findall(r'\btry\s*\{', content))
    
    # Import/require statements
    features['import_count'] = len(re.findall(r'\bimport\b', content))
    features['require_count'] = len(re.findall(r'\brequire\s*\(', content))
    
    # Potentially dangerous functions
    features['eval_count'] = len(re.findall(r'\beval\s*\(', content))
    features['exec_count'] = len(re.findall(r'\bexec\s*\(', content))
    features['system_count'] = len(re.findall(r'\bsystem\s*\(', content))
    
    return features

def calculate_entropy(data):
    """
    Calculate Shannon entropy of data.
    
    Args:
        data (str): Input string
        
    Returns:
        float: Shannon entropy value
    """
    if not data:
        return 0
    
    entropy = 0
    for x in range(256):
        p_x = data.count(chr(x)) / len(data)
        if p_x > 0:
            entropy += -p_x * np.log2(p_x)
    
    return entropy

def get_json_depth(obj, current_depth=0):
    """
    Calculate the maximum nesting depth of a JSON object.
    
    Args:
        obj: JSON object
        current_depth (int): Current depth level
        
    Returns:
        int: Maximum nesting depth
    """
    if isinstance(obj, dict):
        if not obj:
            return current_depth
        return max(get_json_depth(v, current_depth + 1) for v in obj.values())
    elif isinstance(obj, list):
        if not obj:
            return current_depth
        return max(get_json_depth(item, current_depth + 1) for item in obj)
    else:
        return current_depth

def get_json_breadth(obj):
    """
    Calculate the maximum breadth (number of items at any level) of a JSON object.
    
    Args:
        obj: JSON object
        
    Returns:
        int: Maximum breadth
    """
    if isinstance(obj, dict):
        max_breadth = len(obj)
        for v in obj.values():
            if isinstance(v, (dict, list)):
                max_breadth = max(max_breadth, get_json_breadth(v))
        return max_breadth
    elif isinstance(obj, list):
        max_breadth = len(obj)
        for item in obj:
            if isinstance(item, (dict, list)):
                max_breadth = max(max_breadth, get_json_breadth(item))
        return max_breadth
    else:
        return 1

def get_json_size(obj):
    """
    Count the total number of elements in a JSON object.
    
    Args:
        obj: JSON object
        
    Returns:
        int: Total number of elements
    """
    if isinstance(obj, dict):
        count = len(obj)
        for v in obj.values():
            if isinstance(v, (dict, list)):
                count += get_json_size(v)
        return count
    elif isinstance(obj, list):
        count = len(obj)
        for item in obj:
            if isinstance(item, (dict, list)):
                count += get_json_size(item)
        return count
    else:
        return 1

def extract_json_keys(obj, prefix=""):
    """
    Extract all keys from a JSON object.
    
    Args:
        obj: JSON object
        prefix (str): Current key prefix
        
    Returns:
        list: List of all keys
    """
    keys = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            full_key = f"{prefix}.{k}" if prefix else k
            keys.append(full_key)
            if isinstance(v, (dict, list)):
                keys.extend(extract_json_keys(v, full_key))
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, (dict, list)):
                keys.extend(extract_json_keys(item, f"{prefix}[{i}]"))
    return keys

def extract_json_values(obj):
    """
    Extract all values from a JSON object.
    
    Args:
        obj: JSON object
        
    Returns:
        list: List of all values
    """
    values = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                values.append(v)
                values.extend(extract_json_values(v))
            else:
                values.append(v)
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, (dict, list)):
                values.append(item)
                values.extend(extract_json_values(item))
            else:
                values.append(item)
    return values
