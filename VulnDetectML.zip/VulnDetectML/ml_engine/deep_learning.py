"""
Deep Learning Module for Zero-Day Vulnerability Detection.

This module implements advanced deep learning models for identifying
zero-day vulnerabilities in payloads, including neural networks,
transformer-based models, and sequence analyzers.
"""

import os
import json
import logging
import pickle
import numpy as np
import time
from datetime import datetime

# Import deep learning frameworks
import tensorflow as tf
from tensorflow import keras
from keras import layers, models, optimizers
from keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# Local imports
from ml_engine.utils import flatten_dict, calculate_metrics, get_feature_vector
from ml_engine.feature_extraction import extract_enhanced_features

logger = logging.getLogger(__name__)

# Ensure models directory exists
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models')
DEEP_LEARNING_DIR = os.path.join(MODEL_DIR, 'deep_learning')

def ensure_model_dir():
    """Ensure the model directory exists"""
    os.makedirs(DEEP_LEARNING_DIR, exist_ok=True)


class SequenceEncoder:
    """Encode text/code sequences for deep learning models"""
    
    def __init__(self, max_length=1000, vocab_size=10000):
        self.max_length = max_length
        self.vocab_size = vocab_size
        self.tokenizer = None
        
    def fit(self, texts):
        """Fit the tokenizer on a list of texts"""
        from tensorflow.keras.preprocessing.text import Tokenizer
        from tensorflow.keras.preprocessing.sequence import pad_sequences
        
        self.tokenizer = Tokenizer(num_words=self.vocab_size)
        self.tokenizer.fit_on_texts(texts)
        return self
        
    def transform(self, texts):
        """Transform texts to sequences"""
        from tensorflow.keras.preprocessing.sequence import pad_sequences
        
        if self.tokenizer is None:
            raise ValueError("Tokenizer not fitted. Call fit() first.")
        
        sequences = self.tokenizer.texts_to_sequences(texts)
        padded_sequences = pad_sequences(sequences, maxlen=self.max_length)
        return padded_sequences
    
    def save(self, path):
        """Save the tokenizer to disk"""
        with open(path, 'wb') as f:
            pickle.dump(self.tokenizer, f)
            
    def load(self, path):
        """Load the tokenizer from disk"""
        with open(path, 'rb') as f:
            self.tokenizer = pickle.load(f)
        return self


def build_lstm_model(input_shape, num_classes=1):
    """Build an LSTM model for sequence classification"""
    model = keras.Sequential([
        layers.Embedding(input_dim=10000, output_dim=128, input_length=input_shape[0]),
        layers.SpatialDropout1D(0.2),
        layers.Bidirectional(layers.LSTM(64, return_sequences=True)),
        layers.Bidirectional(layers.LSTM(32)),
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.3),
        layers.Dense(num_classes, activation='sigmoid' if num_classes == 1 else 'softmax')
    ])
    
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy' if num_classes == 1 else 'categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model


def build_cnn_model(input_shape, num_classes=1):
    """Build a CNN model for payload analysis"""
    model = keras.Sequential([
        layers.Embedding(input_dim=10000, output_dim=128, input_length=input_shape[0]),
        layers.Conv1D(128, 5, activation='relu'),
        layers.MaxPooling1D(5),
        layers.Conv1D(128, 5, activation='relu'),
        layers.MaxPooling1D(5),
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.4),
        layers.Dense(num_classes, activation='sigmoid' if num_classes == 1 else 'softmax')
    ])
    
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy' if num_classes == 1 else 'categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model


def build_transformer_model(input_shape, num_classes=1):
    """Build a Transformer model for payload analysis"""
    
    # Define Transformer block
    def transformer_block(inputs, head_size, num_heads, ff_dim, dropout=0):
        # Multi-head self-attention
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=head_size
        )(inputs, inputs)
        attention_output = layers.Dropout(dropout)(attention_output)
        attention_output = layers.LayerNormalization(epsilon=1e-6)(inputs + attention_output)
        
        # Feed-forward network
        ffn_output = layers.Dense(ff_dim, activation="relu")(attention_output)
        ffn_output = layers.Dense(inputs.shape[-1])(ffn_output)
        ffn_output = layers.Dropout(dropout)(ffn_output)
        sequence_output = layers.LayerNormalization(epsilon=1e-6)(attention_output + ffn_output)
        
        return sequence_output
    
    # Define model
    inputs = layers.Input(shape=input_shape)
    embedding_layer = layers.Embedding(input_dim=10000, output_dim=128)(inputs)
    embedding_layer = layers.PositionalEncoding()(embedding_layer)
    
    x = transformer_block(embedding_layer, head_size=64, num_heads=2, ff_dim=128, dropout=0.1)
    x = transformer_block(x, head_size=64, num_heads=2, ff_dim=128, dropout=0.1)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dropout(0.1)(x)
    outputs = layers.Dense(num_classes, activation="sigmoid" if num_classes == 1 else "softmax")(x)
    
    model = keras.Model(inputs=inputs, outputs=outputs)
    
    model.compile(
        optimizer="adam",
        loss="binary_crossentropy" if num_classes == 1 else "categorical_crossentropy",
        metrics=["accuracy"],
    )
    
    return model


# Define a custom positional encoding layer for transformers
class PositionalEncoding(layers.Layer):
    def __init__(self, position=10000, **kwargs):
        self.position = position
        super(PositionalEncoding, self).__init__(**kwargs)
        
    def build(self, input_shape):
        _, sequence_length, d_model = input_shape
        self.pos_encoding = self.positional_encoding(sequence_length, d_model)
        super(PositionalEncoding, self).build(input_shape)
    
    def call(self, inputs):
        return inputs + self.pos_encoding[:, :tf.shape(inputs)[1], :]
    
    def positional_encoding(self, position, d_model):
        # Create encodings for each position and dimension
        angle_rads = self.get_angles(
            np.arange(position)[:, np.newaxis],
            np.arange(d_model)[np.newaxis, :],
            d_model
        )
        
        # Apply sin to even indices
        angle_rads[:, 0::2] = np.sin(angle_rads[:, 0::2])
        
        # Apply cos to odd indices
        angle_rads[:, 1::2] = np.cos(angle_rads[:, 1::2])
        
        pos_encoding = angle_rads[np.newaxis, ...]
        
        return tf.cast(pos_encoding, dtype=tf.float32)
    
    def get_angles(self, pos, i, d_model):
        angle_rates = 1 / np.power(10000, (2 * (i // 2)) / np.float32(d_model))
        return pos * angle_rates
        
    def get_config(self):
        config = super(PositionalEncoding, self).get_config()
        config.update({
            'position': self.position
        })
        return config


# Register the custom layer
keras.utils.get_custom_objects()['PositionalEncoding'] = PositionalEncoding


class DeepPayloadClassifier:
    """Deep Learning Classifier for Payload Analysis"""
    
    def __init__(self, model_type='lstm'):
        """
        Initialize the classifier with the specified model type
        
        Args:
            model_type (str): Type of model to use:
                            - 'lstm': LSTM Neural Network (default)
                            - 'cnn': Convolutional Neural Network
                            - 'transformer': Transformer Model
        """
        self.model_type = model_type
        self.model = None
        self.encoder = SequenceEncoder()
        self.history = None
        self.trained = False
        ensure_model_dir()
        
        # Log initialization of specific model type
        logger.info(f"Initializing DeepPayloadClassifier with model type: {model_type}")
        
    def preprocess_data(self, payloads, labels=None):
        """Preprocess payload data for deep learning models"""
        # Extract text content from payloads
        content_list = [payload.content for payload in payloads]
        
        # Fit or transform sequences
        if not self.encoder.tokenizer:
            self.encoder.fit(content_list)
        
        X = self.encoder.transform(content_list)
        
        if labels is not None:
            return X, np.array(labels)
        return X
    
    def build_model(self, input_shape, num_classes=1):
        """Build a deep learning model based on the specified type"""
        if self.model_type == 'lstm':
            return build_lstm_model(input_shape, num_classes)
        elif self.model_type == 'cnn':
            return build_cnn_model(input_shape, num_classes)
        elif self.model_type == 'transformer':
            return build_transformer_model(input_shape, num_classes)
        else:
            raise ValueError(f"Unsupported model type: {self.model_type}")
    
    def train(self, payloads, labels, validation_split=0.2, epochs=20, batch_size=32):
        """Train the deep learning model on payload data"""
        # Preprocess data
        X, y = self.preprocess_data(payloads, labels)
        
        # Build model
        self.model = self.build_model(X.shape[1:], num_classes=1)
        
        # Set up callbacks
        model_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_model.h5")
        callbacks = [
            EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True),
            ModelCheckpoint(filepath=model_path, save_best_only=True),
            ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=3)
        ]
        
        # Train model
        self.history = self.model.fit(
            X, y,
            validation_split=validation_split,
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks
        )
        
        # Save encoder
        encoder_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_encoder.pkl")
        self.encoder.save(encoder_path)
        
        self.trained = True
        return self.history
    
    def predict(self, payloads):
        """Predict anomalies in payloads"""
        if not self.trained or self.model is None:
            self.load()
            
        X = self.preprocess_data(payloads)
        predictions = self.model.predict(X)
        
        # Return predictions
        return predictions
    
    def save(self):
        """Save the model and encoder"""
        if not self.trained or self.model is None:
            raise ValueError("Model not trained yet.")
            
        # Save model
        model_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_model.h5")
        self.model.save(model_path)
        
        # Save encoder
        encoder_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_encoder.pkl")
        self.encoder.save(encoder_path)
        
        # Save metadata
        metadata = {
            'model_type': self.model_type,
            'trained': self.trained,
            'saved_at': datetime.now().isoformat()
        }
        
        metadata_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_metadata.json")
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f)
            
        return model_path
    
    def load(self, model_path=None, encoder_path=None):
        """Load the model and encoder"""
        try:
            # Default paths
            if model_path is None:
                model_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_model.h5")
            if encoder_path is None:
                encoder_path = os.path.join(DEEP_LEARNING_DIR, f"{self.model_type}_encoder.pkl")
                
            # Load model
            if os.path.exists(model_path):
                self.model = keras.models.load_model(
                    model_path, 
                    custom_objects={'PositionalEncoding': PositionalEncoding}
                )
                
                # Load encoder
                if os.path.exists(encoder_path):
                    self.encoder.load(encoder_path)
                    
                self.trained = True
                logger.info(f"Successfully loaded {self.model_type} model and encoder.")
                return True
            else:
                logger.warning(f"No saved {self.model_type} model found.")
                return False
        except Exception as e:
            logger.error(f"Error loading {self.model_type} model: {str(e)}")
            return False


class AdvancedAnomalyDetection:
    """Advanced deep learning based anomaly detection"""
    
    def __init__(self, model_type='ensemble'):
        """
        Initialize advanced anomaly detection with multiple model types
        
        Args:
            model_type (str): Type of model setup to use:
                            - 'ensemble': Use all available models (LSTM, CNN, Transformer)
                            - 'lstm': Use only LSTM model
                            - 'cnn': Use only CNN model
                            - 'transformer': Use only Transformer model
        """
        self.model_type = model_type
        self.models = {}
        self.trained = False
        ensure_model_dir()
        
        # Log model initialization
        logger.info(f"Initializing AdvancedAnomalyDetection with model type: {model_type}")
        
        # Initialize different model types
        if model_type == 'ensemble':
            # Use all model types for ensemble detection
            self.models['lstm'] = DeepPayloadClassifier('lstm')
            self.models['cnn'] = DeepPayloadClassifier('cnn')
            self.models['transformer'] = DeepPayloadClassifier('transformer')
            logger.info(f"Created ensemble with 3 models: LSTM, CNN, and Transformer")
        else:
            # Use single specified model type
            self.models[model_type] = DeepPayloadClassifier(model_type)
            logger.info(f"Created single model configuration with {model_type}")
    
    def train(self, payloads, labels, validation_split=0.2, epochs=20, batch_size=32):
        """Train all models in the ensemble"""
        results = {}
        
        for model_name, model in self.models.items():
            logger.info(f"Training {model_name} model...")
            history = model.train(payloads, labels, validation_split, epochs, batch_size)
            results[model_name] = {
                'val_accuracy': max(history.history['val_accuracy']),
                'val_loss': min(history.history['val_loss'])
            }
            logger.info(f"Completed training {model_name} model.")
            
        self.trained = True
        return results
    
    def predict(self, payloads, threshold=0.5):
        """
        Get predictions from all models and combine them
        
        Args:
            payloads (list): List of payload objects to analyze
            threshold (float): Threshold for anomaly detection
            
        Returns:
            dict: Combined predictions and scores
        """
        if not self.trained:
            loaded = self.load()
            if not loaded:
                logger.error("Failed to load models for prediction")
                return None
            
        # Log prediction request
        logger.info(f"Getting predictions for {len(payloads)} payloads with {self.model_type} model(s)")
        
        # Get predictions from each model
        predictions = {}
        all_scores = []
        
        for model_name, model in self.models.items():
            try:
                logger.info(f"Running predictions with {model_name} model")
                scores = model.predict(payloads)
                predictions[model_name] = scores
                all_scores.append(scores)
            except Exception as e:
                logger.error(f"Error getting predictions from {model_name} model: {str(e)}")
        
        # Combine predictions (simple averaging for now)
        if all_scores:
            # For single model type, just use its predictions
            if len(all_scores) == 1:
                combined_scores = all_scores[0]
            else:
                # For ensemble, average all model scores
                combined_scores = np.mean(all_scores, axis=0)
                
            # Log prediction results
            logger.info(f"Generated predictions with {len(self.models)} models")
            
            # Convert to binary predictions
            binary_predictions = (combined_scores > threshold).astype(int)
            
            # Return both scores and binary predictions
            return {
                'scores': combined_scores,
                'predictions': binary_predictions,
                'individual_model_scores': predictions,
                'threshold': threshold,
                'model_type': self.model_type
            }
        else:
            logger.error("No predictions available from any model.")
            return None
    
    def save(self):
        """Save all models in the ensemble"""
        paths = {}
        
        for model_name, model in self.models.items():
            try:
                path = model.save()
                paths[model_name] = path
            except Exception as e:
                logger.error(f"Error saving {model_name} model: {str(e)}")
                
        # Save metadata
        metadata = {
            'model_type': self.model_type,
            'trained': self.trained,
            'models': list(self.models.keys()),
            'saved_at': datetime.now().isoformat()
        }
        
        metadata_path = os.path.join(DEEP_LEARNING_DIR, f"advanced_anomaly_metadata.json")
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f)
            
        return paths
    
    def load(self):
        """Load all models in the ensemble"""
        success = True
        
        # Try to load metadata
        metadata_path = os.path.join(DEEP_LEARNING_DIR, f"advanced_anomaly_metadata.json")
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                self.model_type = metadata.get('model_type', 'ensemble')
                
                # Initialize models based on metadata
                self.models = {}
                for model_name in metadata.get('models', []):
                    self.models[model_name] = DeepPayloadClassifier(model_name)
        
        # Load each model
        for model_name, model in self.models.items():
            model_success = model.load()
            success = success and model_success
            
        self.trained = success
        return success


def detect_anomalies_deep(payload_ids, threshold=0.5, model_type='ensemble'):
    """
    Detect anomalies in payloads using deep learning models.
    
    Args:
        payload_ids (list): List of payload IDs to analyze
        threshold (float): Threshold for anomaly detection
        model_type (str): Type of deep learning model to use:
                         - 'lstm': LSTM Neural Network
                         - 'cnn': Convolutional Neural Network
                         - 'transformer': Transformer Model
                         - 'ensemble': Use all models and combine results (default)
        
    Returns:
        dict: Dictionary mapping payload IDs to anomaly results
    """
    from models import Payload, db
    
    try:
        # Get payloads from database
        payloads = Payload.query.filter(Payload.id.in_(payload_ids)).all()
        
        if not payloads:
            logger.warning(f"No payloads found with IDs: {payload_ids}")
            return {}
        
        # Choose the detector based on the model type
        logger.info(f"Using deep learning model type: {model_type}")
        
        if model_type == 'ensemble':
            # Initialize advanced anomaly detector with ensemble of models
            detector = AdvancedAnomalyDetection(model_type='ensemble')
        else:
            # Initialize a single model detector
            detector = DeepPayloadClassifier(model_type=model_type)
        
        # Try to load the model
        loaded = detector.load()
        if not loaded:
            logger.warning(f"No trained {model_type} models found. Using fallback detection.")
            # Try ensemble method as fallback if a specific model was requested
            if model_type != 'ensemble':
                logger.info("Trying ensemble method as fallback...")
                return detect_anomalies_deep(payload_ids, threshold, 'ensemble')
            else:
                # Fall back to traditional methods
                from ml_engine.anomaly_detection import detect_anomalies
                return detect_anomalies(payload_ids)
        
        # Get predictions
        results = detector.predict(payloads)
        
        if results is None:
            logger.error(f"Failed to get predictions from {model_type} model.")
            return {}
        
        # Format results
        anomaly_results = {}
        for i, payload in enumerate(payloads):
            # Handle different result formats between ensemble and single models
            if model_type == 'ensemble' and isinstance(results, dict):
                anomaly_score = float(results['scores'][i][0])
                is_anomalous = bool(results['predictions'][i][0])
            else:
                # Single model format
                anomaly_score = float(results[i][0] if isinstance(results[i], list) else results[i])
                is_anomalous = anomaly_score > threshold
            
            # Store results
            anomaly_results[payload.id] = {
                "anomaly_score": anomaly_score,
                "is_anomalous": is_anomalous,
                "threshold": threshold,
                "method": f"deep_learning_{model_type}",
                "confidence": float(max(anomaly_score, 1.0 - anomaly_score))
            }
            
            # Update payload in database
            payload.anomaly_score = anomaly_score
            payload.is_anomalous = is_anomalous
            db.session.add(payload)
            
        db.session.commit()
        
        return anomaly_results
    
    except Exception as e:
        logger.error(f"Error detecting anomalies with deep learning: {str(e)}")
        # Fallback to traditional methods
        from ml_engine.anomaly_detection import detect_anomalies
        return detect_anomalies(payload_ids)


def train_deep_learning_models(training_session_id, sample_size=100):
    """
    Train deep learning models for anomaly detection.
    
    Args:
        training_session_id (int): ID of the training session
        sample_size (int): Number of samples to generate if needed
        
    Returns:
        dict: Training results and performance metrics
    """
    from models import Payload, TrainingSession, db
    from ml_engine.model_training import prepare_training_data
    
    try:
        # Update training session status
        training_session = TrainingSession.query.get(training_session_id)
        if not training_session:
            raise ValueError(f"Training session with ID {training_session_id} not found")
        
        training_session.status = "running"
        db.session.commit()
        
        logger.info(f"Starting deep learning model training with session {training_session_id}")
        
        # Prepare training data
        X_train, X_val, y_train, y_val = prepare_training_data(sample_size, use_advanced_features=True)
        
        # Get payloads from database for the samples in X_train
        normal_payloads = Payload.query.filter_by(is_anomalous=False).limit(int(sample_size * 0.7)).all()
        anomalous_payloads = Payload.query.filter_by(is_anomalous=True).limit(int(sample_size * 0.3)).all()
        
        training_payloads = normal_payloads + anomalous_payloads
        training_labels = [0] * len(normal_payloads) + [1] * len(anomalous_payloads)
        
        # Initialize and train deep learning models
        detector = AdvancedAnomalyDetection()
        training_results = detector.train(
            payloads=training_payloads,
            labels=training_labels,
            validation_split=0.2,
            epochs=20,
            batch_size=32
        )
        
        # Save models
        model_paths = detector.save()
        
        # Update training session
        training_session.completed_at = datetime.now()
        training_session.status = "completed"
        training_session.num_samples = len(training_payloads)
        training_session.performance_metrics = json.dumps(training_results)
        
        # Update paths
        if 'lstm' in model_paths:
            training_session.anomaly_model_path = model_paths['lstm']
        if 'transformer' in model_paths:
            training_session.clustering_model_path = model_paths['transformer']
        
        db.session.commit()
        
        logger.info(f"Completed deep learning model training with session {training_session_id}")
        
        return {
            "session_id": training_session_id,
            "status": "completed",
            "num_samples": len(training_payloads),
            "model_paths": model_paths,
            "results": training_results
        }
    
    except Exception as e:
        logger.error(f"Error training deep learning models: {str(e)}")
        
        # Update training session to failed
        if 'training_session' in locals() and training_session:
            training_session.status = "failed"
            training_session.completed_at = datetime.now()
            db.session.commit()
        
        raise e