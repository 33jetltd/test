"""
Attack Surface Visualization Module.

This module provides functionality to analyze the attack surface of a system
and generate graph data for visualization.
"""

import json
import random
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)

def generate_attack_surface_data():
    """
    Generate attack surface data for visualization.
    
    This function analyzes the system components, vulnerabilities, and payloads
    to generate a graph representation of the attack surface.
    
    Returns:
        dict: Graph data containing nodes and links for visualization
    """
    try:
        from app import db
        from models import Payload, Vulnerability, ZeroDayCategory
        
        # Get data from database
        payloads = Payload.query.filter_by(analyzed=True).all()
        vulnerabilities = Vulnerability.query.all()
        vulnerability_categories = ZeroDayCategory.query.all()
        
        # Initialize graph data
        nodes = []
        links = []
        node_ids = {}  # For tracking created nodes
        node_counter = 1
        
        # Add system components
        system_components = [
            {
                "name": "Web Application Server",
                "description": "Main application server hosting the web interface",
                "role": "Application hosting",
                "vulnerabilityCount": 0,
                "connections": []
            },
            {
                "name": "Database Server",
                "description": "PostgreSQL database server storing application data",
                "role": "Data storage",
                "vulnerabilityCount": 0,
                "connections": []
            },
            {
                "name": "File Storage",
                "description": "File storage system for uploaded payloads",
                "role": "Content storage",
                "vulnerabilityCount": 0,
                "connections": []
            },
            {
                "name": "Authentication Service",
                "description": "Service handling user authentication",
                "role": "Security",
                "vulnerabilityCount": 0,
                "connections": []
            },
            {
                "name": "API Gateway",
                "description": "Gateway for external API integrations",
                "role": "Integration",
                "vulnerabilityCount": 0,
                "connections": []
            }
        ]
        
        # Add system component nodes
        for component in system_components:
            node_id = f"system_{node_counter}"
            node_ids[component["name"]] = node_id
            
            nodes.append({
                "id": node_id,
                "type": "system",
                "label": component["name"],
                "description": component["description"],
                "role": component["role"],
                "vulnerabilityCount": component["vulnerabilityCount"],
                "connections": component["connections"]
            })
            
            node_counter += 1
        
        # Add vulnerability category nodes
        for category in vulnerability_categories:
            node_id = f"category_{node_counter}"
            node_ids[category.name] = node_id
            
            # Determine severity
            severity = category.severity.lower()
            
            nodes.append({
                "id": node_id,
                "type": "vulnerability",
                "label": category.name,
                "description": category.description,
                "severity": severity.capitalize(),
                "affectedComponent": "Multiple Components",
                "confidence": 95,
                "exploitationPaths": [
                    f"Via {category.name} in web application",
                    f"Through uploaded payloads containing {category.name}"
                ]
            })
            
            # Link vulnerability category to system components
            affected_components = get_affected_components_for_category(category.name)
            for component_name in affected_components:
                if component_name in node_ids:
                    links.append({
                        "source": node_id,
                        "target": node_ids[component_name],
                        "value": 2
                    })
            
            node_counter += 1
        
        # Add payload nodes
        for payload in payloads:
            if payload.is_anomalous:
                node_id = f"payload_{node_counter}"
                node_ids[f"payload_{payload.id}"] = node_id
                
                nodes.append({
                    "id": node_id,
                    "type": "payload",
                    "label": payload.name,
                    "contentType": payload.content_type,
                    "size": payload.size,
                    "created": payload.created_at.strftime("%Y-%m-%d"),
                    "anomalyScore": round(payload.anomaly_score, 2) if payload.anomaly_score else "N/A",
                    "vulnerabilityCount": len(payload.vulnerabilities),
                    "id": payload.id  # Include the actual payload ID for linking to details
                })
                
                # Link payload to "File Storage" component
                if "File Storage" in node_ids:
                    links.append({
                        "source": node_id,
                        "target": node_ids["File Storage"],
                        "value": 1
                    })
                
                # Link payload to its vulnerabilities
                for vuln in payload.vulnerabilities:
                    vuln_node_id = f"vuln_{node_counter}"
                    node_ids[f"vulnerability_{vuln.id}"] = vuln_node_id
                    
                    # Determine severity
                    severity = vuln.severity.lower()
                    
                    nodes.append({
                        "id": vuln_node_id,
                        "type": "vulnerability",
                        "label": vuln.name,
                        "description": vuln.description,
                        "severity": severity.capitalize(),
                        "affectedComponent": "Payload",
                        "confidence": round(vuln.confidence * 100),
                        "exploitationPaths": [
                            f"Via malicious payload ({payload.name})"
                        ]
                    })
                    
                    # Link vulnerability to payload
                    links.append({
                        "source": vuln_node_id,
                        "target": node_id,
                        "value": 3
                    })
                    
                    # Link vulnerability to appropriate system component
                    affected_component = get_affected_component_for_vulnerability(vuln.name)
                    if affected_component in node_ids:
                        links.append({
                            "source": vuln_node_id,
                            "target": node_ids[affected_component],
                            "value": 2
                        })
                    
                    # Add exploitation node for critical/high vulnerabilities
                    if severity in ["critical", "high"]:
                        exploit_node_id = f"exploit_{node_counter}"
                        node_counter += 1
                        
                        nodes.append({
                            "id": exploit_node_id,
                            "type": "exploit",
                            "label": f"Exploit {vuln.name}",
                            "severity": severity.capitalize(),
                            "description": f"Potential exploitation of {vuln.name}",
                            "requiredAccess": "Remote",
                            "impact": "System compromise",
                            "mitigation": f"Apply patch for {vuln.name}"
                        })
                        
                        # Link exploit to vulnerability
                        links.append({
                            "source": exploit_node_id,
                            "target": vuln_node_id,
                            "value": 4
                        })
                    
                    node_counter += 1
                
                node_counter += 1
        
        # Enhance links between system components to create a more connected graph
        create_system_component_links(nodes, links, node_ids)
        
        return {
            "nodes": nodes,
            "links": links
        }
        
    except Exception as e:
        logger.error(f"Error generating attack surface data: {str(e)}")
        # Return a minimal valid graph in case of error
        return {
            "nodes": [
                {"id": "error", "type": "system", "label": "Error Loading Data", 
                 "description": f"Error: {str(e)}", "role": "Error", "vulnerabilityCount": 0, "connections": []}
            ],
            "links": []
        }

def get_affected_components_for_category(category_name):
    """
    Determine which system components are affected by a vulnerability category.
    
    Args:
        category_name (str): Name of the vulnerability category
        
    Returns:
        list: List of affected component names
    """
    # Map vulnerability categories to affected components
    category_to_components = {
        "Command Injection": ["Web Application Server", "API Gateway"],
        "SQL Injection": ["Database Server", "Web Application Server"],
        "Cross-Site Scripting": ["Web Application Server"],
        "Cross-Site Request Forgery": ["Web Application Server", "Authentication Service"],
        "Remote Code Execution": ["Web Application Server", "File Storage"],
        "Authentication Bypass": ["Authentication Service"],
        "Insecure Direct Object References": ["Web Application Server", "API Gateway"],
        "Security Misconfiguration": ["Web Application Server", "Database Server", "API Gateway"],
        "Sensitive Data Exposure": ["Database Server", "File Storage", "Web Application Server"],
        "Broken Authentication": ["Authentication Service"],
        "XML External Entity": ["API Gateway", "Web Application Server"],
        "Insecure Deserialization": ["Web Application Server", "API Gateway"],
        "Using Components with Known Vulnerabilities": ["Web Application Server", "API Gateway", "Database Server"],
        "Insufficient Logging & Monitoring": ["Web Application Server", "Authentication Service"]
    }
    
    # Return affected components or default to all components if category not found
    return category_to_components.get(category_name, ["Web Application Server"])

def get_affected_component_for_vulnerability(vulnerability_name):
    """
    Determine which system component is most affected by a specific vulnerability.
    
    Args:
        vulnerability_name (str): Name of the vulnerability
        
    Returns:
        str: Name of the most affected component
    """
    # These mappings would be more sophisticated in a real implementation
    if any(term in vulnerability_name.lower() for term in ["sql", "database", "injection", "query"]):
        return "Database Server"
    elif any(term in vulnerability_name.lower() for term in ["auth", "login", "password", "credential"]):
        return "Authentication Service"
    elif any(term in vulnerability_name.lower() for term in ["file", "upload", "storage", "path"]):
        return "File Storage"
    elif any(term in vulnerability_name.lower() for term in ["api", "gateway", "endpoint", "service"]):
        return "API Gateway"
    else:
        return "Web Application Server"

def create_system_component_links(nodes, links, node_ids):
    """
    Create links between system components to represent the system architecture.
    
    Args:
        nodes (list): List of node objects
        links (list): List of link objects
        node_ids (dict): Dictionary mapping component names to node IDs
    """
    # Define architectural relationships between components
    component_relationships = [
        ("Web Application Server", "Database Server", 5),
        ("Web Application Server", "File Storage", 4),
        ("Web Application Server", "Authentication Service", 5),
        ("Web Application Server", "API Gateway", 4),
        ("API Gateway", "Database Server", 3),
        ("Authentication Service", "Database Server", 4)
    ]
    
    # Add links for each relationship
    for source, target, value in component_relationships:
        if source in node_ids and target in node_ids:
            links.append({
                "source": node_ids[source],
                "target": node_ids[target],
                "value": value
            })

def find_attack_paths(source_id, target_id):
    """
    Find possible attack paths between two nodes in the attack surface graph.
    
    Args:
        source_id (str): ID of the source node
        target_id (str): ID of the target node
        
    Returns:
        dict: Dictionary containing paths between the nodes
    """
    try:
        # Get the full graph
        graph_data = generate_attack_surface_data()
        nodes = graph_data["nodes"]
        links = graph_data["links"]
        
        # Build an adjacency list from the links
        adjacency_list = defaultdict(list)
        for link in links:
            # Graph is undirected
            adjacency_list[link["source"]].append(link["target"])
            adjacency_list[link["target"]].append(link["source"])
        
        # Find all paths using BFS
        paths = find_all_paths_bfs(adjacency_list, source_id, target_id)
        
        # Sort paths by length (shortest first)
        paths.sort(key=len)
        
        # Limit to the top 5 paths to avoid overwhelming the UI
        return {"paths": paths[:5]}
        
    except Exception as e:
        logger.error(f"Error finding attack paths: {str(e)}")
        return {"paths": []}

def find_all_paths_bfs(graph, start, end, max_paths=5):
    """
    Find all paths between start and end nodes using BFS.
    
    Args:
        graph (dict): Adjacency list representation of the graph
        start (str): Starting node ID
        end (str): Target node ID
        max_paths (int): Maximum number of paths to find
        
    Returns:
        list: List of paths (each path is a list of node IDs)
    """
    queue = [(start, [start])]
    paths = []
    
    while queue and len(paths) < max_paths:
        (vertex, path) = queue.pop(0)
        
        # Get all adjacent nodes not yet in the path
        for next_node in graph[vertex]:
            if next_node not in path:
                if next_node == end:
                    # We found a path to the end node
                    paths.append(path + [next_node])
                else:
                    # Continue exploring from this node
                    queue.append((next_node, path + [next_node]))
    
    return paths