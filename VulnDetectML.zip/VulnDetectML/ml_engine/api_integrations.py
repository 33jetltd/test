"""
API integrations for external vulnerability and threat intelligence services.

This module provides functionality to interact with external APIs for
retrieving vulnerability data, threat intelligence, and performing
enhanced zero-day detection.
"""

import os
import json
import logging
import requests
import time
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API Configuration
ALIENVAULT_OTX_API_KEY = os.environ.get('ALIENVAULT_OTX_API_KEY')
NETWORKSENTRY_API_KEY = os.environ.get('NETWORKSENTRY_API_KEY')
VULDB_API_KEY = os.environ.get('VULDB_API_KEY')
VIRUSTOTAL_API_KEY = os.environ.get('VIRUSTOTAL_API_KEY')
METASPLOIT_API_KEY = os.environ.get('METASPLOIT_API_KEY')

# API Base URLs
ALIENVAULT_OTX_BASE_URL = 'https://otx.alienvault.com/api/v1'
NETWORKSENTRY_BASE_URL = 'https://api.networksentry.io/v1'
VULDB_BASE_URL = 'https://vuldb.com/api/v1'
VIRUSTOTAL_BASE_URL = 'https://www.virustotal.com/api/v3'

class APIIntegrationError(Exception):
    """Exception raised for errors in API integrations"""
    pass

def check_api_keys():
    """
    Check which API keys are available and return their status.
    
    Returns:
        dict: Dictionary mapping API names to their availability status
    """
    api_status = {
        'alienvault_otx': ALIENVAULT_OTX_API_KEY is not None,
        'networksentry': NETWORKSENTRY_API_KEY is not None,
        'vuldb': VULDB_API_KEY is not None,
        'virustotal': VIRUSTOTAL_API_KEY is not None,
        'metasploit': METASPLOIT_API_KEY is not None
    }
    
    # Log available APIs
    available_apis = [api for api, status in api_status.items() if status]
    logger.info(f"Available APIs: {', '.join(available_apis)}")
    
    return api_status

def get_alienvault_pulses(days_back=7, limit=20):
    """
    Get recent threat intelligence pulses from AlienVault OTX.
    
    Args:
        days_back (int): Number of days to look back
        limit (int): Maximum number of results to return
        
    Returns:
        list: List of pulse dictionaries
    """
    if not ALIENVAULT_OTX_API_KEY:
        logger.warning("AlienVault OTX API key not available")
        return []
    
    headers = {
        'X-OTX-API-KEY': ALIENVAULT_OTX_API_KEY,
        'Content-Type': 'application/json'
    }
    
    # Calculate date for the query
    since_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%dT%H:%M:%S')
    
    try:
        # Get recent pulses
        url = f"{ALIENVAULT_OTX_BASE_URL}/pulses/subscribed?limit={limit}&modified_since={since_date}"
        logger.info(f"Requesting AlienVault OTX data from URL: {url}")
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code != 200:
            logger.error(f"AlienVault OTX API returned status code {response.status_code}: {response.text}")
            return []
            
        response.raise_for_status()
        
        data = response.json()
        pulses = data.get('results', [])
        
        # Extract and format the relevant information
        formatted_pulses = []
        for pulse in pulses:
            try:
                # Skip pulses that don't involve zero-day or relevant vulnerabilities
                tags = [tag.lower() for tag in pulse.get('tags', [])]
                if not any(keyword in ' '.join(tags) for keyword in ['zero-day', 'zeroday', 'exploit', 'vulnerability', 'cve', 'malware']):
                    continue
                    
                # Validate required fields
                if not pulse.get('name'):
                    logger.warning(f"Skipping pulse without a name: {pulse.get('id', 'unknown')}")
                    continue
                
                formatted_pulse = {
                    'title': pulse.get('name', 'Unknown Threat'),
                    'description': pulse.get('description', 'No description available'),
                    'author': pulse.get('author_name', 'Unknown'),
                    'created': pulse.get('created', datetime.now().isoformat()),
                    'modified': pulse.get('modified', datetime.now().isoformat()),
                    'tags': pulse.get('tags', []),
                    'references': [ref.get('url') for ref in pulse.get('references', []) if ref.get('url')],
                    'indicators': [
                        {
                            'type': ind.get('type', 'unknown'),
                            'indicator': ind.get('indicator', ''),
                            'description': ind.get('description', '')
                        } 
                        for ind in pulse.get('indicators', [])[:5] if ind.get('indicator')  # Limit to first 5 indicators
                    ],
                    'source': 'AlienVault OTX'
                }
            except Exception as e:
                logger.error(f"Error processing AlienVault pulse: {str(e)}")
                continue
            
            # Determine severity based on tags and TLP
            if 'zero-day' in tags or 'zeroday' in tags:
                formatted_pulse['severity'] = 'critical'
            elif 'exploit' in tags:
                formatted_pulse['severity'] = 'high'
            elif 'vulnerability' in tags or 'cve' in tags:
                formatted_pulse['severity'] = 'medium'
            else:
                formatted_pulse['severity'] = 'low'
                
            formatted_pulses.append(formatted_pulse)
        
        logger.info(f"Retrieved {len(formatted_pulses)} threat intelligence pulses from AlienVault OTX")
        return formatted_pulses
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Error retrieving data from AlienVault OTX: {str(e)}")
        return []

def analyze_reverse_shell_patterns(payload_content, content_type):
    """
    Analyze payload for reverse shell patterns using NetworkSentry.
    
    Args:
        payload_content (str): Content of the payload
        content_type (str): Type of the payload (json, xml, text, script)
        
    Returns:
        dict: Analysis results for reverse shell patterns
    """
    if not NETWORKSENTRY_API_KEY:
        logger.warning("NetworkSentry API key not available")
        return {
            'reverse_shell_detected': False,
            'confidence': 0.0,
            'analysis': 'API key not available'
        }
    
    headers = {
        'Authorization': f'Bearer {NETWORKSENTRY_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    # Prepare payload data
    data = {
        'content': payload_content,
        'content_type': content_type,
        'analysis_type': 'reverse_shell'
    }
    
    try:
        url = f"{NETWORKSENTRY_BASE_URL}/analyze"
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        
        result = response.json()
        logger.info(f"Analyzed payload for reverse shell patterns: {result.get('summary')}")
        
        # Format and return the result
        return {
            'reverse_shell_detected': result.get('detected', False),
            'confidence': result.get('confidence', 0.0),
            'patterns': result.get('patterns', []),
            'analysis': result.get('summary', ''),
            'risk_score': result.get('risk_score', 0)
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Error analyzing reverse shell patterns: {str(e)}")
        # Fall back to internal detection mechanism
        return {
            'reverse_shell_detected': _check_reverse_shell_patterns(payload_content, content_type),
            'confidence': 0.7,  # Lower confidence for the internal mechanism
            'analysis': 'Fallback internal analysis',
            'error': str(e)
        }

def _check_reverse_shell_patterns(payload_content, content_type):
    """
    Internal fallback mechanism to check for common reverse shell patterns.
    
    Args:
        payload_content (str): Content of the payload
        content_type (str): Type of the payload
        
    Returns:
        bool: Whether reverse shell patterns were detected
    """
    # Common reverse shell indicators
    indicators = [
        # Bash reverse shells
        'bash -i >& /dev/tcp/', 
        '/bin/bash -i >',
        '0<&196;exec 196<>/dev/tcp/',
        
        # Python reverse shells
        'import socket,subprocess,os',
        'socket.connect((',
        'subprocess.call(["/bin/sh","-i"])',
        
        # Perl reverse shells
        'perl -e \'use Socket',
        'open(STDIN,">&$c")',
        
        # PHP reverse shells
        'php -r \'$sock=fsockopen',
        'exec("/bin/sh -i <&3 >&3 2>&3")',
        
        # Ruby reverse shells
        'ruby -rsocket -e',
        'exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)',
        
        # Netcat reverse shells
        'nc -e /bin/sh',
        'nc -c /bin/sh',
        'ncat -e /bin/sh',
        '/bin/sh | nc',
        'rm -f /tmp/p; mknod /tmp/p p && nc',
        
        # PowerShell reverse shells
        'powershell -nop -c',
        'New-Object System.Net.Sockets.TCPClient',
        '$stream = $client.GetStream()',
        '[System.Text.Encoding]::ASCII.GetString($bytes,0,$i)',
        
        # Common ports used in reverse shells
        'port=4444',
        'port=443',
        ':1337',
        ':4242',
        ':4545',
        
        # Data exfiltration
        'curl -d @',
        'wget --post-data',
        'exfiltrate',
        'data extraction'
    ]
    
    # Check for indicators
    content_lower = payload_content.lower()
    for indicator in indicators:
        if indicator.lower() in content_lower:
            logger.info(f"Detected reverse shell pattern: {indicator}")
            return True
    
    # Script-specific checks
    if content_type == 'script':
        # Check for suspicious script patterns
        suspicious_script_patterns = [
            'while read line;',
            'mkfifo',
            '>/dev/tcp',
            'telnet >',
            'socat',
            'dev/shm',
            '/tmp/',
            'chmod +x',
            'base64 -d'
        ]
        
        for pattern in suspicious_script_patterns:
            if pattern in content_lower:
                logger.info(f"Detected suspicious script pattern: {pattern}")
                return True
    
    return False

def get_vuldb_vulnerabilities(days_back=7, limit=10):
    """
    Get recent vulnerabilities from VulDB.
    
    Args:
        days_back (int): Number of days to look back
        limit (int): Maximum number of results to return
        
    Returns:
        list: List of vulnerability dictionaries
    """
    if not VULDB_API_KEY:
        logger.warning("VulDB API key not available")
        return []
    
    headers = {
        'X-VulDB-ApiKey': VULDB_API_KEY,
        'Content-Type': 'application/json'
    }
    
    # Calculate date for the query
    since_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d')
    
    try:
        # Get recent vulnerabilities
        data = {
            'details': '1',
            'recent': str(limit),
            'mindate': since_date
        }
        
        url = f"{VULDB_BASE_URL}/search"
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        
        result = response.json()
        vulnerabilities = result.get('result', [])
        
        # Format the vulnerabilities
        formatted_vulns = []
        for vuln_id, vuln in vulnerabilities.items():
            # Skip if not an actual vulnerability
            if not vuln_id.isdigit():
                continue
                
            formatted_vuln = {
                'title': vuln.get('entry', {}).get('title'),
                'description': vuln.get('entry', {}).get('description'),
                'vulnerability_type': _determine_vuln_type(vuln),
                'severity': _determine_severity(vuln),
                'published_date': vuln.get('entry', {}).get('date', {}).get('published'),
                'source': 'VulDB',
                'url': f"https://vuldb.com/?id.{vuln_id}"
            }
            formatted_vulns.append(formatted_vuln)
        
        logger.info(f"Retrieved {len(formatted_vulns)} vulnerabilities from VulDB")
        return formatted_vulns
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Error retrieving data from VulDB: {str(e)}")
        return []

def _determine_vuln_type(vuln_data):
    """
    Determine the vulnerability type from VulDB data.
    
    Args:
        vuln_data (dict): Vulnerability data from VulDB
        
    Returns:
        str: Vulnerability type
    """
    # Extract vulnerability type information
    category = vuln_data.get('entry', {}).get('category')
    
    # Map VulDB categories to our vulnerability types
    mapping = {
        'Denial of Service': 'DoS',
        'Cross-Site Scripting': 'XSS',
        'SQL Injection': 'SQL Injection',
        'Code Execution': 'Code Execution',
        'Memory Corruption': 'Memory Corruption',
        'Overflow': 'Buffer Overflow',
        'Bypass': 'Security Bypass',
        'Gain Information': 'Information Disclosure',
        'Gain Privileges': 'Privilege Escalation',
        'Cross-Site Request Forgery': 'CSRF',
        'Directory Traversal': 'Path Traversal',
        'File Inclusion': 'File Inclusion'
    }
    
    for key, value in mapping.items():
        if category and key in category:
            return value
    
    return 'Other'

def scan_file_with_virustotal(file_content, file_name=None):
    """
    Scan a file with VirusTotal API to check for malware or exploits.
    
    Args:
        file_content (bytes or str): Content of the file to scan
        file_name (str, optional): Name of the file
        
    Returns:
        dict: Scan results from VirusTotal
    """
    if not VIRUSTOTAL_API_KEY:
        logger.warning("VirusTotal API key not available")
        return {
            'success': False,
            'detected': False,
            'message': 'API key not available',
            'detection_rate': 0,
            'threat_level': 'unknown'
        }
    
    headers = {'x-apikey': VIRUSTOTAL_API_KEY}
    
    try:
        # Convert string content to bytes if necessary
        if isinstance(file_content, str):
            file_content = file_content.encode('utf-8')
            
        # First, upload the file
        upload_url = f"{VIRUSTOTAL_BASE_URL}/files"
        files = {'file': (file_name or 'payload.bin', file_content)}
        
        response = requests.post(upload_url, headers=headers, files=files)
        response.raise_for_status()
        
        # Get the analysis ID
        result = response.json()
        analysis_id = result.get('data', {}).get('id')
        
        if not analysis_id:
            return {
                'success': False,
                'detected': False,
                'message': 'Failed to get analysis ID',
                'error': 'No analysis ID returned'
            }
            
        # Wait for the analysis to complete (with timeout)
        timeout = time.time() + 60  # 60 seconds timeout
        analysis_url = f"{VIRUSTOTAL_BASE_URL}/analyses/{analysis_id}"
        
        while time.time() < timeout:
            response = requests.get(analysis_url, headers=headers)
            response.raise_for_status()
            
            analysis = response.json()
            status = analysis.get('data', {}).get('attributes', {}).get('status')
            
            if status == 'completed':
                # Analysis is complete, process the results
                stats = analysis.get('data', {}).get('attributes', {}).get('stats', {})
                results = analysis.get('data', {}).get('attributes', {}).get('results', {})
                
                # Calculate detection rates
                malicious = stats.get('malicious', 0)
                suspicious = stats.get('suspicious', 0)
                total = stats.get('total', 0)
                
                detection_rate = (malicious + suspicious) / total if total > 0 else 0
                
                # Determine threat level
                if detection_rate > 0.5:
                    threat_level = 'critical'
                elif detection_rate > 0.2:
                    threat_level = 'high'
                elif detection_rate > 0.05:
                    threat_level = 'medium'
                elif detection_rate > 0:
                    threat_level = 'low'
                else:
                    threat_level = 'safe'
                
                # Extract threat categories
                threat_categories = set()
                for engine, result in results.items():
                    if result.get('category') in ['malicious', 'suspicious']:
                        if 'result' in result:
                            threat_categories.add(result['result'])
                
                return {
                    'success': True,
                    'detected': malicious + suspicious > 0,
                    'total_engines': total,
                    'malicious_detections': malicious,
                    'suspicious_detections': suspicious,
                    'detection_rate': detection_rate,
                    'threat_level': threat_level,
                    'threat_categories': list(threat_categories),
                    'permalink': f"https://www.virustotal.com/gui/file/{analysis.get('meta', {}).get('file_info', {}).get('sha256')}"
                }
            
            # If not completed, wait a bit before checking again
            time.sleep(3)
            
        # If we reach here, the analysis timed out
        return {
            'success': False,
            'detected': False,
            'message': 'Analysis timed out',
            'error': 'Timeout waiting for analysis'
        }
    
    except requests.exceptions.RequestException as e:
        logger.error(f"Error scanning file with VirusTotal: {str(e)}")
        return {
            'success': False,
            'detected': False,
            'message': f'Error communicating with VirusTotal: {str(e)}',
            'error': str(e)
        }

def _determine_severity(vuln_data):
    """
    Determine the severity from VulDB data.
    
    Args:
        vuln_data (dict): Vulnerability data from VulDB
        
    Returns:
        str: Severity level (critical, high, medium, low)
    """
    # Extract CVSS score if available
    cvss = vuln_data.get('entry', {}).get('cvss', {}).get('score')
    
    if cvss:
        try:
            cvss_score = float(cvss)
            if cvss_score >= 9.0:
                return 'critical'
            elif cvss_score >= 7.0:
                return 'high'
            elif cvss_score >= 4.0:
                return 'medium'
            else:
                return 'low'
        except (ValueError, TypeError):
            pass
    
    # Fallback to VulDB's own risk classification
    risk = vuln_data.get('entry', {}).get('risk')
    
    if risk:
        if risk == 5:
            return 'critical'
        elif risk == 4:
            return 'high'
        elif risk == 3:
            return 'medium'
        elif risk <= 2:
            return 'low'
    
    # Default severity if nothing else works
    return 'medium'

def test_api_connections():
    """
    Test connections to all configured APIs.
    
    Returns:
        dict: Dictionary mapping API names to connection status
    """
    connection_status = {}
    
    # Test AlienVault OTX
    if ALIENVAULT_OTX_API_KEY:
        try:
            headers = {'X-OTX-API-KEY': ALIENVAULT_OTX_API_KEY}
            response = requests.get(f"{ALIENVAULT_OTX_BASE_URL}/user/me", headers=headers)
            if response.status_code == 200:
                connection_status['AlienVault OTX'] = {
                    'status': 'connected',
                    'details': 'Successfully connected to AlienVault OTX API'
                }
            else:
                connection_status['AlienVault OTX'] = {
                    'status': 'error',
                    'details': f"API returned status code {response.status_code}"
                }
        except Exception as e:
            connection_status['AlienVault OTX'] = {
                'status': 'error',
                'details': str(e)
            }
    else:
        connection_status['AlienVault OTX'] = {
            'status': 'unavailable',
            'details': 'API key not configured'
        }
    
    # Test NetworkSentry
    if NETWORKSENTRY_API_KEY:
        try:
            headers = {'Authorization': f'Bearer {NETWORKSENTRY_API_KEY}'}
            response = requests.get(f"{NETWORKSENTRY_BASE_URL}/status", headers=headers)
            if response.status_code == 200:
                connection_status['NetworkSentry'] = {
                    'status': 'connected',
                    'details': 'Successfully connected to NetworkSentry API'
                }
            else:
                connection_status['NetworkSentry'] = {
                    'status': 'error',
                    'details': f"API returned status code {response.status_code}"
                }
        except Exception as e:
            connection_status['NetworkSentry'] = {
                'status': 'error',
                'details': str(e)
            }
    else:
        connection_status['NetworkSentry'] = {
            'status': 'unavailable',
            'details': 'API key not configured'
        }
    
    # Test VulDB
    if VULDB_API_KEY:
        try:
            headers = {
                'X-VulDB-ApiKey': VULDB_API_KEY,
                'Content-Type': 'application/json'
            }
            data = {'info': '1'}
            response = requests.post(f"{VULDB_BASE_URL}/info", headers=headers, json=data)
            if response.status_code == 200:
                connection_status['VulDB'] = {
                    'status': 'connected',
                    'details': 'Successfully connected to VulDB API'
                }
            else:
                connection_status['VulDB'] = {
                    'status': 'error',
                    'details': f"API returned status code {response.status_code}"
                }
        except Exception as e:
            connection_status['VulDB'] = {
                'status': 'error',
                'details': str(e)
            }
    else:
        connection_status['VulDB'] = {
            'status': 'unavailable',
            'details': 'API key not configured'
        }
        
    # Test VirusTotal
    if VIRUSTOTAL_API_KEY:
        try:
            headers = {'x-apikey': VIRUSTOTAL_API_KEY}
            response = requests.get(f"{VIRUSTOTAL_BASE_URL}/users/current", headers=headers)
            if response.status_code == 200:
                connection_status['VirusTotal'] = {
                    'status': 'connected',
                    'details': 'Successfully connected to VirusTotal API'
                }
            else:
                connection_status['VirusTotal'] = {
                    'status': 'error',
                    'details': f"API returned status code {response.status_code}"
                }
        except Exception as e:
            connection_status['VirusTotal'] = {
                'status': 'error',
                'details': str(e)
            }
    else:
        connection_status['VirusTotal'] = {
            'status': 'unavailable',
            'details': 'API key not configured'
        }
    
    # Test Metasploit API
    if METASPLOIT_API_KEY:
        try:
            # The URL would be specific to the Metasploit API implementation
            # For this example, we're using a placeholder URL
            headers = {'Authorization': f'Bearer {METASPLOIT_API_KEY}'}
            
            # In a real implementation, this would be a valid endpoint
            # This is just a placeholder for the integration
            response = requests.get("https://api.metasploit.com/api/v1/modules", headers=headers)
            
            if response.status_code == 200:
                connection_status['Metasploit'] = {
                    'status': 'connected',
                    'details': 'Successfully connected to Metasploit API'
                }
            else:
                connection_status['Metasploit'] = {
                    'status': 'error',
                    'details': f"API returned status code {response.status_code}"
                }
        except Exception as e:
            connection_status['Metasploit'] = {
                'status': 'error',
                'details': str(e)
            }
    else:
        connection_status['Metasploit'] = {
            'status': 'unavailable',
            'details': 'API key not configured'
        }
    
    return connection_status