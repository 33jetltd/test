"""
Anomaly detection for identifying abnormal payloads.

This module implements machine learning algorithms for anomaly detection
to identify potential zero-day vulnerabilities in payloads.
"""

import logging
import pickle
import os
import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.covariance import EllipticEnvelope
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score
from app import db
from models import Payload
from ml_engine.feature_extraction import extract_features_from_payload
from ml_engine.utils import get_feature_vector

logger = logging.getLogger(__name__)

# Default model paths
DEFAULT_MODEL_DIR = "ml_models"
DEFAULT_ISOLATION_FOREST_PATH = os.path.join(DEFAULT_MODEL_DIR, "isolation_forest.pkl")
DEFAULT_LOF_PATH = os.path.join(DEFAULT_MODEL_DIR, "local_outlier_factor.pkl")
DEFAULT_OCSVM_PATH = os.path.join(DEFAULT_MODEL_DIR, "one_class_svm.pkl")
DEFAULT_EE_PATH = os.path.join(DEFAULT_MODEL_DIR, "elliptic_envelope.pkl")
DEFAULT_RF_PATH = os.path.join(DEFAULT_MODEL_DIR, "random_forest.pkl")
DEFAULT_MLP_PATH = os.path.join(DEFAULT_MODEL_DIR, "mlp_classifier.pkl")

def ensure_model_dir():
    """Ensure the model directory exists"""
    if not os.path.exists(DEFAULT_MODEL_DIR):
        os.makedirs(DEFAULT_MODEL_DIR)

def train_anomaly_detection_model(X_train, model_type="isolation_forest", **kwargs):
    """
    Train an anomaly detection model with support for multiple advanced algorithms.
    
    Args:
        X_train (numpy.ndarray): Training data
        model_type (str): Type of model to train. Options include:
                         - isolation_forest: Isolation Forest algorithm
                         - local_outlier_factor: Local Outlier Factor algorithm
                         - one_class_svm: One-Class SVM algorithm
                         - elliptic_envelope: Elliptic Envelope algorithm (statistical)
                         - random_forest: Random Forest classifier (supervised)
                         - mlp: Multi-layer Perceptron neural network (supervised)
        **kwargs: Additional model parameters
        
    Returns:
        object: Trained model
    """
    logger.info(f"Training {model_type} anomaly detection model")
    
    if model_type == "isolation_forest":
        # Isolation Forest parameters
        n_estimators = kwargs.get("n_estimators", 100)
        max_samples = kwargs.get("max_samples", "auto")
        contamination = kwargs.get("contamination", 0.1)
        random_state = kwargs.get("random_state", 42)
        
        model = IsolationForest(
            n_estimators=n_estimators,
            max_samples=max_samples,
            contamination=contamination,
            random_state=random_state
        )
    elif model_type == "local_outlier_factor":
        # Local Outlier Factor parameters
        n_neighbors = kwargs.get("n_neighbors", 20)
        contamination = kwargs.get("contamination", 0.1)
        
        model = LocalOutlierFactor(
            n_neighbors=n_neighbors,
            contamination=contamination,
            novelty=True
        )
    elif model_type == "one_class_svm":
        # One-Class SVM parameters
        nu = kwargs.get("nu", 0.1)
        kernel = kwargs.get("kernel", "rbf")
        gamma = kwargs.get("gamma", "scale")
        
        model = OneClassSVM(
            nu=nu,
            kernel=kernel,
            gamma=gamma
        )
    elif model_type == "elliptic_envelope":
        # Robust covariance parameters
        contamination = kwargs.get("contamination", 0.1)
        random_state = kwargs.get("random_state", 42)
        
        model = EllipticEnvelope(
            contamination=contamination,
            random_state=random_state
        )
    elif model_type == "random_forest":
        # Random Forest parameters (supervised approach with labeled data)
        n_estimators = kwargs.get("n_estimators", 100)
        max_depth = kwargs.get("max_depth", None)
        random_state = kwargs.get("random_state", 42)
        
        model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state
        )
        
        # For supervised models, we need labeled data (y_train)
        y_train = kwargs.get("y_train")
        if y_train is None:
            raise ValueError("y_train must be provided for supervised models")
        
        # Train with both X and y
        return model.fit(X_train, y_train)
    elif model_type == "mlp_classifier":
        # Neural network parameters (supervised approach with labeled data)
        hidden_layer_sizes = kwargs.get("hidden_layer_sizes", (100,))
        max_iter = kwargs.get("max_iter", 1000)
        activation = kwargs.get("activation", "relu")
        random_state = kwargs.get("random_state", 42)
        
        model = MLPClassifier(
            hidden_layer_sizes=hidden_layer_sizes,
            max_iter=max_iter,
            activation=activation,
            random_state=random_state
        )
        
        # For supervised models, we need labeled data (y_train)
        y_train = kwargs.get("y_train")
        if y_train is None:
            raise ValueError("y_train must be provided for supervised models")
        
        # Train with both X and y
        return model.fit(X_train, y_train)
    else:
        raise ValueError(f"Unsupported model type: {model_type}")
    
    # Fit the model
    model.fit(X_train)
    
    return model

def save_anomaly_detection_model(model, model_type="isolation_forest"):
    """
    Save an anomaly detection model to disk.
    
    Args:
        model: Trained model to save
        model_type (str): Type of model being saved
        
    Returns:
        str: Path to the saved model
    """
    ensure_model_dir()
    
    if model_type == "isolation_forest":
        model_path = DEFAULT_ISOLATION_FOREST_PATH
    elif model_type == "local_outlier_factor":
        model_path = DEFAULT_LOF_PATH
    elif model_type == "one_class_svm":
        model_path = DEFAULT_OCSVM_PATH
    elif model_type == "elliptic_envelope":
        model_path = DEFAULT_EE_PATH
    elif model_type == "random_forest":
        model_path = DEFAULT_RF_PATH
    elif model_type == "mlp_classifier":
        model_path = DEFAULT_MLP_PATH
    else:
        model_path = os.path.join(DEFAULT_MODEL_DIR, f"{model_type}.pkl")
    
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    
    logger.info(f"Saved {model_type} model to {model_path}")
    
    return model_path

def load_anomaly_detection_model(model_type="isolation_forest", model_path=None):
    """
    Load an anomaly detection model from disk.
    
    Args:
        model_type (str): Type of model to load
        model_path (str, optional): Custom path to the model file
        
    Returns:
        object: Loaded model
    """
    if model_path is None:
        if model_type == "isolation_forest":
            model_path = DEFAULT_ISOLATION_FOREST_PATH
        elif model_type == "local_outlier_factor":
            model_path = DEFAULT_LOF_PATH
        elif model_type == "one_class_svm":
            model_path = DEFAULT_OCSVM_PATH
        elif model_type == "elliptic_envelope":
            model_path = DEFAULT_EE_PATH
        elif model_type == "random_forest":
            model_path = DEFAULT_RF_PATH
        elif model_type == "mlp_classifier":
            model_path = DEFAULT_MLP_PATH
        else:
            model_path = os.path.join(DEFAULT_MODEL_DIR, f"{model_type}.pkl")
    
    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        
        logger.info(f"Loaded {model_type} model from {model_path}")
        return model
    except FileNotFoundError:
        logger.warning(f"Model file not found: {model_path}")
        return None
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        return None

def detect_anomalies(payload_ids, model_type="isolation_forest", threshold=None):
    """
    Detect anomalies in a set of payloads.
    
    Args:
        payload_ids (list): List of payload IDs to analyze
        model_type (str): Type of model to use
        threshold (float, optional): Custom anomaly score threshold
        
    Returns:
        dict: Dictionary mapping payload IDs to anomaly results
    """
    # Load the model
    model = load_anomaly_detection_model(model_type)
    
    # Use fallback model if no trained model available
    if model is None:
        logger.warning(f"No trained {model_type} model found. Using fallback detection.")
        # Create a simple fallback model
        results = {}
        # For each payload, we'll use a basic heuristic approach instead
        for payload_id in payload_ids:
            results[payload_id] = {
                "is_anomaly": False,
                "anomaly_score": 0.0,
                "using_fallback": True,
                "message": "Using fallback detection (no trained model available)"
            }
        return results
    
    results = {}
    
    # Process payloads in batches
    for payload_id in payload_ids:
        try:
            # Get payload from database
            payload = Payload.query.get(payload_id)
            if not payload:
                logger.warning(f"Payload {payload_id} not found")
                continue
            
            # Extract features from payload
            features_dict = extract_features_from_payload(payload_id)
            
            # Convert features to vector
            X = get_feature_vector([features_dict])
            
            # Detect anomalies
            # Initialize default values
            anomaly_score = 0.0
            is_anomalous = False
            
            # Model-specific detection logic
            if model_type == "isolation_forest":
                # For Isolation Forest, lower (more negative) scores indicate anomalies
                anomaly_scores = -model.decision_function(X)
                anomaly_score = anomaly_scores[0]
                is_anomalous = model.predict(X)[0] == -1
            elif model_type == "local_outlier_factor":
                # For LOF, lower (more negative) scores indicate anomalies
                anomaly_scores = -model.decision_function(X)
                anomaly_score = anomaly_scores[0]
                is_anomalous = model.predict(X)[0] == -1
            elif model_type == "one_class_svm":
                # For One-Class SVM, lower (more negative) scores indicate anomalies
                anomaly_scores = -model.decision_function(X)
                anomaly_score = anomaly_scores[0]
                is_anomalous = model.predict(X)[0] == -1
            elif model_type == "elliptic_envelope":
                # For Elliptic Envelope, lower (more negative) scores indicate anomalies
                anomaly_scores = -model.decision_function(X)
                anomaly_score = anomaly_scores[0]
                is_anomalous = model.predict(X)[0] == -1
            elif model_type == "random_forest" or model_type == "mlp_classifier":
                # For supervised classifiers, use probability scores
                try:
                    # If the model has predict_proba method
                    proba = model.predict_proba(X)
                    # Assuming class 1 is anomalous
                    if proba.shape[1] > 1:
                        anomaly_score = proba[0][1]  # Probability of being anomalous
                    else:
                        anomaly_score = proba[0][0]
                    
                    # Prediction (0 = normal, 1 = anomalous)
                    prediction = model.predict(X)[0]
                    is_anomalous = prediction == 1
                except:
                    # Fallback to simple prediction
                    prediction = model.predict(X)[0]
                    is_anomalous = prediction == 1
                    # Use decision_function if available for score
                    try:
                        anomaly_scores = model.decision_function(X)
                        anomaly_score = anomaly_scores[0]
                    except:
                        anomaly_score = float(is_anomalous)
            
            # Apply custom threshold if provided
            if threshold is not None:
                is_anomalous = anomaly_score > threshold
            
            # Update payload with results
            payload.anomaly_score = float(anomaly_score)
            payload.is_anomalous = bool(is_anomalous)
            payload.analyzed = True
            
            db.session.commit()
            
            # Store results
            results[payload_id] = {
                "anomaly_score": float(anomaly_score),
                "is_anomalous": bool(is_anomalous)
            }
            
            logger.info(f"Payload {payload_id}: anomaly_score={anomaly_score}, is_anomalous={is_anomalous}")
            
        except Exception as e:
            logger.error(f"Error detecting anomalies in payload {payload_id}: {str(e)}")
            db.session.rollback()
    
    return results

def get_anomaly_threshold(model, X_validation, contamination=0.1, y_validation=None):
    """
    Calculate the anomaly score threshold based on validation data.
    
    Args:
        model: Trained anomaly detection model
        X_validation (numpy.ndarray): Validation data
        contamination (float): Expected proportion of anomalies
        y_validation (numpy.ndarray, optional): Validation labels for supervised models
        
    Returns:
        float: Threshold value for anomaly scores
    """
    if isinstance(model, IsolationForest) or isinstance(model, OneClassSVM) or isinstance(model, EllipticEnvelope):
        # For unsupervised models with decision_function
        scores = -model.decision_function(X_validation)
    elif isinstance(model, LocalOutlierFactor):
        # For Local Outlier Factor
        scores = -model.decision_function(X_validation)
    elif isinstance(model, RandomForestClassifier) or isinstance(model, MLPClassifier):
        # For supervised classifiers
        try:
            # Try to use probability scores if available
            proba = model.predict_proba(X_validation)
            if proba.shape[1] > 1:
                # Assuming class 1 is anomalous
                scores = proba[:, 1]
            else:
                scores = proba[:, 0]
        except:
            # Fallback to decision function if available
            try:
                scores = model.decision_function(X_validation)
            except:
                # Last resort: use predictions directly
                preds = model.predict(X_validation)
                scores = np.array([float(p == 1) for p in preds])
        
        # If we have ground truth labels, we can use ROC curve to find optimal threshold
        if y_validation is not None:
            try:
                # Use ROC curve analysis to find the best threshold
                from sklearn.metrics import roc_curve, f1_score
                fpr, tpr, thresholds = roc_curve(y_validation, scores)
                
                # Calculate F1 score for each threshold
                f1_scores = []
                for thresh in thresholds:
                    y_pred = (scores >= thresh).astype(int)
                    f1 = f1_score(y_validation, y_pred)
                    f1_scores.append(f1)
                
                # Find threshold with highest F1 score
                best_idx = np.argmax(f1_scores)
                return thresholds[best_idx]
            except:
                # If ROC analysis fails, fall back to percentile method
                pass
    else:
        logger.warning(f"Unsupported model type for threshold calculation: {type(model)}. Using percentile method.")
    
    # Sort scores and determine threshold using percentile method
    sorted_scores = np.sort(scores)
    threshold_idx = int(len(sorted_scores) * (1 - contamination))
    threshold = sorted_scores[threshold_idx]
    
    return threshold
