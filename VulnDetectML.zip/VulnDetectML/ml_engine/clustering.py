"""
Clustering for grouping similar payloads.

This module implements clustering algorithms to group similar payloads
based on their features, helping to identify patterns in potential
vulnerabilities.
"""

import logging
import pickle
import os
import numpy as np
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering, Birch, SpectralClustering, MeanShift, OPTICS
from sklearn.mixture import GaussianMixture
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from app import db
from models import Payload
from ml_engine.feature_extraction import extract_features_from_payload
from ml_engine.utils import get_feature_vector

logger = logging.getLogger(__name__)

# Default model paths
DEFAULT_MODEL_DIR = "ml_models"
DEFAULT_KMEANS_PATH = os.path.join(DEFAULT_MODEL_DIR, "kmeans.pkl")
DEFAULT_DBSCAN_PATH = os.path.join(DEFAULT_MODEL_DIR, "dbscan.pkl")
DEFAULT_AGGLOM_PATH = os.path.join(DEFAULT_MODEL_DIR, "agglomerative.pkl")
DEFAULT_BIRCH_PATH = os.path.join(DEFAULT_MODEL_DIR, "birch.pkl")
DEFAULT_GMM_PATH = os.path.join(DEFAULT_MODEL_DIR, "gaussian_mixture.pkl")
DEFAULT_SPECTRAL_PATH = os.path.join(DEFAULT_MODEL_DIR, "spectral.pkl")
DEFAULT_MEANSHIFT_PATH = os.path.join(DEFAULT_MODEL_DIR, "meanshift.pkl")
DEFAULT_OPTICS_PATH = os.path.join(DEFAULT_MODEL_DIR, "optics.pkl")

def ensure_model_dir():
    """Ensure the model directory exists"""
    if not os.path.exists(DEFAULT_MODEL_DIR):
        os.makedirs(DEFAULT_MODEL_DIR)

def train_clustering_model(X_train, model_type="kmeans", **kwargs):
    """
    Train a clustering model.
    
    Args:
        X_train (numpy.ndarray): Training data
        model_type (str): Type of model to train
        **kwargs: Additional model parameters
        
    Returns:
        object: Trained model
    """
    logger.info(f"Training {model_type} clustering model")
    
    if model_type == "kmeans":
        # KMeans parameters
        n_clusters = kwargs.get("n_clusters", 5)
        random_state = kwargs.get("random_state", 42)
        
        model = KMeans(
            n_clusters=n_clusters,
            random_state=random_state
        )
    elif model_type == "dbscan":
        # DBSCAN parameters
        eps = kwargs.get("eps", 0.5)
        min_samples = kwargs.get("min_samples", 5)
        
        model = DBSCAN(
            eps=eps,
            min_samples=min_samples
        )
    elif model_type == "agglomerative":
        # Agglomerative Clustering parameters
        n_clusters = kwargs.get("n_clusters", 5)
        linkage = kwargs.get("linkage", "ward")
        
        model = AgglomerativeClustering(
            n_clusters=n_clusters,
            linkage=linkage
        )
    elif model_type == "birch":
        # Birch parameters
        n_clusters = kwargs.get("n_clusters", 5)
        threshold = kwargs.get("threshold", 0.5)
        branching_factor = kwargs.get("branching_factor", 50)
        
        model = Birch(
            n_clusters=n_clusters,
            threshold=threshold,
            branching_factor=branching_factor
        )
    elif model_type == "gaussian_mixture":
        # Gaussian Mixture Model parameters
        n_components = kwargs.get("n_components", 5)
        covariance_type = kwargs.get("covariance_type", "full")
        random_state = kwargs.get("random_state", 42)
        
        model = GaussianMixture(
            n_components=n_components,
            covariance_type=covariance_type,
            random_state=random_state
        )
    elif model_type == "spectral":
        # Spectral Clustering parameters
        n_clusters = kwargs.get("n_clusters", 5)
        n_neighbors = kwargs.get("n_neighbors", 10)
        random_state = kwargs.get("random_state", 42)
        
        model = SpectralClustering(
            n_clusters=n_clusters,
            n_neighbors=n_neighbors,
            random_state=random_state
        )
    elif model_type == "meanshift":
        # Mean Shift parameters
        bandwidth = kwargs.get("bandwidth", None)
        bin_seeding = kwargs.get("bin_seeding", False)
        
        model = MeanShift(
            bandwidth=bandwidth,
            bin_seeding=bin_seeding
        )
    elif model_type == "optics":
        # OPTICS parameters
        min_samples = kwargs.get("min_samples", 5)
        xi = kwargs.get("xi", 0.05)
        
        model = OPTICS(
            min_samples=min_samples,
            xi=xi
        )
    else:
        raise ValueError(f"Unsupported model type: {model_type}")
    
    # Fit the model
    model.fit(X_train)
    
    return model

def save_clustering_model(model, model_type="kmeans"):
    """
    Save a clustering model to disk.
    
    Args:
        model: Trained model to save
        model_type (str): Type of model being saved
        
    Returns:
        str: Path to the saved model
    """
    ensure_model_dir()
    
    if model_type == "kmeans":
        model_path = DEFAULT_KMEANS_PATH
    elif model_type == "dbscan":
        model_path = DEFAULT_DBSCAN_PATH
    elif model_type == "agglomerative":
        model_path = DEFAULT_AGGLOM_PATH
    elif model_type == "birch":
        model_path = DEFAULT_BIRCH_PATH
    elif model_type == "gaussian_mixture":
        model_path = DEFAULT_GMM_PATH
    elif model_type == "spectral":
        model_path = DEFAULT_SPECTRAL_PATH
    elif model_type == "meanshift":
        model_path = DEFAULT_MEANSHIFT_PATH
    elif model_type == "optics":
        model_path = DEFAULT_OPTICS_PATH
    else:
        model_path = os.path.join(DEFAULT_MODEL_DIR, f"{model_type}.pkl")
    
    # For models that don't support pickling or need special handling
    if model_type == "agglomerative":
        model_data = {
            "type": model_type,
            "labels": model.labels_,
            "n_clusters": model.n_clusters,
            "linkage": model.linkage
        }
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
    elif model_type == "spectral":
        model_data = {
            "type": model_type,
            "labels": model.labels_,
            "n_clusters": model.n_clusters,
            "affinity": model.affinity
        }
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
    elif model_type == "meanshift":
        model_data = {
            "type": model_type,
            "labels": model.labels_,
            "cluster_centers": model.cluster_centers_,
            "n_clusters": len(model.cluster_centers_)
        }
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
    elif model_type == "optics":
        model_data = {
            "type": model_type,
            "labels": model.labels_,
            "min_samples": model.min_samples,
            "xi": model.xi,
            "predecessor": model.predecessor_,
            "ordering": model.ordering_
        }
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
    else:
        with open(model_path, 'wb') as f:
            pickle.dump(model, f)
    
    logger.info(f"Saved {model_type} model to {model_path}")
    
    return model_path

def load_clustering_model(model_type="kmeans", model_path=None):
    """
    Load a clustering model from disk.
    
    Args:
        model_type (str): Type of model to load
        model_path (str, optional): Custom path to the model file
        
    Returns:
        object: Loaded model
    """
    if model_path is None:
        if model_type == "kmeans":
            model_path = DEFAULT_KMEANS_PATH
        elif model_type == "dbscan":
            model_path = DEFAULT_DBSCAN_PATH
        elif model_type == "agglomerative":
            model_path = DEFAULT_AGGLOM_PATH
        elif model_type == "birch":
            model_path = DEFAULT_BIRCH_PATH
        elif model_type == "gaussian_mixture":
            model_path = DEFAULT_GMM_PATH
        elif model_type == "spectral":
            model_path = DEFAULT_SPECTRAL_PATH
        elif model_type == "meanshift":
            model_path = DEFAULT_MEANSHIFT_PATH
        elif model_type == "optics":
            model_path = DEFAULT_OPTICS_PATH
        else:
            model_path = os.path.join(DEFAULT_MODEL_DIR, f"{model_type}.pkl")
    
    try:
        with open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        # Handle special cases for models that store parameters instead of the model itself
        if model_type in ["agglomerative", "spectral", "meanshift", "optics"] and isinstance(model_data, dict):
            # We can't directly use the model for prediction in some cases, but we can use the stored parameters
            logger.info(f"Loaded {model_type} model parameters from {model_path}")
            return model_data
        
        logger.info(f"Loaded {model_type} model from {model_path}")
        return model_data
    except FileNotFoundError:
        logger.warning(f"Model file not found: {model_path}")
        return None
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        return None

def cluster_payloads(payload_ids, model_type="kmeans"):
    """
    Cluster a set of payloads.
    
    Args:
        payload_ids (list): List of payload IDs to cluster
        model_type (str): Type of model to use
        
    Returns:
        dict: Dictionary mapping payload IDs to cluster assignments
    """
    # Load the model
    model = load_clustering_model(model_type)
    
    # Use fallback clustering if no trained model available
    if model is None:
        logger.warning(f"No trained {model_type} model found. Using fallback clustering.")
        # Create a simple fallback model where everything is in cluster 0
        results = {}
        for payload_id in payload_ids:
            results[payload_id] = {
                "cluster_id": 0,
                "using_fallback": True,
                "message": "Using fallback clustering (no trained model available)"
            }
            
            # Update payload in database
            try:
                payload = Payload.query.get(payload_id)
                if payload:
                    payload.cluster_id = 0
                    db.session.commit()
            except Exception as e:
                logger.error(f"Error updating payload {payload_id}: {str(e)}")
                db.session.rollback()
                
        return results
    
    results = {}
    
    # Extract features for all payloads
    features_list = []
    valid_payload_ids = []
    
    for payload_id in payload_ids:
        try:
            # Get payload from database
            payload = Payload.query.get(payload_id)
            if not payload:
                logger.warning(f"Payload {payload_id} not found")
                continue
            
            # Extract features from payload
            features_dict = extract_features_from_payload(payload_id)
            
            # Add to list
            features_list.append(features_dict)
            valid_payload_ids.append(payload_id)
            
        except Exception as e:
            logger.error(f"Error extracting features from payload {payload_id}: {str(e)}")
    
    if not features_list:
        logger.warning("No valid payloads to cluster")
        return results
    
    # Convert features to matrix
    X = get_feature_vector(features_list)
    
    # Cluster payloads
    if model_type == "kmeans":
        # For KMeans, use predict method
        clusters = model.predict(X)
    elif model_type == "dbscan":
        # For DBSCAN, we need to run fit_predict again
        # This isn't ideal, but DBSCAN doesn't have a separate predict method
        clusters = model.fit_predict(X)
    elif model_type == "gaussian_mixture":
        # For GMM, use predict method
        clusters = model.predict(X)
    elif model_type == "birch":
        # For Birch, use predict method
        clusters = model.predict(X)
    elif model_type == "agglomerative" and isinstance(model, dict):
        # For AgglomerativeClustering, we need to train a new model
        # since it doesn't support prediction on new data
        agglom = AgglomerativeClustering(
            n_clusters=model.get("n_clusters", 5),
            linkage=model.get("linkage", "ward")
        )
        clusters = agglom.fit_predict(X)
    elif model_type == "spectral" and isinstance(model, dict):
        # For SpectralClustering, we need to train a new model
        spectral = SpectralClustering(
            n_clusters=model.get("n_clusters", 5),
            affinity=model.get("affinity", "rbf")
        )
        clusters = spectral.fit_predict(X)
    elif model_type == "meanshift" and isinstance(model, dict):
        # For MeanShift, we need to train a new model
        # We can use the stored cluster centers to initialize a new model
        # But for simplicity, we'll just fit a new one
        meanshift = MeanShift()
        clusters = meanshift.fit_predict(X)
    elif model_type == "optics" and isinstance(model, dict):
        # For OPTICS, we need to train a new model
        optics = OPTICS(
            min_samples=model.get("min_samples", 5),
            xi=model.get("xi", 0.05)
        )
        clusters = optics.fit_predict(X)
    else:
        # Generic fallback - might not work for all models
        try:
            clusters = model.predict(X)
        except AttributeError:
            # If predict is not available, try fit_predict
            try:
                clusters = model.fit_predict(X)
            except AttributeError:
                logger.error(f"Model {model_type} does not support prediction")
                return results
    
    # Update database and store results
    for i, payload_id in enumerate(valid_payload_ids):
        try:
            payload = Payload.query.get(payload_id)
            
            # Update payload with cluster assignment
            payload.cluster_id = int(clusters[i])
            
            db.session.commit()
            
            # Store results
            results[payload_id] = {
                "cluster_id": int(clusters[i])
            }
            
            logger.info(f"Payload {payload_id} assigned to cluster {clusters[i]}")
            
        except Exception as e:
            logger.error(f"Error updating cluster for payload {payload_id}: {str(e)}")
            db.session.rollback()
    
    return results

def visualize_clusters(payload_ids=None, model_type="kmeans", dimension_reduction="tsne", save_path=None):
    """
    Generate visualization of payload clusters.
    
    Args:
        payload_ids (list, optional): List of payload IDs to visualize. If None, all payloads are used.
        model_type (str): Type of clustering model to use
        dimension_reduction (str): Method for dimensionality reduction ('tsne' or 'pca')
        save_path (str, optional): Path to save the visualization. If None, a temporary file is created.
        
    Returns:
        str: Path to the saved visualization
    """
    try:
        # Get payloads
        if payload_ids is None:
            payloads = Payload.query.filter(Payload.analyzed == True).all()
            payload_ids = [p.id for p in payloads]
        else:
            payloads = Payload.query.filter(Payload.id.in_(payload_ids)).all()
        
        if not payloads:
            logger.warning("No payloads found for visualization")
            return None
        
        # Extract features for all payloads
        features_list = []
        valid_payload_ids = []
        for payload in payloads:
            try:
                features_dict = extract_features_from_payload(payload.id)
                features_list.append(features_dict)
                valid_payload_ids.append(payload.id)
            except Exception as e:
                logger.error(f"Error extracting features from payload {payload.id}: {str(e)}")
        
        if not features_list:
            logger.warning("No valid features extracted for visualization")
            return None
        
        # Convert features to matrix
        X = get_feature_vector(features_list)
        
        # Get clusters
        clusters = None
        if all(p.cluster_id is not None for p in payloads):
            # Use existing cluster assignments
            clusters = [p.cluster_id for p in payloads]
        else:
            # Cluster the payloads
            result = cluster_payloads(payload_ids, model_type)
            if not result:
                logger.warning("Clustering failed, using random assignments for visualization")
                import random
                clusters = [random.randint(0, 4) for _ in range(len(payloads))]
            else:
                clusters = [result.get(pid, {}).get("cluster_id", 0) for pid in valid_payload_ids]
        
        # Get anomaly information
        anomalies = [p.is_anomalous for p in payloads]
        
        # Reduce dimensionality for visualization
        if dimension_reduction == "tsne":
            reducer = TSNE(n_components=2, random_state=42)
            X_reduced = reducer.fit_transform(X)
        else:  # PCA
            reducer = PCA(n_components=2, random_state=42)
            X_reduced = reducer.fit_transform(X)
        
        # Generate visualization
        plt.figure(figsize=(12, 8))
        
        # Plot clusters
        scatter = plt.scatter(X_reduced[:, 0], X_reduced[:, 1], 
                              c=clusters, cmap='viridis', 
                              s=100, alpha=0.7, edgecolors='w')
        
        # Mark anomalies with an 'x'
        for i, is_anomalous in enumerate(anomalies):
            if is_anomalous:
                plt.scatter(X_reduced[i, 0], X_reduced[i, 1], 
                           marker='x', color='red', s=200, linewidths=2)
        
        # Add legend for clusters
        legend1 = plt.legend(*scatter.legend_elements(),
                             loc="upper right", title="Clusters")
        plt.add_artist(legend1)
        
        # Add legend for anomalies
        from matplotlib.lines import Line2D
        legend_elements = [Line2D([0], [0], marker='x', color='w', label='Anomaly',
                                 markerfacecolor='red', markersize=10)]
        plt.legend(handles=legend_elements, loc="lower right")
        
        plt.title(f'Payload Clustering Visualization ({model_type.upper()} model with {dimension_reduction.upper()} reduction)')
        plt.xlabel('Dimension 1')
        plt.ylabel('Dimension 2')
        plt.grid(alpha=0.3)
        
        # Save the figure
        if save_path is None:
            import tempfile
            temp_dir = tempfile.gettempdir()
            save_path = os.path.join(temp_dir, f'cluster_viz_{model_type}_{dimension_reduction}.png')
        
        plt.tight_layout()
        plt.savefig(save_path)
        plt.close()
        
        return save_path
    
    except Exception as e:
        logger.error(f"Error visualizing clusters: {str(e)}")
        return None

def get_cluster_statistics(model_type="kmeans"):
    """
    Get statistics about the clusters.
    
    Args:
        model_type (str): Type of clustering model
        
    Returns:
        dict: Cluster statistics
    """
    try:
        # Get all payloads with cluster assignments
        payloads = Payload.query.filter(Payload.cluster_id.isnot(None)).all()
        
        if not payloads:
            return {"error": "No clustered payloads found"}
        
        # Group payloads by cluster
        clusters = {}
        for payload in payloads:
            cluster_id = payload.cluster_id
            if cluster_id not in clusters:
                clusters[cluster_id] = []
            clusters[cluster_id].append(payload)
        
        # Calculate statistics
        stats = {
            "total_payloads": len(payloads),
            "total_clusters": len(clusters),
            "largest_cluster_size": max(len(cluster) for cluster in clusters.values()),
            "smallest_cluster_size": min(len(cluster) for cluster in clusters.values()),
            "clusters": {}
        }
        
        # Calculate statistics for each cluster
        for cluster_id, cluster_payloads in clusters.items():
            # Count anomalies in cluster
            anomaly_count = sum(1 for p in cluster_payloads if p.is_anomalous)
            
            # Calculate average anomaly score
            avg_anomaly_score = sum(p.anomaly_score or 0 for p in cluster_payloads) / len(cluster_payloads)
            
            stats["clusters"][cluster_id] = {
                "size": len(cluster_payloads),
                "anomaly_count": anomaly_count,
                "anomaly_percentage": (anomaly_count / len(cluster_payloads)) * 100,
                "avg_anomaly_score": avg_anomaly_score
            }
        
        return stats
    
    except Exception as e:
        logger.error(f"Error calculating cluster statistics: {str(e)}")
        return {"error": str(e)}
