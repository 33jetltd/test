"""
Mobile Application Analysis Module.

This module provides functionality to analyze mobile applications (APK/IPA files)
for security vulnerabilities, including static analysis, dynamic analysis,
and permission/component checks.
"""

import os
import json
import re
import time
import tempfile
import logging
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
from io import BytesIO

logger = logging.getLogger(__name__)

class MobileAnalysisError(Exception):
    """Exception raised for errors in mobile application analysis."""
    pass

class MobileAppInfo:
    """Class to store mobile application information."""
    
    def __init__(self):
        self.name = ""
        self.package = ""
        self.version = ""
        self.version_code = 0
        self.platform = ""
        self.min_sdk = ""
        self.target_sdk = ""
        self.size = 0
        self.hash = ""
        self.signature_status = "Unknown"
        self.category = "Unknown"
        self.icon_path = None
        self.permissions = []
        self.activities = []
        self.services = []
        self.receivers = []
        self.providers = []
        self.libraries = []
        self.network_endpoints = []
        

def analyze_mobile_app(app_file, analysis_type="comprehensive"):
    """
    Analyze a mobile application (APK/IPA) for security vulnerabilities.
    
    Args:
        app_file: The uploaded app file (file object)
        analysis_type (str): Type of analysis to perform:
                           - comprehensive: All checks
                           - static: Static analysis only
                           - dynamic: Dynamic analysis only
                           - network: Network traffic analysis
                           - permissions: Permissions analysis
        
    Returns:
        dict: Analysis results
    """
    try:
        # Determine file type (APK or IPA)
        file_contents = app_file.read()
        file_extension = os.path.splitext(app_file.filename)[1].lower()
        
        if file_extension == '.apk':
            platform = 'android'
            result = analyze_android_app(BytesIO(file_contents), analysis_type)
        elif file_extension == '.ipa':
            platform = 'ios' 
            result = analyze_ios_app(BytesIO(file_contents), analysis_type)
        else:
            raise MobileAnalysisError(f"Unsupported file type: {file_extension}. Please upload an APK or IPA file.")
        
        # Log analysis completion
        logger.info(f"Completed {analysis_type} analysis of {app_file.filename}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error analyzing mobile app: {str(e)}")
        raise MobileAnalysisError(f"Error analyzing mobile app: {str(e)}")

def analyze_android_app(file_content, analysis_type):
    """
    Analyze an Android APK file.
    
    Args:
        file_content (BytesIO): APK file content
        analysis_type (str): Type of analysis to perform
        
    Returns:
        dict: Analysis results
    """
    # Create result template
    result = {
        "app_info": {},
        "security_assessment": {
            "score": 0,
            "grade": "",
            "details": {},
            "vulnerabilities": []
        },
        "permissions": [],
        "components": {
            "activities": [],
            "services": [],
            "receivers": [],
            "providers": []
        },
        "libraries": [],
        "network_analysis": {
            "endpoints": [],
            "ssl_analysis": []
        },
        "source_code_analysis": {
            "findings": []
        }
    }
    
    # Extract app info
    app_info = extract_android_app_info(file_content)
    result["app_info"] = {
        "name": app_info.name,
        "package": app_info.package,
        "version": app_info.version,
        "version_code": app_info.version_code,
        "platform": "Android",
        "min_sdk": app_info.min_sdk,
        "target_sdk": app_info.target_sdk,
        "size": app_info.size,
        "hash": app_info.hash,
        "signature_status": app_info.signature_status,
        "category": app_info.category,
        "icon_path": app_info.icon_path
    }
    
    # Perform static analysis
    if analysis_type in ["comprehensive", "static"]:
        static_results = perform_android_static_analysis(file_content, app_info)
        result["permissions"] = static_results["permissions"]
        result["components"] = static_results["components"]
        result["libraries"] = static_results["libraries"]
        result["source_code_analysis"] = static_results["source_code_analysis"]
    
    # Perform network analysis
    if analysis_type in ["comprehensive", "network"]:
        network_results = analyze_android_network(file_content, app_info)
        result["network_analysis"] = network_results
    
    # Perform security assessment
    security_assessment = assess_android_security(result)
    result["security_assessment"] = security_assessment
    
    return result

def analyze_ios_app(file_content, analysis_type):
    """
    Analyze an iOS IPA file.
    
    Args:
        file_content (BytesIO): IPA file content
        analysis_type (str): Type of analysis to perform
        
    Returns:
        dict: Analysis results
    """
    # Create result template
    result = {
        "app_info": {},
        "security_assessment": {
            "score": 0,
            "grade": "",
            "details": {},
            "vulnerabilities": []
        },
        "permissions": [],
        "components": {
            "view_controllers": [],
            "frameworks": [],
            "app_delegates": [],
            "extensions": []
        },
        "libraries": [],
        "network_analysis": {
            "endpoints": [],
            "ssl_analysis": []
        },
        "source_code_analysis": {
            "findings": []
        }
    }
    
    # Extract app info
    app_info = extract_ios_app_info(file_content)
    result["app_info"] = {
        "name": app_info.name,
        "bundle_id": app_info.package,
        "version": app_info.version,
        "build": app_info.version_code,
        "platform": "iOS",
        "min_os": app_info.min_sdk,
        "size": app_info.size,
        "hash": app_info.hash,
        "signature_status": app_info.signature_status,
        "category": app_info.category,
        "icon_path": app_info.icon_path
    }
    
    # Perform static analysis
    if analysis_type in ["comprehensive", "static"]:
        static_results = perform_ios_static_analysis(file_content, app_info)
        result["permissions"] = static_results["permissions"]
        result["components"] = static_results["components"]
        result["libraries"] = static_results["libraries"]
        result["source_code_analysis"] = static_results["source_code_analysis"]
    
    # Perform network analysis
    if analysis_type in ["comprehensive", "network"]:
        network_results = analyze_ios_network(file_content, app_info)
        result["network_analysis"] = network_results
    
    # Perform security assessment
    security_assessment = assess_ios_security(result)
    result["security_assessment"] = security_assessment
    
    return result

def extract_android_app_info(file_content):
    """
    Extract basic information from an Android APK file.
    
    Args:
        file_content (BytesIO): APK file content
        
    Returns:
        MobileAppInfo: Application information
    """
    app_info = MobileAppInfo()
    app_info.platform = "Android"
    
    try:
        # Calculate file size
        file_content.seek(0, os.SEEK_END)
        app_info.size = file_content.tell()
        file_content.seek(0)
        
        # Open APK as ZIP
        with zipfile.ZipFile(file_content) as apk_zip:
            # Extract AndroidManifest.xml
            if "AndroidManifest.xml" in apk_zip.namelist():
                # In a real implementation, we would use proper tools like aapt or apktool
                # to parse the binary AndroidManifest.xml. This is a simplified version.
                
                # Mocked extraction from manifest
                app_info.name = "Mobile Banking App"
                app_info.package = "com.example.mobilebanking"
                app_info.version = "2.1.0"
                app_info.version_code = 42
                app_info.min_sdk = "API 23 (Android 6.0)"
                app_info.target_sdk = "API 30 (Android 11.0)"
                
                # Extract activities, services, receivers, providers
                app_info.activities = ["MainActivity", "LoginActivity", "WebViewActivity", 
                                      "TransferActivity", "SettingsActivity"]
                app_info.services = ["DataSyncService", "NotificationService"]
                app_info.receivers = ["BootReceiver", "PushNotificationReceiver"]
                app_info.providers = ["UserDataProvider"]
                
                # Extract permissions
                app_info.permissions = [
                    {"name": "android.permission.INTERNET", "type": "normal"},
                    {"name": "android.permission.ACCESS_NETWORK_STATE", "type": "normal"},
                    {"name": "android.permission.READ_EXTERNAL_STORAGE", "type": "dangerous"},
                    {"name": "android.permission.WRITE_EXTERNAL_STORAGE", "type": "dangerous"},
                    {"name": "android.permission.CAMERA", "type": "dangerous"},
                    {"name": "android.permission.READ_CONTACTS", "type": "dangerous"},
                    {"name": "android.permission.READ_PHONE_STATE", "type": "dangerous"},
                    {"name": "android.permission.ACCESS_FINE_LOCATION", "type": "dangerous"},
                    {"name": "android.permission.VIBRATE", "type": "normal"},
                    {"name": "com.android.launcher.permission.INSTALL_SHORTCUT", "type": "signature"}
                ]
            
            # Extract common libraries
            common_libraries = [
                "okhttp", "retrofit", "gson", "sqlcipher", "glide", 
                "firebase", "zxing"
            ]
            app_info.libraries = []
            
            for filename in apk_zip.namelist():
                if filename.endswith(".jar") or filename.endswith(".dex"):
                    for lib in common_libraries:
                        if lib in filename.lower():
                            app_info.libraries.append({
                                "name": lib.capitalize(),
                                "version": get_mock_library_version(lib)
                            })
            
            # Remove duplicates
            seen_libs = set()
            unique_libs = []
            for lib in app_info.libraries:
                if lib["name"] not in seen_libs:
                    seen_libs.add(lib["name"])
                    unique_libs.append(lib)
            app_info.libraries = unique_libs
            
            # Calculate hash (simplified)
            app_info.hash = "8a7df6e8f14a3b9b3e0f0e8d9a8c7b6e5f4d3c2b1a0"
            
            # Check signature
            app_info.signature_status = "Properly Signed"
            
            # Assign category
            app_info.category = "Finance / Banking"
            
    except Exception as e:
        logger.error(f"Error extracting Android app info: {str(e)}")
        raise MobileAnalysisError(f"Error extracting app info: {str(e)}")
    
    return app_info

def extract_ios_app_info(file_content):
    """
    Extract basic information from an iOS IPA file.
    
    Args:
        file_content (BytesIO): IPA file content
        
    Returns:
        MobileAppInfo: Application information
    """
    app_info = MobileAppInfo()
    app_info.platform = "iOS"
    
    try:
        # Calculate file size
        file_content.seek(0, os.SEEK_END)
        app_info.size = file_content.tell()
        file_content.seek(0)
        
        # Open IPA as ZIP
        with zipfile.ZipFile(file_content) as ipa_zip:
            # In a real implementation, we would use proper tools to parse the Info.plist
            # This is a simplified version
            
            # Mocked extraction from Info.plist
            app_info.name = "Mobile Banking iOS"
            app_info.package = "com.example.mobilebanking-ios"
            app_info.version = "2.1.0"
            app_info.version_code = 42
            app_info.min_sdk = "iOS 14.0+"
            
            # Extract permissions
            app_info.permissions = [
                {"name": "NSCameraUsageDescription", "type": "dangerous"},
                {"name": "NSPhotoLibraryUsageDescription", "type": "dangerous"},
                {"name": "NSLocationWhenInUseUsageDescription", "type": "dangerous"},
                {"name": "NSContactsUsageDescription", "type": "dangerous"},
                {"name": "NSFaceIDUsageDescription", "type": "dangerous"}
            ]
            
            # Extract libraries
            app_info.libraries = [
                {"name": "Alamofire", "version": "5.4.0"},
                {"name": "SwiftyJSON", "version": "5.0.0"},
                {"name": "KeychainAccess", "version": "4.2.0"},
                {"name": "SDWebImage", "version": "5.11.0"},
                {"name": "Firebase", "version": "8.5.0"},
                {"name": "GoogleAnalytics", "version": "7.0.0"}
            ]
            
            # Calculate hash (simplified)
            app_info.hash = "9b8d7e6c5f4a3b2d1c0f9e8d7c6b5a4f3e2d1c0b"
            
            # Check signature
            app_info.signature_status = "Properly Signed"
            
            # Assign category
            app_info.category = "Finance / Banking"
            
    except Exception as e:
        logger.error(f"Error extracting iOS app info: {str(e)}")
        raise MobileAnalysisError(f"Error extracting app info: {str(e)}")
    
    return app_info

def perform_android_static_analysis(file_content, app_info):
    """
    Perform static analysis on an Android APK.
    
    Args:
        file_content (BytesIO): APK file content
        app_info (MobileAppInfo): App information
        
    Returns:
        dict: Static analysis results
    """
    result = {
        "permissions": [],
        "components": {
            "activities": [],
            "services": [],
            "receivers": [],
            "providers": []
        },
        "libraries": [],
        "source_code_analysis": {
            "findings": []
        }
    }
    
    try:
        # Process permissions
        for perm in app_info.permissions:
            permission_data = {
                "name": perm["name"],
                "type": perm["type"],
                "description": get_permission_description(perm["name"]),
                "risk": get_permission_risk(perm["name"])
            }
            result["permissions"].append(permission_data)
        
        # Process activities
        for activity in app_info.activities:
            is_exported = activity == "WebViewActivity"  # For demonstration purposes
            activity_data = {
                "name": activity,
                "full_name": f"com.example.mobilebanking.ui.{activity}",
                "exported": is_exported,
                "risky": is_exported
            }
            result["components"]["activities"].append(activity_data)
        
        # Process services
        for service in app_info.services:
            service_data = {
                "name": service,
                "full_name": f"com.example.mobilebanking.services.{service}",
                "exported": False,
                "risky": False
            }
            result["components"]["services"].append(service_data)
        
        # Process receivers
        for receiver in app_info.receivers:
            receiver_data = {
                "name": receiver,
                "full_name": f"com.example.mobilebanking.receivers.{receiver}",
                "exported": True,  # Usually broadcast receivers are exported
                "risky": True
            }
            result["components"]["receivers"].append(receiver_data)
        
        # Process providers
        for provider in app_info.providers:
            provider_data = {
                "name": provider,
                "full_name": f"com.example.mobilebanking.providers.{provider}",
                "exported": True,
                "protected": True,
                "risky": False
            }
            result["components"]["providers"].append(provider_data)
        
        # Process libraries
        for lib in app_info.libraries:
            lib_name = lib["name"].lower()
            lib_version = lib["version"]
            
            library_data = {
                "name": lib["name"],
                "version": lib_version,
                "up_to_date": is_library_up_to_date(lib_name, lib_version),
                "vulnerabilities": get_library_vulnerabilities(lib_name, lib_version)
            }
            result["libraries"].append(library_data)
        
        # Perform source code analysis (simulated)
        result["source_code_analysis"]["findings"] = simulate_source_code_findings()
        
    except Exception as e:
        logger.error(f"Error in Android static analysis: {str(e)}")
        raise MobileAnalysisError(f"Static analysis error: {str(e)}")
    
    return result

def perform_ios_static_analysis(file_content, app_info):
    """
    Perform static analysis on an iOS IPA.
    
    Args:
        file_content (BytesIO): IPA file content
        app_info (MobileAppInfo): App information
        
    Returns:
        dict: Static analysis results
    """
    # This would be similar to the Android analysis but with iOS-specific components
    # For brevity, a simplified version is provided
    
    result = {
        "permissions": [],
        "components": {
            "view_controllers": [],
            "frameworks": [],
            "app_delegates": [],
            "extensions": []
        },
        "libraries": [],
        "source_code_analysis": {
            "findings": []
        }
    }
    
    try:
        # Process permissions
        for perm in app_info.permissions:
            permission_data = {
                "name": perm["name"],
                "type": perm["type"],
                "description": get_ios_permission_description(perm["name"]),
                "risk": get_permission_risk(perm["name"])
            }
            result["permissions"].append(permission_data)
        
        # Process libraries
        for lib in app_info.libraries:
            lib_name = lib["name"].lower()
            lib_version = lib["version"]
            
            library_data = {
                "name": lib["name"],
                "version": lib_version,
                "up_to_date": is_library_up_to_date(lib_name, lib_version),
                "vulnerabilities": get_library_vulnerabilities(lib_name, lib_version)
            }
            result["libraries"].append(library_data)
        
        # Perform source code analysis (simulated)
        result["source_code_analysis"]["findings"] = simulate_ios_source_code_findings()
        
    except Exception as e:
        logger.error(f"Error in iOS static analysis: {str(e)}")
        raise MobileAnalysisError(f"Static analysis error: {str(e)}")
    
    return result

def analyze_android_network(file_content, app_info):
    """
    Analyze network communication in an Android app.
    
    Args:
        file_content (BytesIO): APK file content
        app_info (MobileAppInfo): App information
        
    Returns:
        dict: Network analysis results
    """
    network_results = {
        "endpoints": [],
        "ssl_analysis": [],
        "data_leakage": []
    }
    
    try:
        # Simulate finding network endpoints from code
        network_results["endpoints"] = [
            {
                "host": "api.mobilebanking.com",
                "protocol": "HTTPS",
                "description": "Main API server - 12 endpoints",
                "endpoints": [
                    "POST /api/login",
                    "GET /api/accounts",
                    "POST /api/transfer"
                ],
                "suspicious": False
            },
            {
                "host": "analytics.trackuser.net",
                "protocol": "HTTP",
                "description": "Analytics service - 3 endpoints",
                "endpoints": [
                    "POST /track",
                    "GET /config"
                ],
                "suspicious": True,
                "reason": "Insecure connection (HTTP) - Sensitive data could be exposed"
            },
            {
                "host": "cdn.mobilebanking.com",
                "protocol": "HTTPS",
                "description": "Content delivery - 5 endpoints",
                "endpoints": [
                    "GET /images",
                    "GET /js"
                ],
                "suspicious": False
            }
        ]
        
        # Simulate SSL/TLS analysis
        network_results["ssl_analysis"] = [
            {
                "host": "api.mobilebanking.com",
                "protocol": "TLS 1.2",
                "cipher_suite": "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
                "certificate": "Valid (Expires: 2025-02-15)",
                "status": "Secure"
            },
            {
                "host": "analytics.trackuser.net",
                "protocol": "HTTP",
                "cipher_suite": "N/A",
                "certificate": "N/A",
                "status": "Insecure"
            },
            {
                "host": "cdn.mobilebanking.com",
                "protocol": "TLS 1.2",
                "cipher_suite": "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
                "certificate": "Valid (Expires: 2025-01-10)",
                "status": "Secure"
            }
        ]
        
        # Simulate data leakage findings
        network_results["data_leakage"] = [
            {
                "severity": "Critical",
                "description": "The application transmits device ID and user identifiable information over HTTP to analytics.trackuser.net",
                "code_snippet": """POST /track HTTP/1.1
Host: analytics.trackuser.net
Content-Type: application/json

{
  "device_id": "b5c77a8e-0c3d-4f79-8f37-92e5af91df8a",
  "user_id": "user12345",
  "account_number": "****8901",
  "event": "transfer_initiated",
  "amount": 500.00,
  "timestamp": "2023-03-15T14:32:10Z"
}"""
            }
        ]
        
    except Exception as e:
        logger.error(f"Error in Android network analysis: {str(e)}")
        raise MobileAnalysisError(f"Network analysis error: {str(e)}")
    
    return network_results

def analyze_ios_network(file_content, app_info):
    """
    Analyze network communication in an iOS app.
    
    Args:
        file_content (BytesIO): IPA file content
        app_info (MobileAppInfo): App information
        
    Returns:
        dict: Network analysis results
    """
    # Similar to Android but iOS-specific
    # For brevity, a simplified version is provided that reuses the Android function
    return analyze_android_network(file_content, app_info)

def assess_android_security(analysis_results):
    """
    Perform overall security assessment for an Android app.
    
    Args:
        analysis_results (dict): Analysis results
        
    Returns:
        dict: Security assessment
    """
    # Calculate scores for different security aspects
    code_security_score = calculate_code_security_score(analysis_results)
    data_protection_score = calculate_data_protection_score(analysis_results)
    network_security_score = calculate_network_security_score(analysis_results)
    authentication_score = calculate_authentication_score(analysis_results)
    
    # Count vulnerabilities by severity
    vulnerabilities = {
        "critical": 0,
        "high": 0,
        "medium": 0,
        "low": 0
    }
    
    # Add findings from source code analysis
    for finding in analysis_results.get("source_code_analysis", {}).get("findings", []):
        severity = finding.get("severity", "").lower()
        if severity in vulnerabilities:
            vulnerabilities[severity] += 1
    
    # Check for network vulnerabilities
    if "network_analysis" in analysis_results:
        for endpoint in analysis_results["network_analysis"].get("endpoints", []):
            if endpoint.get("suspicious"):
                vulnerabilities["high"] += 1
        
        for leak in analysis_results["network_analysis"].get("data_leakage", []):
            severity = leak.get("severity", "").lower()
            if severity in vulnerabilities:
                vulnerabilities[severity] += 1
    
    # Check for dangerous permissions
    dangerous_permission_count = 0
    for permission in analysis_results.get("permissions", []):
        if permission.get("type") == "dangerous":
            dangerous_permission_count += 1
            if dangerous_permission_count > 3:  # Threshold for considering as an issue
                vulnerabilities["medium"] += 1
    
    # Check for library vulnerabilities
    for library in analysis_results.get("libraries", []):
        for vuln in library.get("vulnerabilities", []):
            severity = vuln.get("severity", "").lower()
            if severity in vulnerabilities:
                vulnerabilities[severity] += 1
    
    # Calculate overall score (weighted average)
    overall_score = (
        code_security_score * 0.25 +
        data_protection_score * 0.25 +
        network_security_score * 0.25 +
        authentication_score * 0.25
    )
    
    # Adjust score based on vulnerabilities
    overall_score -= vulnerabilities.get("critical", 0) * 15
    overall_score -= vulnerabilities.get("high", 0) * 10
    overall_score -= vulnerabilities.get("medium", 0) * 5
    overall_score -= vulnerabilities.get("low", 0) * 2
    
    # Ensure score is between 0 and 100
    overall_score = max(0, min(100, overall_score))
    
    # Determine grade
    grade = get_grade_from_score(overall_score)
    
    return {
        "score": round(overall_score),
        "grade": grade,
        "details": {
            "code_security": round(code_security_score),
            "data_protection": round(data_protection_score),
            "network_security": round(network_security_score),
            "authentication": round(authentication_score)
        },
        "vulnerabilities": vulnerabilities
    }

def assess_ios_security(analysis_results):
    """
    Perform overall security assessment for an iOS app.
    
    Args:
        analysis_results (dict): Analysis results
        
    Returns:
        dict: Security assessment
    """
    # Similar to Android but iOS-specific
    # For brevity, reuse the Android function with slight adjustments
    assessment = assess_android_security(analysis_results)
    
    # Make iOS-specific adjustments (e.g., iOS apps typically score better on sandboxing)
    assessment["details"]["code_security"] = min(100, assessment["details"]["code_security"] + 5)
    
    # Recalculate overall score
    overall_score = (
        assessment["details"]["code_security"] * 0.25 +
        assessment["details"]["data_protection"] * 0.25 +
        assessment["details"]["network_security"] * 0.25 +
        assessment["details"]["authentication"] * 0.25
    )
    
    # Ensure score is between 0 and 100
    overall_score = max(0, min(100, overall_score))
    
    # Update overall score and grade
    assessment["score"] = round(overall_score)
    assessment["grade"] = get_grade_from_score(overall_score)
    
    return assessment

# Helper functions

def get_permission_description(permission_name):
    """Get a description for an Android permission."""
    descriptions = {
        "android.permission.INTERNET": "Allows the app to open network sockets",
        "android.permission.ACCESS_NETWORK_STATE": "Allows the app to view network connections",
        "android.permission.READ_EXTERNAL_STORAGE": "Allows the app to read from external storage",
        "android.permission.WRITE_EXTERNAL_STORAGE": "Allows the app to write to external storage",
        "android.permission.CAMERA": "Allows the app to access the camera device",
        "android.permission.READ_CONTACTS": "Allows the app to read the user's contacts data",
        "android.permission.READ_PHONE_STATE": "Allows read-only access to phone state, including the phone number, current cellular network information, and ongoing calls",
        "android.permission.ACCESS_FINE_LOCATION": "Allows the app to get precise location from location services",
        "android.permission.VIBRATE": "Allows the app to control the vibrator",
        "com.android.launcher.permission.INSTALL_SHORTCUT": "Allows an application to add shortcuts without user intervention"
    }
    return descriptions.get(permission_name, "No description available")

def get_ios_permission_description(permission_name):
    """Get a description for an iOS permission."""
    descriptions = {
        "NSCameraUsageDescription": "Allows the app to access the device camera",
        "NSPhotoLibraryUsageDescription": "Allows the app to access the photo library",
        "NSLocationWhenInUseUsageDescription": "Allows the app to access location while in use",
        "NSContactsUsageDescription": "Allows the app to access the device contacts",
        "NSFaceIDUsageDescription": "Allows the app to use Face ID authentication"
    }
    return descriptions.get(permission_name, "No description available")

def get_permission_risk(permission_name):
    """Get risk level for a permission."""
    high_risk = ["android.permission.READ_CONTACTS", 
                "android.permission.READ_PHONE_STATE", 
                "android.permission.ACCESS_FINE_LOCATION",
                "android.permission.CAMERA",
                "NSCameraUsageDescription", 
                "NSContactsUsageDescription",
                "NSLocationWhenInUseUsageDescription"]
    
    medium_risk = ["android.permission.READ_EXTERNAL_STORAGE", 
                  "android.permission.WRITE_EXTERNAL_STORAGE",
                  "NSPhotoLibraryUsageDescription"]
    
    if permission_name in high_risk:
        return "High"
    elif permission_name in medium_risk:
        return "Medium"
    else:
        return "Low"

def get_mock_library_version(library_name):
    """Get mock version for a library."""
    versions = {
        "okhttp": "3.12.0",
        "retrofit": "2.9.0",
        "gson": "2.8.5",
        "sqlcipher": "4.4.0",
        "glide": "4.11.0",
        "firebase": "19.0.0",
        "zxing": "3.3.3"
    }
    return versions.get(library_name, "1.0.0")

def is_library_up_to_date(library_name, version):
    """Check if a library version is up to date."""
    latest_versions = {
        "okhttp": "4.9.1",
        "retrofit": "2.9.0",
        "gson": "2.8.9",
        "sqlcipher": "4.5.0",
        "glide": "4.12.0",
        "firebase": "29.0.0",
        "zxing": "3.4.1",
        "alamofire": "5.5.0",
        "swiftyjson": "5.0.1",
        "keychainaccess": "4.2.2",
        "sdwebimage": "5.12.0"
    }
    
    library_name = library_name.lower()
    
    if library_name in latest_versions:
        return version == latest_versions[library_name]
    
    return True  # Default to true if we don't know

def get_library_vulnerabilities(library_name, version):
    """Get known vulnerabilities for a library version."""
    vulnerabilities = {
        "okhttp": {
            "3.12.0": [{"id": "CVE-2021-0341", "severity": "High", "description": "Improper certificate validation"}]
        },
        "gson": {
            "2.8.5": [{"id": "CVE-2022-25647", "severity": "Medium", "description": "Deserialization vulnerability"}]
        }
    }
    
    library_name = library_name.lower()
    
    if library_name in vulnerabilities and version in vulnerabilities[library_name]:
        return vulnerabilities[library_name][version]
    
    return []

def simulate_source_code_findings():
    """Simulate source code analysis findings."""
    return [
        {
            "title": "Insecure Data Storage",
            "severity": "Critical",
            "location": "com.example.mobilebanking.utils.UserPreferences.java",
            "description": "Sensitive user data is stored in SharedPreferences without encryption",
            "vulnerable_code": """SharedPreferences prefs = context.getSharedPreferences("user_data", Context.MODE_PRIVATE);
SharedPreferences.Editor editor = prefs.edit();
editor.putString("account_number", accountNumber);
editor.putString("auth_token", authToken);
editor.apply();""",
            "suggested_fix": """MasterKey masterKey = new MasterKey.Builder(context)
    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
    .build();

SharedPreferences encryptedPrefs = EncryptedSharedPreferences.create(
    context,
    "encrypted_user_data",
    masterKey,
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);

encryptedPrefs.edit()
    .putString("account_number", accountNumber)
    .putString("auth_token", authToken)
    .apply();""",
            "impact": "An attacker with physical access to the device or who can exploit another vulnerability to access the app's data directory could extract sensitive user information, potentially leading to account compromise."
        },
        {
            "title": "Weak SSL Implementation",
            "severity": "High",
            "location": "com.example.mobilebanking.network.ApiClient.java",
            "description": "SSL certificate validation is disabled, allowing man-in-the-middle attacks",
            "vulnerable_code": """TrustManager[] trustAllCerts = new TrustManager[] {
    new X509TrustManager() {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {}

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {}

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
};""",
            "suggested_fix": """OkHttpClient client = new OkHttpClient.Builder()
    // Use default SSL factory which properly validates certificates
    .build();""",
            "impact": "An attacker could perform a man-in-the-middle attack to intercept sensitive information transmitted between the app and the server, including login credentials and financial data."
        },
        {
            "title": "Arbitrary Code Execution via WebView",
            "severity": "Critical",
            "location": "com.example.mobilebanking.ui.WebViewActivity.java",
            "description": "JavaScript interface exposes critical native functionality to WebView content",
            "vulnerable_code": """webView.getSettings().setJavaScriptEnabled(true);
webView.getSettings().setAllowFileAccess(true);
webView.addJavascriptInterface(new WebAppInterface(this), "Android");

class WebAppInterface {
    Context context;

    WebAppInterface(Context context) {
        this.context = context;
    }

    @JavascriptInterface
    public String getDeviceInfo() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }

    @JavascriptInterface
    public void executeCommand(String command) {
        try {
            Runtime.getRuntime().exec(command);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}""",
            "suggested_fix": """WebView webView = findViewById(R.id.webView);
webView.getSettings().setJavaScriptEnabled(true);
webView.getSettings().setAllowFileAccess(false);
webView.getSettings().setAllowFileAccessFromFileURLs(false);
webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
webView.addJavascriptInterface(new WebAppInterface(this), "Android");

class WebAppInterface {
    Context context;

    WebAppInterface(Context context) {
        this.context = context;
    }

    @JavascriptInterface
    public String getDeviceInfo() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }

    // Removed executeCommand method
}""",
            "impact": "Malicious websites loaded in the WebView or a successful cross-site scripting attack could execute arbitrary commands on the device with the permissions of the app."
        }
    ]

def simulate_ios_source_code_findings():
    """Simulate iOS source code analysis findings."""
    return [
        {
            "title": "Insecure Data Storage",
            "severity": "Critical",
            "location": "UserDefaults.swift",
            "description": "Sensitive user data stored in UserDefaults without encryption",
            "vulnerable_code": """let defaults = UserDefaults.standard
defaults.set(accountNumber, forKey: "accountNumber")
defaults.set(authToken, forKey: "authToken")""",
            "suggested_fix": """let secureStorage = KeychainWrapper.standard
secureStorage.set(accountNumber, forKey: "accountNumber")
secureStorage.set(authToken, forKey: "authToken")""",
            "impact": "An attacker with access to the device could extract sensitive user information from UserDefaults."
        },
        {
            "title": "App Transport Security Disabled",
            "severity": "High",
            "location": "Info.plist",
            "description": "App Transport Security (ATS) is disabled, allowing insecure HTTP connections",
            "vulnerable_code": """<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <true/>
</dict>""",
            "suggested_fix": """<key>NSAppTransportSecurity</key>
<dict>
    <key>NSExceptionDomains</key>
    <dict>
        <key>example.com</key>
        <dict>
            <key>NSExceptionAllowsInsecureHTTPLoads</key>
            <true/>
            <key>NSIncludesSubdomains</key>
            <true/>
        </dict>
    </dict>
</dict>""",
            "impact": "Disabling ATS allows the app to make insecure HTTP connections, potentially exposing sensitive data."
        },
        {
            "title": "Jailbreak Detection Bypass",
            "severity": "High",
            "location": "SecurityUtils.swift",
            "description": "Jailbreak detection can be easily bypassed",
            "vulnerable_code": """func isJailbroken() -> Bool {
    let path = "/Applications/Cydia.app"
    return FileManager.default.fileExists(atPath: path)
}""",
            "suggested_fix": """func isJailbroken() -> Bool {
    // Check for Cydia
    if FileManager.default.fileExists(atPath: "/Applications/Cydia.app") {
        return true
    }
    
    // Check for sandboxing
    let stringToWrite = "Jailbreak Detection Test"
    do {
        try stringToWrite.write(toFile: "/private/jailbreak.txt", atomically: true, encoding: .utf8)
        return true
    } catch {
        return false
    }
}""",
            "impact": "The simple jailbreak detection can be easily bypassed, allowing attackers to run the app on jailbroken devices and potentially extract sensitive data or modify the app's behavior."
        }
    ]

def calculate_code_security_score(analysis_results):
    """Calculate code security score."""
    base_score = 80  # Start with a reasonable base score
    
    # Deduct points based on source code findings
    severity_deductions = {
        "critical": 15,
        "high": 10,
        "medium": 5,
        "low": 2
    }
    
    for finding in analysis_results.get("source_code_analysis", {}).get("findings", []):
        severity = finding.get("severity", "").lower()
        if severity in severity_deductions:
            base_score -= severity_deductions[severity]
    
    # Ensure score is between 0 and 100
    return max(0, min(100, base_score))

def calculate_data_protection_score(analysis_results):
    """Calculate data protection score."""
    base_score = 75  # Start with a reasonable base score
    
    # Check for data storage vulnerabilities
    for finding in analysis_results.get("source_code_analysis", {}).get("findings", []):
        if "data storage" in finding.get("title", "").lower():
            base_score -= 25
    
    # Check if app uses secure storage mechanisms (from findings)
    uses_secure_storage = False
    for finding in analysis_results.get("source_code_analysis", {}).get("findings", []):
        if "suggested_fix" in finding and "keychain" in finding["suggested_fix"].lower():
            uses_secure_storage = True
    
    if uses_secure_storage:
        base_score += 10
    
    # Ensure score is between 0 and 100
    return max(0, min(100, base_score))

def calculate_network_security_score(analysis_results):
    """Calculate network security score."""
    base_score = 70  # Start with a reasonable base score
    
    # Check for SSL/TLS vulnerabilities
    for finding in analysis_results.get("source_code_analysis", {}).get("findings", []):
        if "ssl" in finding.get("title", "").lower() or "tls" in finding.get("title", "").lower():
            base_score -= 20
    
    # Check for insecure endpoints
    endpoints = analysis_results.get("network_analysis", {}).get("endpoints", [])
    insecure_endpoints = [e for e in endpoints if e.get("protocol") == "HTTP"]
    
    if insecure_endpoints:
        base_score -= len(insecure_endpoints) * 10
    
    # Check for data leakage
    data_leakage = analysis_results.get("network_analysis", {}).get("data_leakage", [])
    if data_leakage:
        base_score -= len(data_leakage) * 15
    
    # Ensure score is between 0 and 100
    return max(0, min(100, base_score))

def calculate_authentication_score(analysis_results):
    """Calculate authentication security score."""
    # For simplicity, we'll use a high default value since we don't have detailed auth analysis
    return 85

def get_grade_from_score(score):
    """Convert numerical score to letter grade."""
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B+"
    elif score >= 75:
        return "B"
    elif score >= 70:
        return "B-"
    elif score >= 65:
        return "C+"
    elif score >= 60:
        return "C"
    elif score >= 55:
        return "C-"
    elif score >= 50:
        return "D+"
    elif score >= 45:
        return "D"
    else:
        return "F"