"""
Ensemble methods for combining different anomaly detection and clustering algorithms.

This module provides functionality to combine the results of multiple models
to improve the accuracy and robustness of the zero-day vulnerability detection system.
"""

import logging
import numpy as np
from app import db
from models import Payload
from ml_engine.anomaly_detection import detect_anomalies, load_anomaly_detection_model
from ml_engine.clustering import cluster_payloads, load_clustering_model
from ml_engine.feature_extraction import extract_features_from_payload
from ml_engine.utils import get_feature_vector

logger = logging.getLogger(__name__)

def ensemble_anomaly_detection(payload_ids, models=None, weights=None, threshold=0.5):
    """
    Perform ensemble anomaly detection using multiple models.
    
    Args:
        payload_ids (list): List of payload IDs to analyze
        models (list, optional): List of model types to use. If None, all available models are used.
        weights (dict, optional): Dictionary mapping model types to weights. If None, equal weights are used.
        threshold (float): Threshold for classifying a payload as anomalous
        
    Returns:
        dict: Dictionary mapping payload IDs to ensemble anomaly results
    """
    if models is None:
        models = ["isolation_forest", "local_outlier_factor", "one_class_svm", "elliptic_envelope"]
    
    # Validate models - only use those that are available
    available_models = []
    for model_type in models:
        model = load_anomaly_detection_model(model_type)
        if model is not None:
            available_models.append(model_type)
    
    if not available_models:
        logger.warning("No available models for ensemble anomaly detection")
        return {}
    
    # Set weights if not provided
    if weights is None:
        weights = {model_type: 1.0/len(available_models) for model_type in available_models}
    
    # Normalize weights to sum to 1
    total_weight = sum(weights.values())
    weights = {k: v/total_weight for k, v in weights.items()}
    
    # Run anomaly detection with each model
    model_results = {}
    for model_type in available_models:
        results = detect_anomalies(payload_ids, model_type)
        if results:
            model_results[model_type] = results
    
    if not model_results:
        logger.warning("All models failed in ensemble anomaly detection")
        return {}
    
    # Combine results using weighted voting
    ensemble_results = {}
    for payload_id in payload_ids:
        # Calculate weighted anomaly score
        weighted_score = 0
        valid_weight_sum = 0
        is_anomalous_votes = 0
        
        for model_type, results in model_results.items():
            if payload_id in results:
                result = results[payload_id]
                if "using_fallback" not in result:  # Skip fallback results
                    model_weight = weights.get(model_type, 0)
                    weighted_score += result["anomaly_score"] * model_weight
                    valid_weight_sum += model_weight
                    
                    if result["is_anomalous"]:
                        is_anomalous_votes += model_weight
        
        if valid_weight_sum > 0:
            # Normalize weighted score
            normalized_score = weighted_score / valid_weight_sum
            
            # Determine if anomalous
            is_anomalous = (is_anomalous_votes / valid_weight_sum) > threshold
            
            # Store result
            ensemble_results[payload_id] = {
                "anomaly_score": normalized_score,
                "is_anomalous": is_anomalous,
                "confidence": max(is_anomalous_votes / valid_weight_sum, 1 - (is_anomalous_votes / valid_weight_sum))
            }
            
            # Update payload in database
            try:
                payload = Payload.query.get(payload_id)
                if payload:
                    payload.anomaly_score = normalized_score
                    payload.is_anomalous = is_anomalous
                    payload.analyzed = True
                    db.session.commit()
            except Exception as e:
                logger.error(f"Error updating payload {payload_id}: {str(e)}")
                db.session.rollback()
    
    return ensemble_results

def consensus_clustering(payload_ids, models=None):
    """
    Perform consensus clustering using multiple clustering algorithms.
    
    This function combines results from multiple clustering algorithms to
    produce a more robust and stable clustering.
    
    Args:
        payload_ids (list): List of payload IDs to cluster
        models (list, optional): List of model types to use. If None, all available models are used.
        
    Returns:
        dict: Dictionary mapping payload IDs to consensus cluster assignments
    """
    if models is None:
        models = ["kmeans", "dbscan", "birch", "gaussian_mixture"]
    
    # Validate models - only use those that are available
    available_models = []
    for model_type in models:
        model = load_clustering_model(model_type)
        if model is not None:
            available_models.append(model_type)
    
    if not available_models:
        logger.warning("No available models for consensus clustering")
        return {}
    
    # Run clustering with each model
    model_results = {}
    for model_type in available_models:
        results = cluster_payloads(payload_ids, model_type)
        if results:
            model_results[model_type] = results
    
    if not model_results:
        logger.warning("All models failed in consensus clustering")
        return {}
    
    # Create co-association matrix
    n = len(payload_ids)
    co_association = np.zeros((n, n))
    
    for model_type, results in model_results.items():
        # Get cluster assignments
        clusters = {}
        for i, pid in enumerate(payload_ids):
            if pid in results:
                clusters[i] = results[pid].get("cluster_id", 0)
            else:
                clusters[i] = 0
        
        # Update co-association matrix
        for i in range(n):
            for j in range(i+1, n):
                if i in clusters and j in clusters:
                    if clusters[i] == clusters[j]:
                        co_association[i, j] += 1
                        co_association[j, i] += 1
    
    # Normalize co-association matrix
    co_association /= len(model_results)
    
    # Convert co-association matrix to a distance matrix for final clustering
    distance_matrix = 1 - co_association
    
    # Perform final clustering using hierarchical clustering
    from sklearn.cluster import AgglomerativeClustering
    final_model = AgglomerativeClustering(
        n_clusters=None,
        distance_threshold=0.5,  # Cut the tree where distance > 0.5
        affinity="precomputed",
        linkage="average"
    )
    
    try:
        labels = final_model.fit_predict(distance_matrix)
        
        # Update payloads and build results
        consensus_results = {}
        for i, payload_id in enumerate(payload_ids):
            try:
                payload = Payload.query.get(payload_id)
                if payload:
                    payload.cluster_id = int(labels[i])
                    db.session.commit()
                    
                consensus_results[payload_id] = {
                    "cluster_id": int(labels[i])
                }
            except Exception as e:
                logger.error(f"Error updating payload {payload_id}: {str(e)}")
                db.session.rollback()
        
        return consensus_results
    
    except Exception as e:
        logger.error(f"Error in consensus clustering: {str(e)}")
        return {}

def train_ensemble_models(anomaly_models, clustering_models, X_train, X_val, y_val):
    """
    Train ensemble models that combine multiple anomaly detection and clustering models.
    
    Args:
        anomaly_models (dict): Dictionary of trained anomaly detection models
        clustering_models (dict): Dictionary of trained clustering models
        X_train (numpy.ndarray): Training data features
        X_val (numpy.ndarray): Validation data features
        y_val (numpy.ndarray): Validation data labels
        
    Returns:
        dict: Dictionary containing ensemble models and their metrics
    """
    logger.info("Training ensemble models")
    
    # Initialize result dictionary
    result = {
        "models": {},
        "metrics": {}
    }
    
    try:
        # Train weighted ensemble for anomaly detection
        if len(anomaly_models) > 1:
            logger.info(f"Training weighted ensemble with {len(anomaly_models)} anomaly models")
            
            # Get validation predictions from each model
            model_predictions = {}
            model_scores = {}
            
            for model_type, model in anomaly_models.items():
                try:
                    # Get predictions
                    if model_type in ['isolation_forest', 'local_outlier_factor', 'one_class_svm', 'elliptic_envelope']:
                        preds = model.predict(X_val)
                        # Convert from -1/1 to 1/0 (anomaly/normal)
                        preds_binary = np.where(preds == -1, 1, 0)
                        
                        # Get scores if available
                        try:
                            scores = -model.decision_function(X_val)
                        except (AttributeError, ValueError):
                            scores = np.array([float(p == -1) for p in preds])
                            
                    elif model_type in ['random_forest', 'mlp_classifier']:
                        preds_binary = model.predict(X_val)
                        
                        # Get probabilities if available
                        try:
                            scores = model.predict_proba(X_val)[:, 1]
                        except (AttributeError, ValueError, IndexError):
                            scores = np.array([float(p) for p in preds_binary])
                    
                    # Calculate model accuracy
                    from sklearn.metrics import accuracy_score, f1_score
                    accuracy = accuracy_score(y_val, preds_binary)
                    f1 = f1_score(y_val, preds_binary, zero_division=0)
                    
                    # Store predictions and metrics
                    model_predictions[model_type] = preds_binary
                    model_scores[model_type] = scores
                    
                    logger.info(f"Model {model_type}: accuracy={accuracy:.4f}, f1={f1:.4f}")
                    
                except Exception as e:
                    logger.error(f"Error getting predictions for model {model_type}: {str(e)}")
            
            if not model_predictions:
                logger.warning("No valid model predictions available for ensemble")
            else:
                # Calculate optimal weights based on performance
                # We'll use F1 score as the weight
                weights = {}
                total_f1 = 0
                
                for model_type, preds in model_predictions.items():
                    f1 = f1_score(y_val, preds, zero_division=0)
                    weights[model_type] = f1
                    total_f1 += f1
                
                # Normalize weights
                if total_f1 > 0:
                    weights = {k: v / total_f1 for k, v in weights.items()}
                else:
                    # Equal weights if all models perform poorly
                    weights = {k: 1.0 / len(model_predictions) for k in model_predictions.keys()}
                
                # Store the weights
                result["models"]["weighted_ensemble"] = {
                    "weights": weights,
                    "model_types": list(weights.keys())
                }
                
                # Evaluate the ensemble on validation data
                ensemble_scores = np.zeros(len(y_val))
                for model_type, model_weight in weights.items():
                    ensemble_scores += model_scores[model_type] * model_weight
                
                # Find the optimal threshold using ROC curve
                from sklearn.metrics import roc_curve, precision_recall_curve, f1_score, precision_score, recall_score, accuracy_score
                
                # ROC curve optimization
                fpr, tpr, thresholds = roc_curve(y_val, ensemble_scores)
                
                # Find threshold that maximizes TPR - FPR (Youden's J statistic)
                optimal_threshold_idx = np.argmax(tpr - fpr)
                optimal_threshold = thresholds[optimal_threshold_idx]
                
                # Apply threshold to get binary predictions
                ensemble_preds = (ensemble_scores >= optimal_threshold).astype(int)
                
                # Calculate metrics
                precision = precision_score(y_val, ensemble_preds, zero_division=0)
                recall = recall_score(y_val, ensemble_preds, zero_division=0)
                f1 = f1_score(y_val, ensemble_preds, zero_division=0)
                accuracy = accuracy_score(y_val, ensemble_preds)
                
                # Store metrics
                result["metrics"]["weighted_ensemble"] = {
                    "threshold": float(optimal_threshold),
                    "precision": float(precision),
                    "recall": float(recall),
                    "f1_score": float(f1),
                    "accuracy": float(accuracy)
                }
                
                logger.info(f"Ensemble metrics: precision={precision:.4f}, recall={recall:.4f}, f1={f1:.4f}")
        
        # Handle consensus clustering
        if len(clustering_models) > 1:
            logger.info(f"Training consensus clustering with {len(clustering_models)} clustering models")
            
            # Get cluster assignments from each model
            model_clusters = {}
            for model_type, model in clustering_models.items():
                try:
                    # Get cluster assignments
                    cluster_labels = model.predict(X_val)
                    model_clusters[model_type] = cluster_labels
                except Exception as e:
                    logger.error(f"Error getting cluster assignments for model {model_type}: {str(e)}")
            
            if len(model_clusters) < 2:
                logger.warning("Not enough valid clustering models for consensus")
            else:
                # Create co-association matrix
                n_samples = len(X_val)
                co_association = np.zeros((n_samples, n_samples))
                
                # For each clustering result, update co-association matrix
                for model_type, clusters in model_clusters.items():
                    for i in range(n_samples):
                        for j in range(i+1, n_samples):
                            if clusters[i] == clusters[j]:
                                co_association[i, j] += 1
                                co_association[j, i] += 1
                
                # Normalize co-association matrix
                co_association /= len(model_clusters)
                
                # Convert co-association matrix to distance matrix
                distance_matrix = 1 - co_association
                
                # Apply hierarchical clustering to the distance matrix
                from sklearn.cluster import AgglomerativeClustering
                
                # Determine optimal number of clusters
                optimal_n_clusters = 5  # Default
                
                # Try different numbers of clusters and evaluate
                silhouette_scores = []
                n_clusters_range = range(2, min(11, n_samples // 5))
                
                for n_clusters in n_clusters_range:
                    try:
                        consensus_model = AgglomerativeClustering(
                            n_clusters=n_clusters,
                            affinity='precomputed',
                            linkage='average'
                        )
                        consensus_labels = consensus_model.fit_predict(distance_matrix)
                        
                        # Calculate silhouette score
                        from sklearn.metrics import silhouette_score
                        if len(np.unique(consensus_labels)) > 1:
                            score = silhouette_score(X_val, consensus_labels)
                            silhouette_scores.append((n_clusters, score))
                    except Exception as e:
                        logger.warning(f"Error evaluating consensus clustering with {n_clusters} clusters: {str(e)}")
                
                # Find optimal number of clusters
                if silhouette_scores:
                    optimal_n_clusters = max(silhouette_scores, key=lambda x: x[1])[0]
                
                # Create final consensus model
                consensus_model = AgglomerativeClustering(
                    n_clusters=optimal_n_clusters,
                    affinity='precomputed',
                    linkage='average'
                )
                consensus_labels = consensus_model.fit_predict(distance_matrix)
                
                # Store the consensus model configuration
                result["models"]["consensus_clustering"] = {
                    "n_clusters": optimal_n_clusters,
                    "model_types": list(model_clusters.keys())
                }
                
                # Calculate metrics for consensus clustering
                try:
                    from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
                    
                    metrics = {}
                    
                    if len(np.unique(consensus_labels)) > 1:
                        metrics["silhouette_score"] = float(silhouette_score(X_val, consensus_labels))
                        metrics["davies_bouldin_index"] = float(davies_bouldin_score(X_val, consensus_labels))
                        metrics["calinski_harabasz_index"] = float(calinski_harabasz_score(X_val, consensus_labels))
                    
                    # Calculate cluster distribution
                    unique_clusters, cluster_counts = np.unique(consensus_labels, return_counts=True)
                    cluster_distribution = {int(k): int(v) for k, v in zip(unique_clusters, cluster_counts)}
                    metrics["cluster_distribution"] = cluster_distribution
                    
                    # Store metrics
                    result["metrics"]["consensus_clustering"] = metrics
                    
                    logger.info(f"Consensus clustering metrics: silhouette={metrics.get('silhouette_score', 0):.4f}")
                except Exception as e:
                    logger.error(f"Error calculating consensus clustering metrics: {str(e)}")
        
        # Combined anomaly detection and clustering model
        if anomaly_models and clustering_models:
            logger.info("Training combined anomaly detection and clustering model")
            
            # Use the best anomaly detection model
            best_anomaly_model = None
            best_f1 = -1
            
            for model_type, model in anomaly_models.items():
                try:
                    # Get predictions
                    if model_type in ['isolation_forest', 'local_outlier_factor', 'one_class_svm', 'elliptic_envelope']:
                        preds = model.predict(X_val)
                        preds_binary = np.where(preds == -1, 1, 0)
                    else:
                        preds_binary = model.predict(X_val)
                    
                    # Calculate F1 score
                    f1 = f1_score(y_val, preds_binary, zero_division=0)
                    
                    if f1 > best_f1:
                        best_f1 = f1
                        best_anomaly_model = (model_type, model)
                        
                except Exception as e:
                    logger.error(f"Error evaluating model {model_type} for combined detection: {str(e)}")
            
            # Use the first clustering model (or consensus if available)
            clustering_model = None
            clustering_model_type = None
            
            if "consensus_clustering" in result["models"]:
                # Use consensus clustering
                clustering_model_type = "consensus_clustering"
            elif clustering_models:
                # Use the first available clustering model
                clustering_model_type = next(iter(clustering_models.keys()))
                clustering_model = clustering_models[clustering_model_type]
            
            if best_anomaly_model and clustering_model_type:
                # Store the combined model configuration
                result["models"]["combined_detection"] = {
                    "anomaly_model_type": best_anomaly_model[0],
                    "clustering_model_type": clustering_model_type
                }
                
                # Calculate and store metrics
                # For combined detection, we would typically need to evaluate on real data
                # Here we just record that the model was created
                result["metrics"]["combined_detection"] = {
                    "configuration": f"Combines {best_anomaly_model[0]} and {clustering_model_type}"
                }
        
        return result
    
    except Exception as e:
        logger.error(f"Error training ensemble models: {str(e)}")
        return {"error": str(e)}

def combine_detection_methods(payload_ids):
    """
    Combine anomaly detection and clustering to improve vulnerability detection.
    
    This function uses insights from both anomaly detection and clustering
    to produce more accurate vulnerability classifications.
    
    Args:
        payload_ids (list): List of payload IDs to analyze
        
    Returns:
        dict: Dictionary mapping payload IDs to combined detection results
    """
    # Run ensemble anomaly detection
    anomaly_results = ensemble_anomaly_detection(payload_ids)
    
    # Run consensus clustering
    cluster_results = consensus_clustering(payload_ids)
    
    # Combine results
    combined_results = {}
    
    for payload_id in payload_ids:
        payload = Payload.query.get(payload_id)
        if not payload:
            continue
        
        # Get anomaly and cluster data
        anomaly_data = anomaly_results.get(payload_id, {})
        cluster_data = cluster_results.get(payload_id, {})
        
        # Basic data
        result = {
            "payload_id": payload_id,
            "anomaly_score": anomaly_data.get("anomaly_score", payload.anomaly_score or 0),
            "is_anomalous": anomaly_data.get("is_anomalous", payload.is_anomalous or False),
            "cluster_id": cluster_data.get("cluster_id", payload.cluster_id or 0)
        }
        
        # Calculate cluster-enhanced confidence
        if result["cluster_id"] is not None:
            # Get other payloads in the same cluster
            cluster_payloads = Payload.query.filter(
                Payload.cluster_id == result["cluster_id"],
                Payload.id != payload_id
            ).all()
            
            if cluster_payloads:
                # Calculate percentage of anomalies in the cluster
                anomaly_percentage = sum(1 for p in cluster_payloads if p.is_anomalous) / len(cluster_payloads)
                
                # Adjust confidence based on cluster anomaly percentage
                if result["is_anomalous"] and anomaly_percentage > 0.5:
                    # More confident it's anomalous if other payloads in cluster are anomalous
                    confidence_boost = min(0.2, anomaly_percentage / 5)
                    result["confidence"] = min(1.0, anomaly_data.get("confidence", 0.7) + confidence_boost)
                elif not result["is_anomalous"] and anomaly_percentage < 0.3:
                    # More confident it's normal if other payloads in cluster are normal
                    confidence_boost = min(0.2, (1 - anomaly_percentage) / 5)
                    result["confidence"] = min(1.0, anomaly_data.get("confidence", 0.7) + confidence_boost)
                else:
                    # No adjustment
                    result["confidence"] = anomaly_data.get("confidence", 0.7)
            else:
                result["confidence"] = anomaly_data.get("confidence", 0.7)
        else:
            result["confidence"] = anomaly_data.get("confidence", 0.7)
        
        combined_results[payload_id] = result
    
    return combined_results