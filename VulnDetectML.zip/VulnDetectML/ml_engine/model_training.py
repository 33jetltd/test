"""
Model training module for zero-day vulnerability detection.

This module provides functionality to train both anomaly detection and
clustering models for identifying zero-day vulnerabilities in payloads.
"""

import logging
import os
import json
import numpy as np
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.preprocessing import StandardScaler
from app import db
from models import TrainingSession, Payload
from ml_engine.feature_extraction import extract_features_from_payload
from ml_engine.anomaly_detection import train_anomaly_detection_model, save_anomaly_detection_model
from ml_engine.clustering import train_clustering_model, save_clustering_model
from ml_engine.utils import get_feature_vector
from ml_engine.data_generator import generate_sample_data

logger = logging.getLogger(__name__)

def train_models(training_session_id, sample_size=100, model_config=None):
    """
    Train anomaly detection and clustering models with support for advanced algorithms and ensemble methods.
    
    Args:
        training_session_id (int): ID of the training session
        sample_size (int): Number of samples to generate if needed
        model_config (dict, optional): Configuration for models to train:
            {
                'anomaly_models': List of model types to train for anomaly detection
                'clustering_models': List of model types to train for clustering
                'use_ensemble': Whether to train ensemble models
                'advanced_features': Whether to use advanced feature extraction
            }
        
    Returns:
        dict: Training results and metrics
    """
    logger.info(f"Starting model training: session={training_session_id}, sample_size={sample_size}")
    
    # Retrieve the training session
    training_session = TrainingSession.query.get(training_session_id)
    if not training_session:
        raise ValueError(f"Training session {training_session_id} not found")
    
    try:
        # Set default model configuration if none provided
        if model_config is None:
            model_config = {
                'anomaly_models': ['isolation_forest', 'elliptic_envelope', 'random_forest', 'mlp_classifier'],
                'clustering_models': ['kmeans', 'birch', 'gaussian_mixture', 'spectral', 'mean_shift'],
                'use_ensemble': True,
                'advanced_features': True
            }
        
        # Prepare training data
        X_train, X_val, y_train, y_val = prepare_training_data(
            sample_size, 
            use_advanced_features=model_config.get('advanced_features', True)
        )
        
        # Train all specified anomaly detection models
        anomaly_models = {}
        anomaly_model_paths = {}
        anomaly_metrics = {}
        
        for model_type in model_config.get('anomaly_models', ['isolation_forest']):
            logger.info(f"Training anomaly detection model: {model_type}")
            
            # Configure model parameters based on model type
            model_params = {'random_state': 42}
            
            if model_type == 'isolation_forest':
                model_params.update({
                    'n_estimators': 100,
                    'contamination': 0.1,
                    'max_samples': 'auto'
                })
            elif model_type == 'elliptic_envelope':
                model_params.update({
                    'contamination': 0.1,
                    'support_fraction': 0.8
                })
            elif model_type == 'random_forest' or model_type == 'mlp_classifier':
                # These are supervised models, so they need labels
                model_params.update({
                    'y_train': y_train  # Pass labels for supervised models
                })
                
                if model_type == 'random_forest':
                    model_params.update({
                        'n_estimators': 100,
                        'max_depth': 10
                    })
                else:  # mlp_classifier
                    model_params.update({
                        'hidden_layer_sizes': (100, 50),
                        'max_iter': 1000,
                        'activation': 'relu'
                    })
            
            # Train the model
            model = train_anomaly_detection_model(X_train, model_type=model_type, **model_params)
            
            # Save the model
            model_path = save_anomaly_detection_model(model, model_type=model_type)
            
            # Store model and path
            anomaly_models[model_type] = model
            anomaly_model_paths[model_type] = model_path
            
            # Evaluate the model
            model_metrics = evaluate_anomaly_model(model, model_type, X_val, y_val)
            anomaly_metrics[model_type] = model_metrics
        
        # Train all specified clustering models
        clustering_models = {}
        clustering_model_paths = {}
        clustering_metrics = {}
        
        for model_type in model_config.get('clustering_models', ['kmeans']):
            logger.info(f"Training clustering model: {model_type}")
            
            # Configure model parameters based on model type
            model_params = {'random_state': 42}
            
            if model_type == 'kmeans':
                model_params.update({
                    'n_clusters': 5
                })
            elif model_type == 'birch':
                model_params.update({
                    'n_clusters': 5,
                    'threshold': 0.5
                })
            elif model_type == 'gaussian_mixture':
                model_params.update({
                    'n_components': 5,
                    'covariance_type': 'full'
                })
            elif model_type == 'spectral':
                model_params.update({
                    'n_clusters': 5,
                    'affinity': 'rbf'
                })
            elif model_type == 'mean_shift':
                # Mean Shift automatically determines the number of clusters
                model_params.update({
                    'bandwidth': None,  # Automatically estimate bandwidth
                    'bin_seeding': True
                })
            
            # Train the model
            model = train_clustering_model(X_train, model_type=model_type, **model_params)
            
            # Save the model
            model_path = save_clustering_model(model, model_type=model_type)
            
            # Store model and path
            clustering_models[model_type] = model
            clustering_model_paths[model_type] = model_path
            
            # Evaluate the model (for clustering, we use internal metrics)
            model_metrics = evaluate_clustering_model(model, model_type, X_val)
            clustering_metrics[model_type] = model_metrics
        
        # Train ensemble models if specified
        ensemble_metrics = {}
        if model_config.get('use_ensemble', False):
            logger.info("Training ensemble models")
            
            # Import ensemble functions
            from ml_engine.ensemble import train_ensemble_models
            
            # Train ensemble models
            ensemble_results = train_ensemble_models(
                anomaly_models=anomaly_models,
                clustering_models=clustering_models,
                X_train=X_train,
                X_val=X_val,
                y_val=y_val
            )
            
            # Add ensemble metrics
            ensemble_metrics = ensemble_results.get('metrics', {})
        
        # Combine all metrics
        metrics = {
            'anomaly_detection': anomaly_metrics,
            'clustering': clustering_metrics,
            'ensemble': ensemble_metrics
        }
        
        # Update training session
        training_session.completed_at = datetime.utcnow()
        training_session.status = "completed"
        
        # Store primary model paths (we'll store the best performing ones)
        if anomaly_model_paths:
            # Find best anomaly model based on F1 score
            best_anomaly_model = max(
                anomaly_metrics.items(),
                key=lambda x: x[1].get('f1_score', 0)
            )[0]
            training_session.anomaly_model_path = anomaly_model_paths.get(best_anomaly_model)
        
        if clustering_model_paths:
            # For clustering, we'll just use the first one
            training_session.clustering_model_path = next(iter(clustering_model_paths.values()))
        
        # Store all metrics
        training_session.performance_metrics = json.dumps(metrics)
        
        db.session.commit()
        
        logger.info(f"Training completed: session={training_session_id}")
        
        return {
            "training_session_id": training_session_id,
            "anomaly_model_path": anomaly_model_path,
            "clustering_model_path": clustering_model_path,
            "metrics": metrics
        }
    
    except Exception as e:
        logger.error(f"Error during training: {str(e)}")
        
        # Update training session with error
        training_session.status = "failed"
        db.session.commit()
        
        raise
        
def evaluate_anomaly_model(model, model_type, X_val, y_val):
    """
    Evaluate an anomaly detection model on validation data.
    
    Args:
        model: Trained anomaly detection model
        model_type (str): Type of model being evaluated
        X_val (numpy.ndarray): Validation features
        y_val (numpy.ndarray): Validation labels
        
    Returns:
        dict: Evaluation metrics
    """
    try:
        # Different models have different prediction formats
        if model_type in ['isolation_forest', 'local_outlier_factor', 'one_class_svm', 'elliptic_envelope']:
            # These models predict -1 for anomalies, 1 for normal
            anomaly_preds = model.predict(X_val)
            # Convert to binary (1 for anomalies, 0 for normal)
            anomaly_preds_binary = np.where(anomaly_preds == -1, 1, 0)
            
            # Some models have decision_function for scores
            try:
                anomaly_scores = -model.decision_function(X_val)  # Negated because lower scores are more normal
                # Calculate AUC if possible
                from sklearn.metrics import roc_auc_score
                auc = roc_auc_score(y_val, anomaly_scores)
            except (AttributeError, ValueError) as e:
                logger.warning(f"Could not calculate AUC for {model_type}: {str(e)}")
                auc = None
                
        elif model_type in ['random_forest', 'mlp_classifier']:
            # These are supervised models that predict 0 for normal, 1 for anomalies
            anomaly_preds_binary = model.predict(X_val)
            
            # Try to get prediction probabilities
            try:
                anomaly_scores = model.predict_proba(X_val)[:, 1]  # Probability of class 1 (anomaly)
                from sklearn.metrics import roc_auc_score
                auc = roc_auc_score(y_val, anomaly_scores)
            except (AttributeError, ValueError, IndexError) as e:
                logger.warning(f"Could not calculate AUC for {model_type}: {str(e)}")
                auc = None
        else:
            logger.warning(f"Unknown model type for evaluation: {model_type}")
            return {"error": f"Unknown model type: {model_type}"}
        
        # Calculate standard classification metrics
        from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, confusion_matrix
        
        precision = precision_score(y_val, anomaly_preds_binary, zero_division=0)
        recall = recall_score(y_val, anomaly_preds_binary, zero_division=0)
        f1 = f1_score(y_val, anomaly_preds_binary, zero_division=0)
        accuracy = accuracy_score(y_val, anomaly_preds_binary)
        
        # Calculate confusion matrix
        tn, fp, fn, tp = confusion_matrix(y_val, anomaly_preds_binary, labels=[0, 1]).ravel()
        
        # Advanced metrics
        # True Positive Rate (Sensitivity)
        tpr = tp / (tp + fn) if (tp + fn) > 0 else 0
        # True Negative Rate (Specificity)
        tnr = tn / (tn + fp) if (tn + fp) > 0 else 0
        # False Positive Rate
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
        # False Negative Rate
        fnr = fn / (fn + tp) if (fn + tp) > 0 else 0
        
        metrics = {
            "model_type": model_type,
            "precision": float(precision),
            "recall": float(recall),
            "f1_score": float(f1),
            "accuracy": float(accuracy),
            "true_positives": int(tp),
            "true_negatives": int(tn),
            "false_positives": int(fp),
            "false_negatives": int(fn),
            "true_positive_rate": float(tpr),
            "true_negative_rate": float(tnr),
            "false_positive_rate": float(fpr),
            "false_negative_rate": float(fnr),
        }
        
        # Add AUC if calculated
        if auc is not None:
            metrics["auc"] = float(auc)
        
        return metrics
    except Exception as e:
        logger.error(f"Error evaluating {model_type} model: {str(e)}")
        return {"error": str(e)}

def evaluate_clustering_model(model, model_type, X_val):
    """
    Evaluate a clustering model using internal validation metrics.
    
    Args:
        model: Trained clustering model
        model_type (str): Type of model being evaluated
        X_val (numpy.ndarray): Validation features
        
    Returns:
        dict: Evaluation metrics
    """
    try:
        # Get cluster assignments for validation data
        if model_type in ['kmeans', 'birch']:
            cluster_labels = model.predict(X_val)
            cluster_centers = getattr(model, 'cluster_centers_', None)
            n_clusters = getattr(model, 'n_clusters', 0)
            inertia = getattr(model, 'inertia_', None)
        elif model_type == 'gaussian_mixture':
            cluster_labels = model.predict(X_val)
            cluster_centers = getattr(model, 'means_', None)
            n_clusters = getattr(model, 'n_components', 0)
            inertia = None
        elif model_type == 'spectral':
            cluster_labels = model.predict(X_val)
            n_clusters = getattr(model, 'n_clusters', 0)
            cluster_centers = None
            inertia = None
        elif model_type == 'mean_shift':
            cluster_labels = model.predict(X_val)
            cluster_centers = getattr(model, 'cluster_centers_', None)
            n_clusters = len(cluster_centers) if cluster_centers is not None else 0
            inertia = None
        else:
            logger.warning(f"Unknown model type for clustering evaluation: {model_type}")
            return {"error": f"Unknown model type: {model_type}"}
        
        # Calculate internal validation metrics
        metrics = {
            "model_type": model_type,
            "n_clusters": int(n_clusters)
        }
        
        # Add inertia if available
        if inertia is not None:
            metrics["inertia"] = float(inertia)
        
        # Calculate silhouette score if possible
        try:
            from sklearn.metrics import silhouette_score
            if len(np.unique(cluster_labels)) > 1:  # Need at least 2 clusters
                silhouette = silhouette_score(X_val, cluster_labels)
                metrics["silhouette_score"] = float(silhouette)
        except Exception as e:
            logger.warning(f"Could not calculate silhouette score: {str(e)}")
        
        # Calculate Davies-Bouldin index if possible
        try:
            from sklearn.metrics import davies_bouldin_score
            if len(np.unique(cluster_labels)) > 1:
                db_index = davies_bouldin_score(X_val, cluster_labels)
                metrics["davies_bouldin_index"] = float(db_index)
        except Exception as e:
            logger.warning(f"Could not calculate Davies-Bouldin index: {str(e)}")
        
        # Calculate Calinski-Harabasz index if possible
        try:
            from sklearn.metrics import calinski_harabasz_score
            if len(np.unique(cluster_labels)) > 1:
                ch_index = calinski_harabasz_score(X_val, cluster_labels)
                metrics["calinski_harabasz_index"] = float(ch_index)
        except Exception as e:
            logger.warning(f"Could not calculate Calinski-Harabasz index: {str(e)}")
        
        # Add cluster distribution
        unique_clusters, cluster_counts = np.unique(cluster_labels, return_counts=True)
        cluster_distribution = {int(k): int(v) for k, v in zip(unique_clusters, cluster_counts)}
        metrics["cluster_distribution"] = cluster_distribution
        
        return metrics
    except Exception as e:
        logger.error(f"Error evaluating {model_type} clustering model: {str(e)}")
        return {"error": str(e)}

def prepare_training_data(sample_size=100, use_advanced_features=True):
    """
    Prepare training data for model training with support for advanced feature extraction.
    
    This function will first check if there are enough analyzed payloads
    in the database. If not, it will generate synthetic samples.
    
    Args:
        sample_size (int): Number of samples to generate if needed
        use_advanced_features (bool): Whether to use advanced feature extraction
        
    Returns:
        tuple: X_train, X_val, y_train, y_val
    """
    # Check if we have enough analyzed payloads
    analyzed_payloads = Payload.query.filter_by(analyzed=True).all()
    
    if len(analyzed_payloads) >= sample_size:
        logger.info(f"Using {len(analyzed_payloads)} existing payloads for training")
        
        # Extract features from existing payloads
        features_list = []
        labels = []
        
        for payload in analyzed_payloads:
            try:
                # Extract features
                features_dict = extract_features_from_payload(payload.id)
                
                # Add to list
                features_list.append(features_dict)
                labels.append(1 if payload.is_anomalous else 0)
                
            except Exception as e:
                logger.error(f"Error extracting features from payload {payload.id}: {str(e)}")
    else:
        logger.info(f"Generating {sample_size} synthetic samples for training")
        
        # Generate synthetic samples
        result = generate_sample_data(sample_size)
        
        # Get features and labels from generated data
        features_list = result["features"]
        labels = result["labels"]
    
    # Convert features to matrix
    X = get_feature_vector(features_list)
    y = np.array(labels)
    
    # Scale the features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Split into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )
    
    logger.info(f"Prepared training data: X_train={X_train.shape}, X_val={X_val.shape}")
    
    return X_train, X_val, y_train, y_val

def evaluate_models(anomaly_model, clustering_model, X_val, y_val):
    """
    Evaluate the trained models on validation data.
    
    Args:
        anomaly_model: Trained anomaly detection model
        clustering_model: Trained clustering model
        X_val (numpy.ndarray): Validation features
        y_val (numpy.ndarray): Validation labels
        
    Returns:
        dict: Evaluation metrics
    """
    # Evaluate anomaly detection model
    # For anomaly detection, -1 typically indicates anomalies
    anomaly_preds = anomaly_model.predict(X_val)
    # Convert from the model's format (-1 for anomalies, 1 for normal) to binary (1 for anomalies, 0 for normal)
    anomaly_preds_binary = np.where(anomaly_preds == -1, 1, 0)
    
    # Calculate metrics
    precision = precision_score(y_val, anomaly_preds_binary)
    recall = recall_score(y_val, anomaly_preds_binary)
    f1 = f1_score(y_val, anomaly_preds_binary)
    
    # For clustering, we'll calculate some internal metrics
    # like silhouette score, but since this is unsupervised,
    # we can't directly compare to ground truth labels
    
    # Create metrics dictionary
    metrics = {
        "anomaly_detection": {
            "precision": float(precision),
            "recall": float(recall),
            "f1_score": float(f1)
        },
        "clustering": {
            "n_clusters": getattr(clustering_model, "n_clusters", 0),
            "inertia": getattr(clustering_model, "inertia_", 0)
        }
    }
    
    return metrics
